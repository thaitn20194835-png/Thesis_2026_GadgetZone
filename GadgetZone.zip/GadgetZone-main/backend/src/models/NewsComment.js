const mongoose = require('mongoose');

const newsCommentSchema = new mongoose.Schema({
  news: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'News',
    required: true,
  },
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  content: {
    type: String,
    required: [true, 'Nội dung không được trống'],
    trim: true,
    maxlength: 1000,
  },
  isApproved: { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('NewsComment', newsCommentSchema);
