const mongoose = require('mongoose');

const supplierSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Vui lòng nhập tên nhà cung cấp'],
    trim: true,
  },
  contactPerson: { type: String, default: '' },
  email: { type: String, default: '' },
  phone: { type: String, default: '' },
  address: { type: String, default: '' },
  website: { type: String, default: '' },
  taxCode: { type: String, default: '' },
  logo: { type: String, default: '' },
  brands: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Brand' }],
  note: { type: String, default: '' },
  isActive: { type: Boolean, default: true },
}, { timestamps: true });

module.exports = mongoose.model('Supplier', supplierSchema);
