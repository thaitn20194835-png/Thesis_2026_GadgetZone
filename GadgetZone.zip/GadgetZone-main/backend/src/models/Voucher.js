const mongoose = require('mongoose');

const voucherSchema = new mongoose.Schema({
  code: {
    type: String,
    required: [true, 'Vui lòng nhập mã voucher'],
    unique: true,
    uppercase: true,
    trim: true,
  },
  description: { type: String, default: '' },
  type: {
    type: String,
    enum: ['percent', 'fixed'],
    default: 'percent',
  },
  value: {
    type: Number,
    required: true,
    min: 0,
  },
  maxDiscount: { type: Number, default: 0 },
  minOrderValue: { type: Number, default: 0 },
  usageLimit: { type: Number, default: 0 },
  usedCount: { type: Number, default: 0 },
  startDate: { type: Date, default: Date.now },
  endDate: { type: Date, required: true },
  isActive: { type: Boolean, default: true },
}, { timestamps: true });

voucherSchema.methods.calculateDiscount = function (orderAmount) {
  if (orderAmount < this.minOrderValue) return 0;
  let discount = 0;
  if (this.type === 'percent') {
    discount = Math.round((orderAmount * this.value) / 100);
    if (this.maxDiscount > 0 && discount > this.maxDiscount) discount = this.maxDiscount;
  } else {
    discount = this.value;
  }
  return Math.min(discount, orderAmount);
};

voucherSchema.methods.isValid = function () {
  const now = new Date();
  if (!this.isActive) return { valid: false, message: 'Mã đã bị vô hiệu hóa' };
  if (now < this.startDate) return { valid: false, message: 'Mã chưa có hiệu lực' };
  if (now > this.endDate) return { valid: false, message: 'Mã đã hết hạn' };
  if (this.usageLimit > 0 && this.usedCount >= this.usageLimit) {
    return { valid: false, message: 'Mã đã hết lượt sử dụng' };
  }
  return { valid: true };
};

module.exports = mongoose.model('Voucher', voucherSchema);
