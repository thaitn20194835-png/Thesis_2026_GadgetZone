const mongoose = require('mongoose');

const newsSchema = new mongoose.Schema({
  title: { type: String, required: true, trim: true },
  slug: { type: String, unique: true },
  summary: { type: String, default: '' },
  content: { type: String, required: true },
  image: { type: String, default: '' },
  author: { type: String, default: 'Admin GadgetZone' },
  isPublished: { type: Boolean, default: true },
  tags: [{ type: String }],
}, { timestamps: true });

newsSchema.pre('save', function () {
  if (this.isModified('title')) {
    this.slug = this.title
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/đ/g, 'd')
      .replace(/Đ/g, 'D')
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/(^-|-$)/g, '')
      + '-' + Date.now().toString(36);
  }
});

module.exports = mongoose.model('News', newsSchema);
