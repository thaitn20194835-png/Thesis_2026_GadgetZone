const mongoose = require('mongoose');

const brandSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Vui lòng nhập tên thương hiệu'],
    unique: true,
    trim: true,
  },
  slug: {
    type: String,
    unique: true,
  },
  logo: {
    type: String,
    default: '',
  },
}, { timestamps: true });

brandSchema.pre('save', function () {
  this.slug = this.name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
});

module.exports = mongoose.model('Brand', brandSchema);
