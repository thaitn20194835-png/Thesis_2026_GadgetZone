const express = require('express');
const router = express.Router();
const { protect, authorize } = require('../middleware/auth');
const {
  getAll,
  getById,
  create,
  update,
  delete: deleteNews,
  adminGetAll,
} = require('../controllers/news.controller');

// Admin routes (đặt trước /:id để tránh conflict)
router.get('/admin/all', protect, authorize('admin'), adminGetAll);

// Public routes
router.get('/', getAll);
router.get('/:id', getById);

// Admin CRUD
router.post('/', protect, authorize('admin'), create);
router.put('/:id', protect, authorize('admin'), update);
router.delete('/:id', protect, authorize('admin'), deleteNews);

module.exports = router;
