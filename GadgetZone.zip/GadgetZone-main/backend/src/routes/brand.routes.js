const router = require('express').Router();
const { getAll, getById, create, update, delete: deleteBrand } = require('../controllers/brand.controller');
const { protect, authorize } = require('../middleware/auth');

router.get('/', getAll);
router.get('/:id', getById);
router.post('/', protect, authorize('admin'), create);
router.put('/:id', protect, authorize('admin'), update);
router.delete('/:id', protect, authorize('admin'), deleteBrand);

module.exports = router;
