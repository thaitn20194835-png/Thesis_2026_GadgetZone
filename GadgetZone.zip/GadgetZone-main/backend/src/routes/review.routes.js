const router = require('express').Router();
const { getByProduct, create, delete: deleteReview, adminGetAll } = require('../controllers/review.controller');
const { protect, authorize } = require('../middleware/auth');

router.get('/admin/all', protect, authorize('admin'), adminGetAll);
router.get('/product/:productId', getByProduct);
router.post('/', protect, create);
router.delete('/:id', protect, authorize('admin'), deleteReview);

module.exports = router;
