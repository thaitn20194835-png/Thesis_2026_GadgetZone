const router = require('express').Router();
const { getAll, getById, create, update, delete: deleteCategory } = require('../controllers/category.controller');
const { protect, authorize } = require('../middleware/auth');

router.get('/', getAll);
router.get('/:id', getById);
router.post('/', protect, authorize('admin'), create);
router.put('/:id', protect, authorize('admin'), update);
router.delete('/:id', protect, authorize('admin'), deleteCategory);

module.exports = router;
