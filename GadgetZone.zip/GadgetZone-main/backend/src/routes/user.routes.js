const router = require('express').Router();
const { getAll, toggleActive, getStats } = require('../controllers/user.controller');
const { protect, authorize } = require('../middleware/auth');

router.use(protect, authorize('admin'));
router.get('/', getAll);
router.get('/stats', getStats);
router.put('/:id/toggle-active', toggleActive);

module.exports = router;
