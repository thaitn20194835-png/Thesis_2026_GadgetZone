const router = require('express').Router();
const { uploadImage, deleteImage } = require('../controllers/upload.controller');
const { protect, authorize } = require('../middleware/auth');
const upload = require('../middleware/upload');

router.post('/', protect, authorize('admin'), upload.single('image'), uploadImage);
router.post('/delete', protect, authorize('admin'), deleteImage);

module.exports = router;
