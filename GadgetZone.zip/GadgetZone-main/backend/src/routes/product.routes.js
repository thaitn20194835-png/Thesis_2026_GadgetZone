const router = require('express').Router();
const { getAll, getById, getBySlug, create, update, delete: deleteProduct, adminGetAll } = require('../controllers/product.controller');
const { protect, authorize } = require('../middleware/auth');

router.get('/', getAll);
router.get('/admin/all', protect, authorize('admin'), adminGetAll);
router.get('/slug/:slug', getBySlug);
router.get('/:id', getById);
router.post('/', protect, authorize('admin'), create);
router.put('/:id', protect, authorize('admin'), update);
router.delete('/:id', protect, authorize('admin'), deleteProduct);

module.exports = router;
