const router = require('express').Router();
const c = require('../controllers/newsComment.controller');
const { protect, authorize } = require('../middleware/auth');

router.get('/news/:newsId', c.getByNews);
router.post('/', protect, c.create);

router.get('/admin/all', protect, authorize('admin'), c.adminGetAll);
router.put('/:id/approve', protect, authorize('admin'), c.toggleApprove);
router.delete('/:id', protect, authorize('admin'), c.remove);

module.exports = router;
