const router = require('express').Router();
const { createVnpayUrl, vnpayReturn } = require('../controllers/payment.controller');
const { protect } = require('../middleware/auth');

router.post('/vnpay/create', protect, createVnpayUrl);
router.get('/vnpay/return', vnpayReturn);

module.exports = router;
