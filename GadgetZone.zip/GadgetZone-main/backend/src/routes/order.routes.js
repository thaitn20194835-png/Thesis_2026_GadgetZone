const router = require('express').Router();
const {
  createOrder, getMyOrders, getOrderById, getAllOrders,
  updateOrderStatus, getStats, getStatsAdvanced,
} = require('../controllers/order.controller');
const { protect, authorize } = require('../middleware/auth');

router.use(protect);
router.post('/', createOrder);
router.get('/my-orders', getMyOrders);
router.get('/admin/all', authorize('admin'), getAllOrders);
router.get('/admin/stats', authorize('admin'), getStats);
router.get('/admin/stats/advanced', authorize('admin'), getStatsAdvanced);
router.get('/:id', getOrderById);
router.put('/:id/status', authorize('admin'), updateOrderStatus);

module.exports = router;
