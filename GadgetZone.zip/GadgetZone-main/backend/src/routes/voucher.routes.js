const router = require('express').Router();
const c = require('../controllers/voucher.controller');
const { protect, authorize } = require('../middleware/auth');

router.get('/active', c.getActive);
router.post('/verify', protect, c.verify);

router.get('/admin/all', protect, authorize('admin'), c.adminGetAll);
router.post('/', protect, authorize('admin'), c.create);
router.put('/:id', protect, authorize('admin'), c.update);
router.delete('/:id', protect, authorize('admin'), c.remove);

module.exports = router;
