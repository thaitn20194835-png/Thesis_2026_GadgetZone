const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

// Đọc tham số dòng lệnh: --from=<folder>  --drop  --yes
const args = process.argv.slice(2);
const fromArg = args.find((a) => a.startsWith('--from='));
const fromFolder = fromArg ? fromArg.split('=')[1] : 'latest';
const drop = args.includes('--drop');
const skipConfirm = args.includes('--yes') || args.includes('-y');

const DUMP_DIR = path.isAbsolute(fromFolder)
  ? fromFolder
  : path.join(__dirname, '..', '..', 'dump', fromFolder);

(async () => {
  if (!fs.existsSync(DUMP_DIR)) {
    console.error(`❌ Không tìm thấy thư mục: ${DUMP_DIR}`);
    console.error(`   Dùng: npm run db:import -- --from=<tên folder trong dump/>`);
    process.exit(1);
  }

  const files = fs.readdirSync(DUMP_DIR).filter((f) => f.endsWith('.json') && f !== '_meta.json');
  if (!files.length) {
    console.error(`❌ Không có file .json nào trong ${DUMP_DIR}`);
    process.exit(1);
  }

  console.log(`📥 Import từ: ${DUMP_DIR}`);
  console.log(`📂 Số collection: ${files.length}`);
  console.log(`⚠️  Mode: ${drop ? 'DROP & REPLACE (xóa hết rồi import)' : 'INSERT (giữ data cũ, thêm mới)'}`);

  const metaPath = path.join(DUMP_DIR, '_meta.json');
  if (fs.existsSync(metaPath)) {
    const meta = JSON.parse(fs.readFileSync(metaPath, 'utf8'));
    console.log(`📅 Snapshot tạo lúc: ${meta.exportedAt}`);
    console.log(`🗄️  DB nguồn: ${meta.database}`);
  }

  if (drop && !skipConfirm) {
    console.log('\n⚠️  CẢNH BÁO: --drop sẽ XÓA HẾT data hiện tại trong các collection này!');
    console.log('   Thêm cờ --yes để xác nhận, hoặc bỏ --drop để chỉ insert.');
    process.exit(1);
  }

  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log(`\n✓ Connected: ${mongoose.connection.db.databaseName}\n`);

    let totalInserted = 0;
    for (const file of files) {
      const coll = path.basename(file, '.json');
      const docs = JSON.parse(fs.readFileSync(path.join(DUMP_DIR, file), 'utf8'));
      if (!Array.isArray(docs) || docs.length === 0) {
        console.log(`  ⊘ ${coll.padEnd(18)} → file trống, bỏ qua`);
        continue;
      }

      // Convert string IDs back to ObjectId, dates back to Date
      const restored = docs.map((d) => restoreTypes(d));

      const collection = mongoose.connection.db.collection(coll);
      if (drop) await collection.deleteMany({});

      const res = await collection.insertMany(restored, { ordered: false });
      totalInserted += res.insertedCount;
      console.log(`  ✓ ${coll.padEnd(18)} → ${String(res.insertedCount).padStart(4)} docs`);
    }

    console.log(`\n✅ Hoàn tất: ${totalInserted} documents đã import`);
    process.exit(0);
  } catch (err) {
    console.error('❌ Import lỗi:', err.message);
    process.exit(1);
  }
})();

function restoreTypes(obj) {
  if (obj === null || typeof obj !== 'object') return obj;
  if (Array.isArray(obj)) return obj.map(restoreTypes);

  const out = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v === null || v === undefined) { out[k] = v; continue; }
    if (typeof v === 'string') {
      // ObjectId hex (24 chars)
      if (/^[0-9a-fA-F]{24}$/.test(v) && (k === '_id' || k.endsWith('Id') || k === 'user' || k === 'product' || k === 'category' || k === 'brand' || k === 'supplier' || k === 'news' || k === 'by')) {
        out[k] = new mongoose.Types.ObjectId(v);
        continue;
      }
      // ISO Date
      if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}/.test(v)) {
        const d = new Date(v);
        if (!isNaN(d.getTime())) { out[k] = d; continue; }
      }
    }
    if (typeof v === 'object') { out[k] = restoreTypes(v); continue; }
    out[k] = v;
  }
  return out;
}
