const fs = require('fs');
const path = require('path');

const dumpDir = path.join(__dirname, '..', '..', 'dump');

if (!fs.existsSync(dumpDir)) {
  console.log('Chưa có dump nào. Chạy: npm run db:export');
  process.exit(0);
}

const folders = fs.readdirSync(dumpDir)
  .filter((f) => fs.statSync(path.join(dumpDir, f)).isDirectory())
  .sort()
  .reverse();

if (!folders.length) { console.log('Chưa có dump nào'); process.exit(0); }

console.log('📂 Các bản dump hiện có:\n');
for (const f of folders) {
  let docs = '';
  const meta = path.join(dumpDir, f, '_meta.json');
  if (fs.existsSync(meta)) {
    try {
      const m = JSON.parse(fs.readFileSync(meta, 'utf8'));
      docs = ` (${m.totalDocuments} docs)`;
    } catch {}
  }
  const tag = f === 'latest' ? '  [LATEST]' : '';
  console.log(`  • ${f}${docs}${tag}`);
}
console.log(`\nDùng:  npm run db:import -- --from=<tên-folder>`);
console.log(`Hoặc:  npm run db:import:fresh -- --from=<tên-folder>  (xóa rồi import)`);
