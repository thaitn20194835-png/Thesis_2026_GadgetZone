const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
const dotenv = require('dotenv');

dotenv.config();

const COLLECTIONS = [
  'users', 'categories', 'brands', 'products', 'news',
  'suppliers', 'vouchers', 'reviews', 'newscomments', 'orders', 'carts', 'wishlists',
];

// Folder lưu dump: backend/dump/<timestamp>/<collection>.json
const ts = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
const DUMP_DIR = path.join(__dirname, '..', '..', 'dump', ts);
const LATEST_DIR = path.join(__dirname, '..', '..', 'dump', 'latest');

(async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('✓ Connected to MongoDB');
    console.log(`📦 Export đến: ${DUMP_DIR}\n`);

    fs.mkdirSync(DUMP_DIR, { recursive: true });
    fs.mkdirSync(LATEST_DIR, { recursive: true });

    const db = mongoose.connection.db;
    const existing = await db.listCollections().toArray();
    const existingNames = existing.map((c) => c.name);

    let totalDocs = 0;
    const summary = {};

    for (const coll of COLLECTIONS) {
      if (!existingNames.includes(coll)) {
        console.log(`  ⊘ ${coll.padEnd(18)} → không tồn tại, bỏ qua`);
        continue;
      }
      const docs = await db.collection(coll).find({}).toArray();
      const file = path.join(DUMP_DIR, `${coll}.json`);
      const fileLatest = path.join(LATEST_DIR, `${coll}.json`);
      const json = JSON.stringify(docs, null, 2);
      fs.writeFileSync(file, json, 'utf8');
      fs.writeFileSync(fileLatest, json, 'utf8');
      totalDocs += docs.length;
      summary[coll] = docs.length;
      console.log(`  ✓ ${coll.padEnd(18)} → ${String(docs.length).padStart(4)} docs`);
    }

    // Metadata
    const meta = {
      exportedAt: new Date().toISOString(),
      database: db.databaseName,
      totalDocuments: totalDocs,
      collections: summary,
    };
    fs.writeFileSync(path.join(DUMP_DIR, '_meta.json'), JSON.stringify(meta, null, 2));
    fs.writeFileSync(path.join(LATEST_DIR, '_meta.json'), JSON.stringify(meta, null, 2));

    console.log(`\n✅ Hoàn tất: ${totalDocs} documents`);
    console.log(`   Snapshot: dump/${ts}/`);
    console.log(`   Latest:   dump/latest/`);
    process.exit(0);
  } catch (err) {
    console.error('❌ Export lỗi:', err.message);
    process.exit(1);
  }
})();
