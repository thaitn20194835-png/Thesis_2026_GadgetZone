const mongoose = require('mongoose');
const dotenv = require('dotenv');

dotenv.config();

const User = require('../models/User');
const Category = require('../models/Category');
const Brand = require('../models/Brand');
const Product = require('../models/Product');
const News = require('../models/News');
const Supplier = require('../models/Supplier');
const Voucher = require('../models/Voucher');
const Review = require('../models/Review');
const NewsComment = require('../models/NewsComment');
const Order = require('../models/Order');

// ============================================================
// REAL IMAGE URLS - crawled from public CDN của các nhà bán lẻ VN
// Sử dụng CellphoneS CDN (công khai), FPT Shop CDN, và Unsplash
// ============================================================

// Logo thương hiệu - dùng simpleicons.org CDN (verified 200 OK, không chặn)
const BRAND_LOGOS = {
  Apple: 'https://cdn.simpleicons.org/apple/000000',
  Samsung: 'https://cdn.simpleicons.org/samsung/000000',
  Xiaomi: 'https://cdn.simpleicons.org/xiaomi/000000',
  OPPO: 'https://cdn.simpleicons.org/oppo/000000',
  Dell: 'https://cdn.simpleicons.org/dell/000000',
  ASUS: 'https://cdn.simpleicons.org/asus/000000',
  Lenovo: 'https://cdn.simpleicons.org/lenovo/000000',
  Sony: 'https://cdn.simpleicons.org/sony/000000',
  JBL: 'https://cdn.simpleicons.org/jbl/000000',
  Huawei: 'https://cdn.simpleicons.org/huawei/000000',
};

// Ảnh sản phẩm - 100% Unsplash (online URL, không upload, ổn định lâu dài)
const PRODUCT_IMAGES = {
  iphone15ProMax: [
    'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=800&q=85',
    'https://images.unsplash.com/photo-1592286927505-1def25115558?w=800&q=85',
  ],
  s24Ultra: [
    'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=800&q=85',
    'https://images.unsplash.com/photo-1592890288564-76628a30a657?w=800&q=85',
    'https://images.unsplash.com/photo-1565849904461-04a58ad377e0?w=800&q=85',
  ],
  xiaomi14: [
    'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=800&q=85',
    'https://images.unsplash.com/photo-1616348436168-de43ad0db179?w=800&q=85',
  ],
  oppoFindX7: [
    'https://images.unsplash.com/photo-1567581935884-3349723552ca?w=800&q=85',
    'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=800&q=85',
  ],
  iphone15: [
    'https://images.unsplash.com/photo-1592286927505-1def25115558?w=800&q=85',
    'https://images.unsplash.com/photo-1605236453806-6ff36851218e?w=800&q=85',
  ],
  macbookM3: [
    'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=800&q=85',
    'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=800&q=85',
    'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=800&q=85',
  ],
  dellXPS: [
    'https://images.unsplash.com/photo-1593642632559-0c6d3fc62b89?w=800&q=85',
    'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=800&q=85',
  ],
  asusROG: [
    'https://images.unsplash.com/photo-1603302576837-37561b2e2302?w=800&q=85',
    'https://images.unsplash.com/photo-1593640408182-31c70c8268f5?w=800&q=85',
  ],
  lenovoLegion: [
    'https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=800&q=85',
    'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=800&q=85',
  ],
  ipadProM4: [
    'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=800&q=85',
    'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=800&q=85',
  ],
  ipadAir: [
    'https://images.unsplash.com/photo-1561154464-82e9adf32764?w=800&q=85',
    'https://images.unsplash.com/photo-1557825835-70d97c4aa567?w=800&q=85',
  ],
  tabS9FE: [
    'https://images.unsplash.com/photo-1623126908029-58cb08a2b272?w=800&q=85',
    'https://images.unsplash.com/photo-1542751110-97427bbecf20?w=800&q=85',
  ],
  appleWatch9: [
    'https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800&q=85',
    'https://images.unsplash.com/photo-1551816230-ef5deaed4a26?w=800&q=85',
  ],
  galaxyWatch6: [
    'https://images.unsplash.com/photo-1617043786394-f977fa12eddf?w=800&q=85',
    'https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?w=800&q=85',
  ],
  jblCharge5: [
    'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=800&q=85',
    'https://images.unsplash.com/photo-1589003077984-894e133dabab?w=800&q=85',
  ],
  sonyXM5: [
    'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=800&q=85',
    'https://images.unsplash.com/photo-1545127398-14699f92334b?w=800&q=85',
  ],
  airpodsPro2: [
    'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=800&q=85',
    'https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?w=800&q=85',
  ],
  magsafeCharger: [
    'https://images.unsplash.com/photo-1620207418302-439b387441b0?w=800&q=85',
  ],
};

// ============================================================
const seedData = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log('Connected to MongoDB');

    await User.deleteMany({});
    await Category.deleteMany({});
    await Brand.deleteMany({});
    await Product.deleteMany({});
    await News.deleteMany({});
    await Supplier.deleteMany({});
    await Voucher.deleteMany({});
    await Review.deleteMany({});
    await NewsComment.deleteMany({});
    await Order.deleteMany({});

    // ===== Users =====
    const users = await User.create([
      { name: 'Admin GadgetZone', email: 'admin@gadgetzone.vn', password: 'admin123', phone: '0901234567', role: 'admin' },
      { name: 'Nguyễn Văn A', email: 'nguyenvana@gmail.com', password: '123456', phone: '0912345678', address: '73 Quang Trung, Hà Đông, Hà Nội', role: 'customer' },
      { name: 'Trần Thị B', email: 'tranthib@gmail.com', password: '123456', phone: '0923456789', address: '128 Cầu Giấy, Cầu Giấy, Hà Nội', role: 'customer' },
    ]);
    console.log('Seeded users:', users.length);

    // ===== Categories =====
    const categories = await Category.create([
      { name: 'Điện thoại', description: 'Smartphone từ các thương hiệu hàng đầu thế giới' },
      { name: 'Laptop', description: 'Laptop văn phòng, gaming và thiết kế đồ họa' },
      { name: 'Tablet', description: 'Máy tính bảng cho công việc và giải trí' },
      { name: 'Đồng hồ thông minh', description: 'Smartwatch theo dõi sức khỏe và phong cách' },
      { name: 'Âm thanh', description: 'Tai nghe, loa Bluetooth, soundbar cao cấp' },
      { name: 'Phụ kiện', description: 'Sạc, cáp, ốp lưng, dock và nhiều phụ kiện khác' },
    ]);
    console.log('Seeded categories:', categories.length);
    const catMap = {};
    categories.forEach(c => { catMap[c.name] = c._id; });

    // ===== Brands =====
    const brandNames = ['Apple', 'Samsung', 'Xiaomi', 'OPPO', 'Dell', 'ASUS', 'Lenovo', 'Sony', 'JBL', 'Huawei'];
    const brands = await Brand.create(
      brandNames.map(n => ({ name: n, logo: BRAND_LOGOS[n] || '' }))
    );
    console.log('Seeded brands:', brands.length);
    const brandMap = {};
    brands.forEach(b => { brandMap[b.name] = b._id; });

    // ===== Suppliers (NCC) =====
    const suppliers = await Supplier.create([
      {
        name: 'Công ty TNHH Apple Việt Nam',
        contactPerson: 'Nguyễn Hoàng Long',
        email: 'contact@apple.vn', phone: '028 3823 8888',
        address: 'Tòa nhà Lotte Center, 54 Liễu Giai, Ba Đình, Hà Nội',
        website: 'https://www.apple.com/vn',
        taxCode: '0314567890',
        logo: BRAND_LOGOS.Apple,
        brands: [brandMap['Apple']],
        note: 'Đối tác chính thức Apple Authorized Reseller',
        isActive: true,
      },
      {
        name: 'Samsung Vina Electronics',
        contactPerson: 'Trần Minh Khoa',
        email: 'b2b@samsung.com.vn', phone: '028 3744 5678',
        address: 'Keangnam Hanoi Landmark Tower, Phạm Hùng, Nam Từ Liêm, Hà Nội',
        website: 'https://www.samsung.com/vn',
        taxCode: '0301234567',
        logo: BRAND_LOGOS.Samsung,
        brands: [brandMap['Samsung']],
        note: 'NCC chính thức Samsung Galaxy & Watch',
        isActive: true,
      },
      {
        name: 'Xiaomi Việt Nam (Digiworld)',
        contactPerson: 'Lê Thị Hằng',
        email: 'partner@digiworld.com.vn', phone: '028 7777 9999',
        address: '162 Hoàng Quốc Việt, Cầu Giấy, Hà Nội',
        website: 'https://digiworld.com.vn',
        taxCode: '0303456789',
        logo: BRAND_LOGOS.Xiaomi,
        brands: [brandMap['Xiaomi'], brandMap['OPPO']],
        note: 'Phân phối Xiaomi và OPPO khu vực phía Nam',
        isActive: true,
      },
      {
        name: 'PC Synnex FPT',
        contactPerson: 'Phạm Văn Hùng',
        email: 'b2b@synnexfpt.com', phone: '024 3974 1111',
        address: 'Tầng 22, Hanoi Tower, 49 Hai Bà Trưng, Hà Nội',
        website: 'https://synnexfpt.com',
        taxCode: '0100686275',
        logo: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/1d/FPT_logo_2010.svg/200px-FPT_logo_2010.svg.png',
        brands: [brandMap['Dell'], brandMap['ASUS'], brandMap['Lenovo']],
        note: 'NCC laptop lớn nhất Việt Nam',
        isActive: true,
      },
      {
        name: 'Sony Electronics Vietnam',
        contactPerson: 'Hoàng Anh Tuấn',
        email: 'sales@sony.com.vn', phone: '028 3825 6789',
        address: 'Tầng 17, Vincom Center Bà Triệu, 191 Bà Triệu, Hai Bà Trưng, Hà Nội',
        website: 'https://www.sony.com.vn',
        taxCode: '0303654321',
        logo: BRAND_LOGOS.Sony,
        brands: [brandMap['Sony']],
        note: 'Tai nghe, loa, máy ảnh chính hãng',
        isActive: true,
      },
      {
        name: 'Harman International (JBL)',
        contactPerson: 'Nguyễn Thị Linh',
        email: 'vn@harman.com', phone: '028 3911 2233',
        address: 'Tòa Charmvit, 117 Trần Duy Hưng, Cầu Giấy, Hà Nội',
        website: 'https://vn.jbl.com',
        taxCode: '0312987654',
        logo: BRAND_LOGOS.JBL,
        brands: [brandMap['JBL']],
        note: 'Phân phối loa JBL khu vực Đông Nam Á',
        isActive: true,
      },
    ]);
    console.log('Seeded suppliers:', suppliers.length);

    // Map brand → supplier để gán vào products
    const supplierByBrand = {};
    suppliers.forEach((s) => {
      s.brands.forEach((bId) => { supplierByBrand[bId.toString()] = s._id; });
    });

    // ===== Products =====
    const products = await Product.create([
      {
        name: 'iPhone 15 Pro Max 256GB - Titan Tự Nhiên',
        description: 'iPhone 15 Pro Max là chiếc flagship đỉnh cao của Apple với chip A17 Pro được sản xuất trên tiến trình 3nm, mang lại hiệu năng vượt trội và tiết kiệm pin tốt hơn. Khung viền titanium siêu nhẹ, bền bỉ và sang trọng. Hệ thống camera 48MP với ống kính tetraprism zoom quang 5x cho chất lượng ảnh chuyên nghiệp. Cổng USB-C tốc độ cao chuẩn USB 3 hỗ trợ truyền tải dữ liệu nhanh chóng.',
        price: 34990000,
        salePrice: 29990000,
        images: PRODUCT_IMAGES.iphone15ProMax,
        category: catMap['Điện thoại'],
        brand: brandMap['Apple'],
        stock: 25,
        specs: {
          'Màn hình': '6.7 inch Super Retina XDR OLED, 120Hz ProMotion',
          'Chip xử lý': 'Apple A17 Pro (3nm)',
          'RAM': '8 GB',
          'Bộ nhớ trong': '256 GB',
          'Camera sau': '48MP chính + 12MP siêu rộng + 12MP tele 5x',
          'Camera trước': '12MP TrueDepth',
          'Pin': '4422 mAh, sạc nhanh 27W, sạc không dây MagSafe 15W',
          'Kết nối': 'USB-C 3.0, 5G, Wi-Fi 6E',
          'Chất liệu': 'Khung Titanium, mặt lưng kính nhám',
        },
        isFeatured: true,
        rating: 4.9,
        numReviews: 218,
      },
      {
        name: 'Samsung Galaxy S24 Ultra 12GB/256GB - Titan Đen',
        description: 'Galaxy S24 Ultra là smartphone Android đỉnh cao với khung viền Titanium, kính Gorilla Armor chống lóa và chống xước. Trải nghiệm Galaxy AI giúp dịch trực tiếp cuộc gọi, tóm tắt văn bản, chỉnh sửa ảnh thông minh. Camera chính 200MP cho ảnh sắc nét đến từng chi tiết, zoom quang học 5x và zoom số AI lên đến 100x. S Pen tích hợp linh hoạt cho ghi chú và sáng tạo.',
        price: 33990000,
        salePrice: 27990000,
        images: PRODUCT_IMAGES.s24Ultra,
        category: catMap['Điện thoại'],
        brand: brandMap['Samsung'],
        stock: 30,
        specs: {
          'Màn hình': '6.8 inch Dynamic AMOLED 2X, QHD+, 120Hz',
          'Chip xử lý': 'Snapdragon 8 Gen 3 for Galaxy',
          'RAM': '12 GB',
          'Bộ nhớ trong': '256 GB',
          'Camera sau': '200MP + 12MP UW + 50MP tele 5x + 10MP tele 3x',
          'Camera trước': '12MP',
          'Pin': '5000 mAh, sạc nhanh 45W',
          'Kết nối': 'USB-C, 5G, Wi-Fi 7',
          'Chất liệu': 'Khung Titanium, kính Gorilla Armor',
        },
        isFeatured: true,
        rating: 4.8,
        numReviews: 156,
      },
      {
        name: 'Xiaomi 14 Ultra 16GB/512GB',
        description: 'Xiaomi 14 Ultra mang đến trải nghiệm nhiếp ảnh chuyên nghiệp với hệ thống camera Leica Summilux, cảm biến 1 inch LYT-900. Chip Snapdragon 8 Gen 3 mạnh mẽ kết hợp HyperOS mượt mà. Sạc HyperCharge 90W có dây và 80W không dây sạc đầy chỉ trong 30 phút.',
        price: 23990000,
        salePrice: 21490000,
        images: PRODUCT_IMAGES.xiaomi14,
        category: catMap['Điện thoại'],
        brand: brandMap['Xiaomi'],
        stock: 20,
        specs: {
          'Màn hình': '6.73 inch LTPO AMOLED, 120Hz, 3000 nits',
          'Chip xử lý': 'Snapdragon 8 Gen 3',
          'RAM': '16 GB',
          'Bộ nhớ trong': '512 GB',
          'Camera sau': '50MP Leica Summilux + 50MP UW + 50MP tele + 50MP periscope',
          'Pin': '5300 mAh, HyperCharge 90W',
        },
        isFeatured: true,
        rating: 4.7,
        numReviews: 87,
      },
      {
        name: 'OPPO Find X7 Ultra 16GB/512GB',
        description: 'OPPO Find X7 Ultra với hệ thống camera kép Hasselblad độc đáo, hai cảm biến tele cho khả năng chụp xa vượt trội. Thiết kế cao cấp, mặt lưng da pha lê độc quyền.',
        price: 24990000,
        salePrice: 0,
        images: PRODUCT_IMAGES.oppoFindX7,
        category: catMap['Điện thoại'],
        brand: brandMap['OPPO'],
        stock: 15,
        specs: {
          'Màn hình': '6.82 inch AMOLED LTPO, 120Hz',
          'Chip xử lý': 'Snapdragon 8 Gen 3',
          'RAM': '16 GB',
          'Bộ nhớ trong': '512 GB',
          'Pin': '5000 mAh, sạc 100W',
        },
        isFeatured: false,
        rating: 4.6,
        numReviews: 42,
      },
      {
        name: 'iPhone 15 128GB - Hồng',
        description: 'iPhone 15 với thiết kế Dynamic Island, chip A16 Bionic, camera 48MP và cổng USB-C lần đầu tiên xuất hiện trên iPhone. Mặt lưng kính nhám sang trọng, viền nhôm cao cấp.',
        price: 22990000,
        salePrice: 19990000,
        images: PRODUCT_IMAGES.iphone15,
        category: catMap['Điện thoại'],
        brand: brandMap['Apple'],
        stock: 40,
        specs: {
          'Màn hình': '6.1 inch Super Retina XDR OLED',
          'Chip xử lý': 'Apple A16 Bionic',
          'RAM': '6 GB',
          'Bộ nhớ trong': '128 GB',
          'Camera sau': '48MP + 12MP siêu rộng',
          'Pin': '3349 mAh, sạc 20W, MagSafe 15W',
        },
        isFeatured: true,
        rating: 4.8,
        numReviews: 245,
      },
      {
        name: 'MacBook Pro 14 inch M3 Pro 18GB/512GB',
        description: 'MacBook Pro 14 inch trang bị chip Apple M3 Pro mới với CPU 11 nhân, GPU 14 nhân mạnh mẽ. Màn hình Liquid Retina XDR mini-LED 120Hz ProMotion cho trải nghiệm hình ảnh đỉnh cao. Pin lên đến 18 giờ, đủ sức xử lý mọi tác vụ chuyên nghiệp từ thiết kế, lập trình đến dựng phim 4K.',
        price: 49990000,
        salePrice: 45990000,
        images: PRODUCT_IMAGES.macbookM3,
        category: catMap['Laptop'],
        brand: brandMap['Apple'],
        stock: 12,
        specs: {
          'Màn hình': '14.2 inch Liquid Retina XDR, 120Hz, 1000 nits',
          'Chip': 'Apple M3 Pro (11 CPU / 14 GPU)',
          'RAM': '18 GB Unified Memory',
          'SSD': '512 GB',
          'Pin': '70Wh, lên đến 18 giờ',
          'Cổng kết nối': '3x Thunderbolt 4, HDMI, SDXC, MagSafe 3',
          'Trọng lượng': '1.61 kg',
        },
        isFeatured: true,
        rating: 4.9,
        numReviews: 132,
      },
      {
        name: 'Dell XPS 15 9530 i7-13700H',
        description: 'Dell XPS 15 với màn hình OLED 3.5K độ chính xác màu 100% DCI-P3, viền siêu mỏng InfinityEdge. Hiệu năng mạnh mẽ với Core i7-13700H và RTX 4050. Vỏ nhôm CNC cao cấp, bàn phím và touchpad đẳng cấp.',
        price: 42990000,
        salePrice: 38990000,
        images: PRODUCT_IMAGES.dellXPS,
        category: catMap['Laptop'],
        brand: brandMap['Dell'],
        stock: 8,
        specs: {
          'Màn hình': '15.6 inch OLED 3.5K (3456x2160), 100% DCI-P3',
          'CPU': 'Intel Core i7-13700H',
          'RAM': '16 GB DDR5',
          'SSD': '512 GB NVMe',
          'GPU': 'NVIDIA RTX 4050 6GB',
          'Pin': '86Wh, sạc nhanh',
          'Trọng lượng': '1.86 kg',
        },
        isFeatured: true,
        rating: 4.7,
        numReviews: 64,
      },
      {
        name: 'ASUS ROG Strix G16 2024 Core Ultra 9',
        description: 'Laptop gaming ROG Strix G16 thế hệ 2024 với Intel Core Ultra 9 185H, RTX 4070 8GB, màn hình 240Hz QHD+. Hệ thống tản nhiệt tri-fan với Liquid Metal mang đến hiệu năng ổn định trong các phiên gaming dài.',
        price: 42990000,
        salePrice: 39490000,
        images: PRODUCT_IMAGES.asusROG,
        category: catMap['Laptop'],
        brand: brandMap['ASUS'],
        stock: 12,
        specs: {
          'Màn hình': '16 inch QHD+ 2560x1600, 240Hz, 100% DCI-P3',
          'CPU': 'Intel Core Ultra 9 185H',
          'RAM': '16 GB DDR5-5600',
          'SSD': '1 TB NVMe',
          'GPU': 'NVIDIA RTX 4070 8GB',
          'Pin': '90Wh',
        },
        isFeatured: true,
        rating: 4.8,
        numReviews: 98,
      },
      {
        name: 'Lenovo Legion 5 Pro 2024 RTX 4060',
        description: 'Lenovo Legion 5 Pro với AMD Ryzen 7 8845HS, RTX 4060, màn hình PureSight 165Hz. Bàn phím TrueStrike chuyên gaming, hệ thống Coldfront 5.0 tản nhiệt cực mát.',
        price: 35990000,
        salePrice: 32990000,
        images: PRODUCT_IMAGES.lenovoLegion,
        category: catMap['Laptop'],
        brand: brandMap['Lenovo'],
        stock: 15,
        specs: {
          'Màn hình': '16 inch WQXGA 165Hz',
          'CPU': 'AMD Ryzen 7 8845HS',
          'RAM': '16 GB DDR5',
          'SSD': '512 GB',
          'GPU': 'NVIDIA RTX 4060 8GB',
        },
        isFeatured: false,
        rating: 4.6,
        numReviews: 51,
      },
      {
        name: 'iPad Pro M4 11 inch 256GB Wi-Fi',
        description: 'iPad Pro M4 mỏng nhất từ trước đến nay (5.3mm), chip M4 mạnh mẽ với Neural Engine 38 TOPS. Màn hình Ultra Retina XDR Tandem OLED siêu sáng, độ tương phản 1.000.000:1. Tương thích Apple Pencil Pro với cảm biến lực vặn và tìm chính xác.',
        price: 28990000,
        salePrice: 26990000,
        images: PRODUCT_IMAGES.ipadProM4,
        category: catMap['Tablet'],
        brand: brandMap['Apple'],
        stock: 18,
        specs: {
          'Màn hình': '11 inch Ultra Retina XDR Tandem OLED, 120Hz',
          'Chip': 'Apple M4',
          'RAM': '8 GB',
          'Bộ nhớ': '256 GB',
          'Camera': '12MP rộng + LiDAR',
          'Pin': 'Lên đến 10 giờ',
          'Kết nối': 'Thunderbolt 4 / USB-C',
        },
        isFeatured: true,
        rating: 4.9,
        numReviews: 87,
      },
      {
        name: 'iPad Air M2 11 inch 128GB Wi-Fi - Xanh',
        description: 'iPad Air M2 mới với chip M2 mạnh mẽ, màn hình Liquid Retina 11 inch, hỗ trợ Apple Pencil Pro. Lựa chọn cân bằng giữa hiệu năng và giá thành cho học tập, làm việc và sáng tạo.',
        price: 18990000,
        salePrice: 16990000,
        images: PRODUCT_IMAGES.ipadAir,
        category: catMap['Tablet'],
        brand: brandMap['Apple'],
        stock: 25,
        specs: {
          'Màn hình': '11 inch Liquid Retina',
          'Chip': 'Apple M2',
          'RAM': '8 GB',
          'Bộ nhớ': '128 GB',
        },
        isFeatured: true,
        rating: 4.7,
        numReviews: 115,
      },
      {
        name: 'Samsung Galaxy Tab S9 FE 128GB Wi-Fi',
        description: 'Galaxy Tab S9 FE đi kèm bút S Pen, màn hình 10.9 inch chống nước IP68. Chip Exynos 1380 mượt mà, pin 8000mAh dùng cả ngày dài.',
        price: 9990000,
        salePrice: 8490000,
        images: PRODUCT_IMAGES.tabS9FE,
        category: catMap['Tablet'],
        brand: brandMap['Samsung'],
        stock: 22,
        specs: {
          'Màn hình': '10.9 inch TFT LCD, 90Hz',
          'Chip': 'Exynos 1380',
          'RAM': '6 GB',
          'Bộ nhớ': '128 GB',
          'Pin': '8000 mAh',
        },
        isFeatured: false,
        rating: 4.5,
        numReviews: 68,
      },
      {
        name: 'Apple Watch Series 9 GPS 45mm Bạc',
        description: 'Apple Watch Series 9 với chip S9 SiP, tính năng Double Tap mới mẻ, màn hình sáng gấp đôi (2000 nits). Cảm biến nhịp tim, oxy máu, ECG và phát hiện ngã chính xác.',
        price: 11490000,
        salePrice: 9990000,
        images: PRODUCT_IMAGES.appleWatch9,
        category: catMap['Đồng hồ thông minh'],
        brand: brandMap['Apple'],
        stock: 30,
        specs: {
          'Màn hình': '45mm Always-On Retina LTPO OLED',
          'Chip': 'Apple S9 SiP',
          'Kháng nước': 'WR50',
          'Pin': 'Lên đến 18 giờ (36 giờ chế độ tiết kiệm)',
        },
        isFeatured: true,
        rating: 4.8,
        numReviews: 173,
      },
      {
        name: 'Samsung Galaxy Watch 6 Classic 43mm',
        description: 'Galaxy Watch 6 Classic với vành xoay vật lý đặc trưng quay trở lại. Màn hình Super AMOLED 1.3 inch sáng đẹp. Theo dõi giấc ngủ, nhịp tim, huyết áp toàn diện.',
        price: 8490000,
        salePrice: 6990000,
        images: PRODUCT_IMAGES.galaxyWatch6,
        category: catMap['Đồng hồ thông minh'],
        brand: brandMap['Samsung'],
        stock: 28,
        specs: {
          'Màn hình': '1.3 inch Super AMOLED',
          'Chip': 'Exynos W930',
          'Kháng nước': 'IP68 / 5ATM',
        },
        isFeatured: false,
        rating: 4.6,
        numReviews: 54,
      },
      {
        name: 'Loa Bluetooth JBL Charge 5',
        description: 'JBL Charge 5 với âm bass sâu mạnh đặc trưng, công suất 40W, kháng nước IP67. Pin 20 giờ và có thể sạc ngược cho điện thoại. Kết nối PartyBoost với các loa JBL khác.',
        price: 3690000,
        salePrice: 2790000,
        images: PRODUCT_IMAGES.jblCharge5,
        category: catMap['Âm thanh'],
        brand: brandMap['JBL'],
        stock: 50,
        specs: {
          'Công suất': '40W RMS',
          'Driver': '52x90mm + 1 tweeter',
          'Pin': '20 giờ',
          'Kháng nước': 'IP67',
          'Kết nối': 'Bluetooth 5.1, USB-C',
        },
        isFeatured: false,
        rating: 4.7,
        numReviews: 234,
      },
      {
        name: 'Tai nghe chống ồn Sony WH-1000XM5',
        description: 'Sony WH-1000XM5 - Top tai nghe chống ồn tốt nhất thế giới. Driver 30mm, công nghệ Hi-Res Audio Wireless với LDAC. Chống ồn ANC chủ động với 8 micro cùng chip xử lý V1. Pin 30 giờ, sạc nhanh 3 phút dùng 3 giờ.',
        price: 8490000,
        salePrice: 6990000,
        images: PRODUCT_IMAGES.sonyXM5,
        category: catMap['Âm thanh'],
        brand: brandMap['Sony'],
        stock: 25,
        specs: {
          'Driver': '30mm',
          'Pin': '30 giờ (40 giờ tắt ANC)',
          'Chống ồn': 'ANC chủ động + 8 micro',
          'Kết nối': 'Bluetooth 5.2, LDAC, jack 3.5mm',
          'Trọng lượng': '250g',
        },
        isFeatured: true,
        rating: 4.9,
        numReviews: 198,
      },
      {
        name: 'Apple AirPods Pro 2 USB-C',
        description: 'AirPods Pro 2 thế hệ mới với cổng USB-C, chip H2 cải tiến chống ồn chủ động vượt trội. Âm thanh không gian Spatial Audio cá nhân hóa, chế độ Adaptive Audio thông minh tự điều chỉnh theo môi trường.',
        price: 6490000,
        salePrice: 5290000,
        images: PRODUCT_IMAGES.airpodsPro2,
        category: catMap['Âm thanh'],
        brand: brandMap['Apple'],
        stock: 60,
        specs: {
          'Chip': 'Apple H2',
          'Pin': '6 giờ (30 giờ với hộp sạc)',
          'Chống ồn': 'ANC + Adaptive Audio',
          'Kết nối': 'Bluetooth 5.3, USB-C',
        },
        isFeatured: true,
        rating: 4.8,
        numReviews: 312,
      },
      {
        name: 'Sạc không dây MagSafe Apple 25W',
        description: 'Sạc không dây MagSafe chính hãng Apple công suất 25W, sạc nhanh cho iPhone 16 Pro / Pro Max. Thiết kế nam châm hít chính xác, cáp USB-C dài 1m.',
        price: 1290000,
        salePrice: 990000,
        images: PRODUCT_IMAGES.magsafeCharger,
        category: catMap['Phụ kiện'],
        brand: brandMap['Apple'],
        stock: 80,
        specs: {
          'Công suất': '25W',
          'Đầu cắm': 'USB-C',
          'Chiều dài cáp': '1m',
          'Tương thích': 'iPhone 12 trở lên',
        },
        isFeatured: false,
        rating: 4.6,
        numReviews: 145,
      },
    ]);
    console.log('Seeded products:', products.length);

    // Gán supplier cho từng product theo brand
    for (const p of products) {
      const supId = supplierByBrand[p.brand.toString()];
      if (supId) await Product.findByIdAndUpdate(p._id, { supplier: supId });
    }
    console.log('  → linked products to suppliers');

    // ===== News (Tin tức công nghệ) =====
    const news = await News.create([
      {
        title: 'iPhone 16 Pro Max chính thức ra mắt: Camera 48MP đột phá, chip A18 Pro',
        summary: 'Apple chính thức trình làng iPhone 16 Pro Max với chip A18 Pro tiến trình 3nm thế hệ 2, hệ thống camera 48MP mới và Apple Intelligence — bước tiến lớn của dòng iPhone Pro Max.',
        content: `Tại sự kiện "It\'s Glowtime" tổ chức tại Apple Park, Apple chính thức trình làng iPhone 16 Pro Max — chiếc smartphone cao cấp nhất của hãng với hàng loạt nâng cấp đáng giá.

**Chip A18 Pro: Hiệu năng vượt trội**
iPhone 16 Pro Max được trang bị chip A18 Pro mới sản xuất trên tiến trình 3nm thế hệ thứ hai của TSMC. Apple cho biết hiệu năng CPU cao hơn 15% và GPU nhanh hơn 20% so với A17 Pro. Đặc biệt, Neural Engine 16 nhân được tối ưu hóa cho các tác vụ Apple Intelligence — bộ tính năng AI on-device đầu tiên của Apple.

**Camera 48MP nâng cấp toàn diện**
Cảm biến chính 48MP Fusion mới có khả năng thu sáng tốt hơn 30%. Ống kính tetraprism zoom quang 5x giờ đây xuất hiện trên cả phiên bản Pro thường, không chỉ riêng Pro Max. Nút Camera Control mới ở cạnh phải cho phép thao tác chụp ảnh, zoom và chọn chế độ giống như máy ảnh chuyên nghiệp.

**Pin và sạc nhanh**
Thời lượng pin được Apple cải thiện lên đến 33 giờ phát video — dài nhất từ trước đến nay trên một chiếc iPhone. Sạc nhanh USB-C đạt 45W, sạc không dây MagSafe lên 25W giúp đầy 50% pin chỉ trong 30 phút.

**Giá bán tại Việt Nam**
iPhone 16 Pro Max có giá khởi điểm 34.990.000 đồng cho phiên bản 256GB và lên đến 53.990.000 đồng cho bản 1TB. Máy chính thức mở bán tại GadgetZone từ 27/09 với hàng loạt ưu đãi như giảm 5% cho khách hàng VIP, trả góp 0% qua thẻ tín dụng và quà tặng phụ kiện trị giá 2 triệu đồng.`,
        image: 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=1200&q=85',
        author: 'Admin GadgetZone',
        tags: ['iPhone', 'Apple', 'Ra mắt', 'A18 Pro'],
        isPublished: true,
      },
      {
        title: 'Galaxy AI và cuộc cách mạng AI on-device trên smartphone 2026',
        summary: 'Năm 2026 chứng kiến sự bùng nổ của AI tích hợp trực tiếp trên thiết bị. Từ Galaxy AI của Samsung đến Apple Intelligence, các hãng đua nhau mang trí tuệ nhân tạo về điện thoại.',
        content: `Trí tuệ nhân tạo on-device đang định hình lại trải nghiệm smartphone trong năm 2026. Khác với việc gửi dữ liệu lên cloud, AI on-device xử lý mọi tác vụ ngay trên thiết bị — bảo mật hơn, nhanh hơn và hoạt động cả khi không có Internet.

**Galaxy AI dẫn đầu xu hướng**
Samsung tiên phong với Galaxy AI ra mắt cùng dòng S24, sau đó mở rộng xuống cả các dòng A. Tính năng Live Translate dịch trực tiếp cuộc gọi điện thoại, Note Assist tóm tắt văn bản dài, và Generative Edit chỉnh sửa ảnh bằng AI đã trở thành tiêu chuẩn mới.

**Apple Intelligence — đáp trả từ Cupertino**
Apple ra mắt Apple Intelligence trên iOS 18 với cách tiếp cận khác biệt: ưu tiên xử lý on-device, chỉ chuyển lên Private Cloud Compute khi cần. Writing Tools, Image Playground và Genmoji là những tính năng nổi bật.

**Tác động đến chip xử lý**
Cuộc đua AI khiến NPU (Neural Processing Unit) trở thành chỉ số quan trọng ngang ngửa CPU/GPU. Snapdragon 8 Gen 3 đạt 45 TOPS, Apple A17 Pro đạt 35 TOPS, và Apple M4 đạt 38 TOPS — đủ sức chạy các mô hình LLM 7 tỷ tham số ngay trên thiết bị.

**Tương lai ra sao?**
Các chuyên gia dự báo đến cuối 2026, hơn 75% smartphone cao cấp sẽ tích hợp AI on-device. Người dùng sẽ có một trợ lý cá nhân hiểu mình thực sự — biết thói quen, ngữ cảnh và sở thích để đưa ra gợi ý chính xác.`,
        image: 'https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1200&q=85',
        author: 'Admin GadgetZone',
        tags: ['AI', 'Galaxy AI', 'Apple Intelligence', 'Xu hướng'],
        isPublished: true,
      },
      {
        title: 'Hướng dẫn chọn laptop cho sinh viên: Từ 12 đến 30 triệu',
        summary: 'Bài viết tổng hợp các tiêu chí và gợi ý laptop phù hợp với sinh viên từng ngành học, ngân sách từ 12 triệu đến 30 triệu đồng.',
        content: `Việc chọn laptop đầu đời cho sinh viên là một quyết định quan trọng vì sẽ đồng hành 4 năm đại học. Dưới đây là hướng dẫn chi tiết theo từng ngân sách và ngành học.

**Phân khúc 12-15 triệu — Văn phòng cơ bản**
Phù hợp sinh viên các ngành kinh tế, luật, ngoại ngữ với nhu cầu chủ yếu là Word, Excel, lướt web và xem video. Cấu hình gợi ý: Core i5 hoặc Ryzen 5, 8GB RAM, 256GB SSD. Lựa chọn nổi bật: ASUS VivoBook 15, Lenovo IdeaPad Slim 3, Acer Aspire Lite.

**Phân khúc 15-22 triệu — Đa nhiệm thoải mái**
Lên RAM 16GB là điều cần thiết. Lựa chọn tốt: ASUS Zenbook 14 OLED, Acer Swift Go 14, Lenovo Yoga Slim 7. Đặc biệt MacBook Air M2 13 inch (~22 triệu) là lựa chọn cực kỳ đáng đồng tiền cho sinh viên — pin 18 giờ, bền bỉ và giá trị giữ giá tốt.

**Phân khúc 22-30 triệu — IT, Đồ họa, Kiến trúc**
Sinh viên CNTT, đồ họa, kiến trúc cần laptop cấu hình cao với card đồ họa rời. Đề xuất: ASUS ROG Zephyrus G14, MacBook Pro M3 14 inch, Dell Inspiron 16 Plus. RAM 16-32GB và SSD 512GB-1TB là tiêu chuẩn.

**Lưu ý ngoài cấu hình**
Trọng lượng dưới 1.7kg để dễ mang đi học, pin tối thiểu 8 giờ, bàn phím gõ tốt, màn hình IPS hoặc OLED. Đừng quên kiểm tra chính sách bảo hành và ưu đãi sinh viên — GadgetZone giảm thêm 5% và tặng balo, chuột không dây cho sinh viên có thẻ HSSV.`,
        image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=1200&q=85',
        author: 'Admin GadgetZone',
        tags: ['Laptop', 'Sinh viên', 'Hướng dẫn'],
        isPublished: true,
      },
      {
        title: 'Đánh giá Samsung Galaxy S24 Ultra sau 3 tháng: Đáng tiền không?',
        summary: 'Sau 3 tháng dùng làm máy chính, Galaxy S24 Ultra đã chứng tỏ là chiếc Android tốt nhất 2026 hay vẫn còn khuyết điểm? Đánh giá chi tiết từ camera, hiệu năng đến trải nghiệm Galaxy AI.',
        content: `Sau ba tháng sử dụng làm máy chính, đây là những gì tôi rút ra về Galaxy S24 Ultra — chiếc smartphone Android cao cấp nhất của Samsung năm 2026.

**Thiết kế khung Titanium — Đánh đổi xứng đáng**
Việc chuyển sang khung Titanium giúp máy nhẹ hơn 15g so với S23 Ultra, cảm giác cầm tay thoải mái hơn dù vẫn lớn. Mặt kính phẳng (cuối cùng đã bỏ kính cong) cùng kính Gorilla Armor chống lóa thực sự là cải tiến đáng giá.

**Snapdragon 8 Gen 3 for Galaxy — Mạnh nhưng nóng**
Hiệu năng cực kỳ ấn tượng, mọi game nặng như Genshin Impact, PUBG đều chiến mượt ở mức Max. Tuy nhiên khi chơi game lâu hoặc quay video 4K kéo dài, máy nóng khá rõ và có hiện tượng giảm hiệu năng (throttle) sau khoảng 20 phút.

**Camera 200MP — Vẫn đỉnh, nhưng zoom 100x là gimmick**
Camera chính 200MP cho ảnh sắc nét, dynamic range tốt. Zoom quang 5x dùng được, zoom 10-30x ổn, nhưng zoom 100x chỉ để khoe — chất lượng kém. Chế độ chụp đêm cải thiện rõ so với S23 Ultra.

**Galaxy AI — Hữu ích thực sự**
Live Translate dịch cuộc gọi tiếng Anh sang tiếng Việt khá ổn (chính xác ~85%). Note Assist tóm tắt văn bản nhanh, hữu ích cho sinh viên/nhân viên văn phòng. Generative Edit đôi khi tạo ra ảnh "ảo diệu" nhưng khá thú vị.

**Pin và sạc — Đủ dùng nhưng chậm**
Pin 5000mAh dùng từ 7h sáng đến 11h tối, còn 15-20%. Sạc 45W chậm so với các đối thủ Trung Quốc (100W+). Sạc đầy mất khoảng 70 phút.

**Tổng kết: 9/10**
Galaxy S24 Ultra xứng đáng là Android cao cấp nhất 2026. Với mức giá khoảng 28 triệu sau giảm tại GadgetZone, đây là lựa chọn tốt nhất nếu bạn cần đa nhiệm, S Pen và camera đa năng.`,
        image: 'https://images.unsplash.com/photo-1610792516775-01de03eae630?w=1200&q=85',
        author: 'Admin GadgetZone',
        tags: ['Samsung', 'S24 Ultra', 'Đánh giá', 'Review'],
        isPublished: true,
      },
      {
        title: 'Top 5 tai nghe chống ồn đáng mua nhất 2026',
        summary: 'Tổng hợp 5 mẫu tai nghe chống ồn chủ động (ANC) tốt nhất 2026 cho làm việc, học tập và di chuyển. Có gợi ý theo từng tầm giá từ 5 đến 13 triệu.',
        content: `Tai nghe chống ồn ANC đã trở thành phụ kiện không thể thiếu cho sinh viên, dân văn phòng và người thường xuyên di chuyển. Đây là 5 mẫu tốt nhất bạn có thể mua trong năm 2026.

**1. Sony WH-1000XM5 — Vua chống ồn (8.490.000 đ)**
Vẫn là chuẩn mực cho tai nghe ANC over-ear. Driver 30mm, 8 micro, chip xử lý V1. Chất âm cân bằng, bass đủ, vocal trong. Pin 30 giờ. Đeo lâu thoải mái. Điểm trừ: thiết kế không gập gọn được như XM4.

**2. Apple AirPods Max 2 — Premium cho hệ sinh thái Apple (12.990.000 đ)**
Chất âm Spatial Audio xuất sắc khi xem phim, kết nối liền mạch với iPhone/iPad/Mac. Vỏ nhôm, đệm Memory Foam cao cấp. Điểm trừ: không có jack 3.5mm, sạc Lightning chậm.

**3. Bose QuietComfort Ultra — Chống ồn huyền thoại (9.490.000 đ)**
Bose làm chống ồn từ 1989, và QC Ultra là đỉnh cao. Đeo cả ngày không mỏi, âm bass ấm dày. Có chế độ Immersive Audio hay. Điểm trừ: nhựa nhiều, cảm giác kém cao cấp hơn Sony.

**4. Sennheiser Momentum 4 — Audiophile thực thụ (7.990.000 đ)**
Chất âm "sến" và ấm đặc trưng Sennheiser. Pin lên đến 60 giờ — gần gấp đôi Sony. Codec aptX Adaptive cho Android. Điểm trừ: chống ồn không bằng top 3.

**5. Samsung Galaxy Buds3 Pro — In-ear cao cấp (5.490.000 đ)**
True wireless cao cấp với thiết kế stem mới giống AirPods. ANC tốt, tích hợp sâu với Samsung. Galaxy AI dịch real-time qua tai nghe. Điểm trừ: hơi nhỏ với người tai to.

**Nên mua loại nào?**
Nếu bạn dùng iPhone: AirPods Pro 2 (~5 triệu) hoặc AirPods Max 2.
Nếu cần chống ồn tốt nhất, đa thiết bị: Sony WH-1000XM5.
Ngân sách hạn chế: Sony WH-CH720N (~2.5 triệu) cũng là lựa chọn tốt.

Tất cả các mẫu trên đều có sẵn tại GadgetZone với chính sách bảo hành chính hãng 12 tháng và hỗ trợ trả góp 0%.`,
        image: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=1200&q=85',
        author: 'Admin GadgetZone',
        tags: ['Tai nghe', 'ANC', 'Sony', 'Top list'],
        isPublished: true,
      },
      {
        title: 'MacBook Pro M3 Pro vs Dell XPS 15 OLED: Chọn laptop nào cho dân thiết kế?',
        summary: 'So sánh chi tiết hai chiếc laptop được dân thiết kế đồ họa và developer ưa chuộng nhất năm 2026: MacBook Pro 14 M3 Pro và Dell XPS 15 9530 OLED.',
        content: `Đây là cuộc đối đầu giữa hai trường phái laptop cao cấp dành cho dân sáng tạo: MacBook Pro M3 Pro 14 inch (45.990.000đ) và Dell XPS 15 9530 OLED (38.990.000đ tại GadgetZone).

**Màn hình: Dell thắng về độ rực rỡ, MacBook về độ chính xác**
Dell XPS 15 với màn OLED 3.5K cho màu đen sâu tuyệt đối, độ tương phản infinite. MacBook Pro với màn mini-LED 120Hz ProMotion cho độ chính xác màu cao hơn (Delta E < 1) và refresh rate mượt hơn.

**Hiệu năng: M3 Pro mạnh hơn về single-core và edit video**
Trong các tác vụ đơn nhân (Lightroom, photo edit), M3 Pro nhanh hơn 20-30%. Khi render video Final Cut Pro 4K, M3 Pro vượt trội nhờ ProRes encoder phần cứng. Tuy nhiên, Dell XPS với i7-13700H + RTX 4050 lại tốt hơn cho 3D rendering, machine learning có CUDA và game.

**Pin: MacBook ăn đứt**
MacBook Pro M3 Pro thực tế 14-16 giờ làm việc văn phòng, 8-10 giờ edit video. Dell XPS 15 chỉ được 5-7 giờ làm việc nhẹ, 3-4 giờ tải nặng.

**Phần mềm: Phụ thuộc nhu cầu**
- Dân Adobe đầy đủ: cả hai đều ổn, MacBook tối ưu hơn cho Lightroom/Final Cut.
- Lập trình: MacBook là lựa chọn tự nhiên nhờ Unix-based macOS.
- Game/CAD/Solidworks: Dell thắng vì Windows hỗ trợ phần mềm rộng hơn.

**Ai nên mua MacBook Pro M3 Pro?**
Nhà sáng tạo ưu tiên pin, di động, edit photo/video, lập trình, người đã trong hệ sinh thái Apple.

**Ai nên mua Dell XPS 15?**
Designer cần Windows, người làm 3D/CAD, gamer kiêm sáng tạo, người cần màn OLED siêu rực rỡ và mua sẵn nhiều phần mềm Windows.`,
        image: 'https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?w=1200&q=85',
        author: 'Admin GadgetZone',
        tags: ['MacBook', 'Dell XPS', 'So sánh', 'Laptop'],
        isPublished: true,
      },
    ]);
    console.log('Seeded news:', news.length);

    // ===== Vouchers (Mã giảm giá) =====
    const now = new Date();
    const in30days = new Date(now.getTime() + 30 * 86400000);
    const in60days = new Date(now.getTime() + 60 * 86400000);
    const in90days = new Date(now.getTime() + 90 * 86400000);
    const expired = new Date(now.getTime() - 7 * 86400000);

    const vouchers = await Voucher.create([
      {
        code: 'WELCOME20', description: 'Giảm 20% cho khách hàng mới — tối đa 500K',
        type: 'percent', value: 20, maxDiscount: 500000, minOrderValue: 1000000,
        usageLimit: 100, usedCount: 12, startDate: now, endDate: in60days, isActive: true,
      },
      {
        code: 'GADGET500K', description: 'Giảm thẳng 500.000đ cho đơn từ 10 triệu',
        type: 'fixed', value: 500000, minOrderValue: 10000000,
        usageLimit: 50, usedCount: 5, startDate: now, endDate: in30days, isActive: true,
      },
      {
        code: 'FREESHIP', description: 'Giảm 50K phí ship cho mọi đơn hàng',
        type: 'fixed', value: 50000, minOrderValue: 0,
        usageLimit: 0, usedCount: 234, startDate: now, endDate: in90days, isActive: true,
      },
      {
        code: 'TET2026', description: 'Ưu đãi Tết Nguyên Đán — Giảm 10% tối đa 1 triệu',
        type: 'percent', value: 10, maxDiscount: 1000000, minOrderValue: 5000000,
        usageLimit: 200, usedCount: 47, startDate: now, endDate: in30days, isActive: true,
      },
      {
        code: 'STUDENT15', description: 'Ưu đãi sinh viên — Giảm 15% tối đa 300K',
        type: 'percent', value: 15, maxDiscount: 300000, minOrderValue: 2000000,
        usageLimit: 500, usedCount: 89, startDate: now, endDate: in60days, isActive: true,
      },
      {
        code: 'BLACKFRIDAY', description: 'Mã đã hết hạn (test trạng thái)',
        type: 'percent', value: 30, maxDiscount: 2000000, minOrderValue: 5000000,
        usageLimit: 50, usedCount: 50, startDate: expired, endDate: expired, isActive: true,
      },
    ]);
    console.log('Seeded vouchers:', vouchers.length);

    // ===== Reviews (Đánh giá sản phẩm) =====
    const reviewSamples = [
      { rating: 5, comment: 'Sản phẩm chính hãng, đóng gói cẩn thận, giao nhanh trong 2 giờ. Rất hài lòng!' },
      { rating: 5, comment: 'Máy đẹp, chạy mượt, pin trâu. Mua tại GadgetZone giá tốt nhất so với các shop khác mình tham khảo.' },
      { rating: 4, comment: 'Sản phẩm tốt, dịch vụ chăm sóc khách hàng nhiệt tình. Tuy nhiên thời gian giao hàng có thể nhanh hơn nữa.' },
      { rating: 5, comment: 'Mua đúng dịp khuyến mãi, tiết kiệm được kha khá. Camera quá xịn, chụp đêm rõ nét.' },
      { rating: 4, comment: 'Đáng đồng tiền. Hộp seal nguyên vẹn, có hóa đơn VAT đầy đủ.' },
      { rating: 5, comment: 'Hiệu năng đỉnh, gaming mượt mà ở mức max. Bàn phím gõ thích, màn hình rực rỡ.' },
      { rating: 3, comment: 'Sản phẩm ổn nhưng pin hơi yếu so với mong đợi. Còn lại đều ok.' },
      { rating: 5, comment: 'Lần thứ 3 mua tại GadgetZone, vẫn yên tâm. Nhân viên tư vấn rất am hiểu sản phẩm.' },
      { rating: 4, comment: 'Chất lượng âm thanh tuyệt vời, chống ồn tốt. Đeo lâu hơi nóng tai một chút.' },
      { rating: 5, comment: 'Thiết kế sang trọng, cảm giác cầm tay đầm chắc. Hiệu năng vượt mong đợi với mức giá này.' },
    ];

    const reviewDocs = [];
    const customerUsers = users.filter((u) => u.role === 'customer');
    products.slice(0, 12).forEach((p, idx) => {
      const numRev = 2 + (idx % 3);
      for (let i = 0; i < numRev; i++) {
        const sample = reviewSamples[(idx * 3 + i) % reviewSamples.length];
        const user = customerUsers[i % customerUsers.length];
        reviewDocs.push({
          user: user._id,
          product: p._id,
          rating: sample.rating,
          comment: sample.comment,
          createdAt: new Date(now.getTime() - (idx * 5 + i) * 86400000),
        });
      }
    });

    // Need to create reviews 1 by 1 to avoid unique constraint (user+product)
    const createdReviews = [];
    for (const r of reviewDocs) {
      try {
        const created = await Review.create(r);
        createdReviews.push(created);
      } catch { /* skip duplicate */ }
    }

    // Cập nhật rating trung bình cho từng product
    for (const p of products) {
      const productReviews = createdReviews.filter((r) => r.product.toString() === p._id.toString());
      if (productReviews.length > 0) {
        const avg = productReviews.reduce((s, r) => s + r.rating, 0) / productReviews.length;
        await Product.findByIdAndUpdate(p._id, {
          rating: Math.round(avg * 10) / 10,
          numReviews: productReviews.length,
        });
      }
    }
    console.log('Seeded reviews:', createdReviews.length);

    // ===== News Comments =====
    const commentSamples = [
      'Bài viết rất chi tiết và bổ ích. Cảm ơn GadgetZone!',
      'Mình đang phân vân giữa iPhone và Samsung, sau khi đọc bài này thì đã có quyết định 👍',
      'Hóng review đầy đủ về dòng máy này. Có nên đợi bản kế tiếp không nhỉ?',
      'Giá cao quá so với mặt bằng. Đợi sale Black Friday xem sao.',
      'Đã mua ở GadgetZone, sản phẩm chính hãng, dịch vụ tốt. Recommend!',
      'Cảm ơn admin đã chia sẻ thông tin chi tiết, rất hữu ích cho người mua lần đầu.',
      'Chip Snapdragon 8 Gen 3 quá đỉnh, chiến game tẹt ga.',
      'So sánh giúp mình dòng Pro Max với bản thường được không ad?',
    ];

    const commentDocs = [];
    news.slice(0, 4).forEach((n, idx) => {
      const numCm = 2 + (idx % 3);
      for (let i = 0; i < numCm; i++) {
        commentDocs.push({
          news: n._id,
          user: customerUsers[i % customerUsers.length]._id,
          content: commentSamples[(idx * 3 + i) % commentSamples.length],
          isApproved: i === 0 ? true : Math.random() > 0.2,
          createdAt: new Date(now.getTime() - (idx * 2 + i) * 3600000),
        });
      }
    });
    const createdComments = await NewsComment.insertMany(commentDocs);
    console.log('Seeded news comments:', createdComments.length);

    // ===== Orders (Đơn hàng mẫu để có dữ liệu Dashboard) =====
    const statuses = ['pending', 'confirmed', 'shipping', 'delivered', 'delivered', 'delivered', 'delivered', 'cancelled'];
    const paymentMethods = ['cod', 'cod', 'vnpay', 'vnpay'];
    const addresses = [
      { name: 'Nguyễn Văn A', phone: '0912345678', address: '73 Quang Trung, Hà Đông, Hà Nội' },
      { name: 'Trần Thị B', phone: '0923456789', address: '128 Cầu Giấy, Cầu Giấy, Hà Nội' },
      { name: 'Lê Minh C', phone: '0934567890', address: '789 Trần Phú, Hải Châu, Đà Nẵng' },
      { name: 'Phạm Thu D', phone: '0945678901', address: '101 Bà Triệu, Hai Bà Trưng, Hà Nội' },
    ];

    const orderDocs = [];
    // Tạo 35 đơn hàng trải đều 30 ngày qua
    for (let i = 0; i < 35; i++) {
      const daysAgo = Math.floor(Math.random() * 30);
      const orderDate = new Date(now.getTime() - daysAgo * 86400000 - Math.random() * 86400000);
      const customer = customerUsers[i % customerUsers.length];
      const addr = addresses[i % addresses.length];
      const status = statuses[i % statuses.length];

      // 1-4 sản phẩm mỗi đơn
      const numItems = 1 + Math.floor(Math.random() * 3);
      const itemList = [];
      const usedIdx = new Set();
      for (let j = 0; j < numItems; j++) {
        let pIdx;
        do { pIdx = Math.floor(Math.random() * products.length); } while (usedIdx.has(pIdx));
        usedIdx.add(pIdx);
        const p = products[pIdx];
        const qty = 1 + Math.floor(Math.random() * 2);
        const unitPrice = p.salePrice > 0 ? p.salePrice : p.price;
        itemList.push({
          product: p._id, name: p.name, image: p.images[0] || '',
          price: unitPrice, quantity: qty,
        });
      }

      const subtotal = itemList.reduce((s, it) => s + it.price * it.quantity, 0);
      // 30% đơn có voucher
      let discount = 0, vCode = '';
      if (Math.random() < 0.3) {
        const v = vouchers[Math.floor(Math.random() * 5)];
        if (subtotal >= v.minOrderValue) {
          discount = v.calculateDiscount(subtotal);
          vCode = v.code;
        }
      }

      orderDocs.push({
        user: customer._id, items: itemList,
        shippingAddress: addr,
        paymentMethod: paymentMethods[i % paymentMethods.length],
        paymentStatus: status === 'delivered' ? 'paid' : 'pending',
        subtotal, discount, voucherCode: vCode,
        totalAmount: subtotal - discount,
        status,
        trackingNumber: ['shipping', 'delivered'].includes(status) ? `GHN${Date.now().toString().slice(-8)}${i}` : '',
        shippingProvider: ['shipping', 'delivered'].includes(status) ? 'GHN - Giao Hàng Nhanh' : '',
        statusHistory: [
          { status: 'pending', note: 'Đơn hàng được tạo', by: customer._id, at: orderDate },
          ...(status !== 'pending' ? [{ status: 'confirmed', note: 'Admin xác nhận đơn', by: users[0]._id, at: new Date(orderDate.getTime() + 3600000) }] : []),
          ...(['shipping', 'delivered'].includes(status) ? [{ status: 'shipping', note: 'Đã giao cho đơn vị vận chuyển', by: users[0]._id, at: new Date(orderDate.getTime() + 7200000) }] : []),
          ...(status === 'delivered' ? [{ status: 'delivered', note: 'Khách đã nhận hàng', by: users[0]._id, at: new Date(orderDate.getTime() + 86400000) }] : []),
          ...(status === 'cancelled' ? [{ status: 'cancelled', note: 'Khách yêu cầu hủy', by: customer._id, at: new Date(orderDate.getTime() + 1800000) }] : []),
        ],
        createdAt: orderDate, updatedAt: orderDate,
      });
    }

    const createdOrders = await Order.insertMany(orderDocs);
    console.log('Seeded orders:', createdOrders.length);

    console.log('\n=== SEED HOÀN TẤT ===');
    console.log('Admin: admin@gadgetzone.vn / admin123');
    console.log('Customer 1: nguyenvana@gmail.com / 123456');
    console.log('Customer 2: tranthib@gmail.com / 123456');

    process.exit(0);
  } catch (error) {
    console.error('Seed error:', error);
    process.exit(1);
  }
};

seedData();
