const Voucher = require('../models/Voucher');

exports.adminGetAll = async (req, res) => {
  try {
    const vouchers = await Voucher.find().sort({ createdAt: -1 });
    res.json({ success: true, data: vouchers });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getActive = async (req, res) => {
  try {
    const now = new Date();
    const vouchers = await Voucher.find({
      isActive: true, startDate: { $lte: now }, endDate: { $gte: now },
    }).sort({ endDate: 1 });
    res.json({ success: true, data: vouchers });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.verify = async (req, res) => {
  try {
    const { code, orderAmount } = req.body;
    const voucher = await Voucher.findOne({ code: code?.trim().toUpperCase() });
    if (!voucher) return res.status(404).json({ success: false, message: 'Mã không tồn tại' });

    const check = voucher.isValid();
    if (!check.valid) return res.status(400).json({ success: false, message: check.message });

    if (orderAmount < voucher.minOrderValue) {
      return res.status(400).json({
        success: false,
        message: `Đơn tối thiểu ${voucher.minOrderValue.toLocaleString('vi-VN')}₫`,
      });
    }

    const discount = voucher.calculateDiscount(orderAmount);
    res.json({
      success: true,
      data: {
        code: voucher.code,
        discount,
        type: voucher.type,
        value: voucher.value,
        description: voucher.description,
      },
    });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.create = async (req, res) => {
  try {
    if (req.body.code) req.body.code = req.body.code.trim().toUpperCase();
    const voucher = await Voucher.create(req.body);
    res.status(201).json({ success: true, data: voucher });
  } catch (e) {
    if (e.code === 11000) return res.status(400).json({ success: false, message: 'Mã đã tồn tại' });
    res.status(400).json({ success: false, message: e.message });
  }
};

exports.update = async (req, res) => {
  try {
    if (req.body.code) req.body.code = req.body.code.trim().toUpperCase();
    const voucher = await Voucher.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!voucher) return res.status(404).json({ success: false, message: 'Không tìm thấy' });
    res.json({ success: true, data: voucher });
  } catch (e) { res.status(400).json({ success: false, message: e.message }); }
};

exports.remove = async (req, res) => {
  try {
    await Voucher.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
