const crypto = require('crypto');
const Order = require('../models/Order');

// Sort keys + encode values theo chuẩn VNPay (space -> '+')
function sortObject(obj) {
  const sorted = {};
  const keys = Object.keys(obj).sort();
  for (const key of keys) {
    sorted[key] = encodeURIComponent(obj[key]).replace(/%20/g, '+');
  }
  return sorted;
}

// Nối query string từ object ĐÃ được encode, KHÔNG encode lại lần nữa.
// Dùng URLSearchParams sẽ gây double-encoding -> VNPay báo sai chữ ký.
function buildQueryString(sorted) {
  return Object.keys(sorted)
    .map((key) => `${key}=${sorted[key]}`)
    .join('&');
}

exports.createVnpayUrl = async (req, res) => {
  try {
    const { orderId } = req.body;
    const order = await Order.findById(orderId);
    if (!order) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy đơn hàng' });
    }

    const date = new Date();
    const createDate = date.toISOString().replace(/[-T:Z.]/g, '').slice(0, 14);

    const vnp_Params = {
      vnp_Version: '2.1.0',
      vnp_Command: 'pay',
      vnp_TmnCode: process.env.VNPAY_TMN_CODE,
      vnp_Locale: 'vn',
      vnp_CurrCode: 'VND',
      vnp_TxnRef: orderId,
      vnp_OrderInfo: `Thanh toan don hang ${orderId}`,
      vnp_OrderType: 'other',
      vnp_Amount: order.totalAmount * 100,
      vnp_ReturnUrl: process.env.VNPAY_RETURN_URL,
      vnp_IpAddr: req.ip || '127.0.0.1',
      vnp_CreateDate: createDate,
    };

    const sorted = sortObject(vnp_Params);
    const signData = buildQueryString(sorted);
    const hmac = crypto.createHmac('sha512', process.env.VNPAY_HASH_SECRET);
    const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

    sorted.vnp_SecureHash = signed;
    const paymentUrl = `${process.env.VNPAY_URL}?${buildQueryString(sorted)}`;

    res.json({ success: true, data: { paymentUrl } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.vnpayReturn = async (req, res) => {
  try {
    const vnp_Params = { ...req.query };
    const secureHash = vnp_Params.vnp_SecureHash;
    delete vnp_Params.vnp_SecureHash;
    delete vnp_Params.vnp_SecureHashType;

    const sorted = sortObject(vnp_Params);
    const signData = buildQueryString(sorted);
    const hmac = crypto.createHmac('sha512', process.env.VNPAY_HASH_SECRET);
    const signed = hmac.update(Buffer.from(signData, 'utf-8')).digest('hex');

    if (secureHash !== signed) {
      return res.status(400).json({ success: false, message: 'Chữ ký không hợp lệ' });
    }

    const orderId = vnp_Params.vnp_TxnRef;
    const responseCode = vnp_Params.vnp_ResponseCode;

    if (responseCode === '00') {
      await Order.findByIdAndUpdate(orderId, {
        paymentStatus: 'paid',
        vnpayTransactionId: vnp_Params.vnp_TransactionNo,
      });
      return res.json({
        success: true,
        message: 'Thanh toán thành công',
        data: {
          orderId,
          amount: vnp_Params.vnp_Amount,
          bankCode: vnp_Params.vnp_BankCode,
          transactionNo: vnp_Params.vnp_TransactionNo,
        },
      });
    }

    await Order.findByIdAndUpdate(orderId, { paymentStatus: 'failed' });
    return res.json({
      success: false,
      message: 'Thanh toán thất bại',
      data: { orderId, responseCode },
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
