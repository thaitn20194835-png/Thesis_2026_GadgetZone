const Supplier = require('../models/Supplier');

exports.getAll = async (req, res) => {
  try {
    const suppliers = await Supplier.find().populate('brands', 'name logo').sort({ createdAt: -1 });
    res.json({ success: true, data: suppliers });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.getById = async (req, res) => {
  try {
    const supplier = await Supplier.findById(req.params.id).populate('brands', 'name logo');
    if (!supplier) return res.status(404).json({ success: false, message: 'Không tìm thấy' });
    res.json({ success: true, data: supplier });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.create = async (req, res) => {
  try {
    const supplier = await Supplier.create(req.body);
    res.status(201).json({ success: true, data: supplier });
  } catch (e) { res.status(400).json({ success: false, message: e.message }); }
};

exports.update = async (req, res) => {
  try {
    const supplier = await Supplier.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!supplier) return res.status(404).json({ success: false, message: 'Không tìm thấy' });
    res.json({ success: true, data: supplier });
  } catch (e) { res.status(400).json({ success: false, message: e.message }); }
};

exports.remove = async (req, res) => {
  try {
    await Supplier.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
