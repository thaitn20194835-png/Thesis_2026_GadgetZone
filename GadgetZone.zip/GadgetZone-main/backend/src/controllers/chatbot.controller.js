const OpenAI = require('openai');
const Product = require('../models/Product');

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

exports.chat = async (req, res) => {
  try {
    const { message } = req.body;

    // Lấy danh sách sản phẩm để chatbot có context
    const products = await Product.find({ isActive: true })
      .select('name price salePrice category brand rating stock')
      .populate('category', 'name')
      .populate('brand', 'name')
      .limit(50);

    const productList = products.map(p =>
      `- ${p.name} | Giá: ${p.salePrice > 0 ? p.salePrice : p.price}đ | Thương hiệu: ${p.brand?.name || 'N/A'} | Danh mục: ${p.category?.name || 'N/A'} | Đánh giá: ${p.rating}/5 | Còn: ${p.stock}`
    ).join('\n');

    const completion = await openai.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages: [
        {
          role: 'system',
          content: `Bạn là trợ lý tư vấn bán hàng của GadgetZone - cửa hàng điện tử trực tuyến. Hãy tư vấn sản phẩm phù hợp dựa trên nhu cầu khách hàng. Trả lời bằng tiếng Việt, thân thiện và chuyên nghiệp.

Danh sách sản phẩm hiện có:
${productList}

Nếu khách hỏi về sản phẩm không có trong danh sách, hãy giới thiệu sản phẩm tương tự hoặc thông báo chưa có.`,
        },
        { role: 'user', content: message },
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    res.json({
      success: true,
      data: {
        reply: completion.choices[0].message.content,
      },
    });
  } catch (error) {
    console.error('Chatbot error:', error);
    res.status(500).json({ success: false, message: 'Chatbot đang bận, vui lòng thử lại sau' });
  }
};
