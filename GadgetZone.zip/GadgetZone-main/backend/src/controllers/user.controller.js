const User = require('../models/User');

// Admin: lấy tất cả users
exports.getAll = async (req, res) => {
  try {
    const users = await User.find().select('-password').sort({ createdAt: -1 });
    res.json({ success: true, data: users });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Admin: khóa / mở tài khoản
exports.toggleActive = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy người dùng' });
    }
    if (user.role === 'admin') {
      return res.status(400).json({ success: false, message: 'Không thể khóa tài khoản admin' });
    }
    user.isActive = !user.isActive;
    await user.save();
    res.json({
      success: true,
      message: user.isActive ? 'Mở khóa tài khoản thành công' : 'Khóa tài khoản thành công',
      data: user,
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// Dashboard stats
exports.getStats = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments({ role: 'customer' });
    const activeUsers = await User.countDocuments({ role: 'customer', isActive: true });
    res.json({ success: true, data: { totalUsers, activeUsers } });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
