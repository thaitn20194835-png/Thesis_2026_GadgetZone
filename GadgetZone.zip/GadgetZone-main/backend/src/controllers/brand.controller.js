const Brand = require('../models/Brand');

exports.getAll = async (req, res) => {
  try {
    const brands = await Brand.find().sort({ name: 1 });
    res.json({ success: true, data: brands });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.getById = async (req, res) => {
  try {
    const brand = await Brand.findById(req.params.id);
    if (!brand) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy thương hiệu' });
    }
    res.json({ success: true, data: brand });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.create = async (req, res) => {
  try {
    const brand = await Brand.create(req.body);
    res.status(201).json({ success: true, message: 'Tạo thương hiệu thành công', data: brand });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ success: false, message: 'Tên thương hiệu đã tồn tại' });
    }
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.update = async (req, res) => {
  try {
    const brand = await Brand.findById(req.params.id);
    if (!brand) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy thương hiệu' });
    }
    Object.assign(brand, req.body);
    await brand.save();
    res.json({ success: true, message: 'Cập nhật thương hiệu thành công', data: brand });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.delete = async (req, res) => {
  try {
    const brand = await Brand.findByIdAndDelete(req.params.id);
    if (!brand) {
      return res.status(404).json({ success: false, message: 'Không tìm thấy thương hiệu' });
    }
    res.json({ success: true, message: 'Xóa thương hiệu thành công' });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};
