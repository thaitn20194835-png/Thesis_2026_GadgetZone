const NewsComment = require('../models/NewsComment');

exports.getByNews = async (req, res) => {
  try {
    const comments = await NewsComment.find({ news: req.params.newsId, isApproved: true })
      .populate('user', 'name')
      .sort({ createdAt: -1 });
    res.json({ success: true, data: comments });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.create = async (req, res) => {
  try {
    const { newsId, content } = req.body;
    if (!content?.trim()) return res.status(400).json({ success: false, message: 'Nội dung trống' });
    const comment = await NewsComment.create({
      news: newsId, user: req.user._id, content: content.trim(),
    });
    const populated = await NewsComment.findById(comment._id).populate('user', 'name');
    res.status(201).json({ success: true, data: populated });
  } catch (e) { res.status(400).json({ success: false, message: e.message }); }
};

exports.adminGetAll = async (req, res) => {
  try {
    const comments = await NewsComment.find()
      .populate('user', 'name email')
      .populate('news', 'title')
      .sort({ createdAt: -1 });
    res.json({ success: true, data: comments });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.toggleApprove = async (req, res) => {
  try {
    const c = await NewsComment.findById(req.params.id);
    if (!c) return res.status(404).json({ success: false, message: 'Không tìm thấy' });
    c.isApproved = !c.isApproved;
    await c.save();
    res.json({ success: true, data: c });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};

exports.remove = async (req, res) => {
  try {
    await NewsComment.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (e) { res.status(500).json({ success: false, message: e.message }); }
};
