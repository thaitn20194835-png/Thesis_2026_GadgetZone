const http = require('http');

function get(path, headers = {}) {
  return new Promise((resolve, reject) => {
    http.get('http://localhost:5000' + path, { headers }, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, raw: d.substring(0, 300) }); }
      });
    }).on('error', reject);
  });
}

function post(path, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const opts = {
      hostname: 'localhost', port: 5000, path, method: 'POST',
      headers: { 'Content-Type': 'application/json', ...headers, 'Content-Length': Buffer.byteLength(data) }
    };
    const req = http.request(opts, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, raw: d.substring(0, 300) }); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

function put(path, body, headers = {}) {
  return new Promise((resolve, reject) => {
    const data = JSON.stringify(body);
    const opts = {
      hostname: 'localhost', port: 5000, path, method: 'PUT',
      headers: { 'Content-Type': 'application/json', ...headers, 'Content-Length': Buffer.byteLength(data) }
    };
    const req = http.request(opts, (res) => {
      let d = '';
      res.on('data', c => d += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(d) }); }
        catch { resolve({ status: res.statusCode, raw: d.substring(0, 300) }); }
      });
    });
    req.on('error', reject);
    req.write(data);
    req.end();
  });
}

let passed = 0;
let failed = 0;
const errors = [];

function check(name, condition, detail = '') {
  if (condition) {
    console.log(`  PASS: ${name}`);
    passed++;
  } else {
    console.log(`  FAIL: ${name} ${detail}`);
    failed++;
    errors.push({ name, detail });
  }
}

async function runTests() {
  // ========== PUBLIC ENDPOINTS ==========
  console.log('\n========== 1. PUBLIC - Categories ==========');
  const cats = await get('/api/categories');
  check('GET /api/categories - status 200', cats.status === 200);
  check('Categories success=true', cats.body?.success === true);
  check('Categories has data array', Array.isArray(cats.body?.data));
  check('Categories count >= 6', cats.body?.data?.length >= 6, `Got ${cats.body?.data?.length}`);

  console.log('\n========== 2. PUBLIC - Brands ==========');
  const brands = await get('/api/brands');
  check('GET /api/brands - status 200', brands.status === 200);
  check('Brands count >= 10', brands.body?.data?.length >= 10, `Got ${brands.body?.data?.length}`);

  console.log('\n========== 3. PUBLIC - Products ==========');
  const prods = await get('/api/products');
  check('GET /api/products - status 200', prods.status === 200);
  check('Products has data array', Array.isArray(prods.body?.data));
  check('Products count >= 12', prods.body?.data?.length >= 12, `Got ${prods.body?.data?.length}`);
  check('Has pagination object', !!prods.body?.pagination);
  check('Pagination has pages field', prods.body?.pagination?.pages !== undefined, `pagination: ${JSON.stringify(prods.body?.pagination)}`);

  const pid = prods.body?.data?.[0]?._id;

  console.log('\n========== 4. PUBLIC - Products Featured ==========');
  const featured = await get('/api/products?featured=true');
  check('Featured products success', featured.body?.success === true);
  check('Featured count > 0', featured.body?.data?.length > 0, `Got ${featured.body?.data?.length}`);

  console.log('\n========== 5. PUBLIC - Product by ID ==========');
  const prod = await get('/api/products/' + pid);
  check('Get product by ID success', prod.body?.success === true);
  check('Product has name', !!prod.body?.data?.name);
  check('Product category populated', typeof prod.body?.data?.category === 'object', `Got ${typeof prod.body?.data?.category}`);
  check('Product brand populated', typeof prod.body?.data?.brand === 'object', `Got ${typeof prod.body?.data?.brand}`);

  console.log('\n========== 6. PUBLIC - Search ==========');
  const search = await get('/api/products?search=iPhone');
  check('Search success', search.body?.success === true);
  check('Search found results', search.body?.data?.length > 0, `Got ${search.body?.data?.length}`);

  console.log('\n========== 7. PUBLIC - Filter by price ==========');
  const priceFilter = await get('/api/products?minPrice=20000000&maxPrice=30000000');
  check('Price filter success', priceFilter.body?.success === true);
  check('Price filter found results', priceFilter.body?.data?.length > 0);

  console.log('\n========== 8. PUBLIC - Sort ==========');
  const sortAsc = await get('/api/products?sort=price_asc');
  check('Sort price_asc success', sortAsc.body?.success === true);
  if (sortAsc.body?.data?.length >= 2) {
    check('Sort ascending correct', sortAsc.body.data[0].price <= sortAsc.body.data[1].price,
      `First: ${sortAsc.body.data[0].price}, Second: ${sortAsc.body.data[1].price}`);
  }

  // ========== AUTH ==========
  console.log('\n========== 9. AUTH - Login Admin ==========');
  const adminLogin = await post('/api/auth/login', { email: 'admin@gadgetzone.vn', password: 'admin123' });
  check('Admin login status 200', adminLogin.status === 200);
  check('Admin login success', adminLogin.body?.success === true);
  check('Admin has token', !!adminLogin.body?.token);
  check('Admin role = admin', adminLogin.body?.user?.role === 'admin', `Got ${adminLogin.body?.user?.role}`);
  const adminToken = adminLogin.body?.token;

  console.log('\n========== 10. AUTH - Login Customer ==========');
  const custLogin = await post('/api/auth/login', { email: 'nguyenvana@gmail.com', password: '123456' });
  check('Customer login success', custLogin.body?.success === true);
  check('Customer role = customer', custLogin.body?.user?.role === 'customer');
  const custToken = custLogin.body?.token;

  console.log('\n========== 11. AUTH - Login Wrong Password ==========');
  const badLogin = await post('/api/auth/login', { email: 'admin@gadgetzone.vn', password: 'wrong' });
  check('Wrong password returns 401', badLogin.status === 401, `Got ${badLogin.status}`);

  console.log('\n========== 12. AUTH - Register ==========');
  const reg = await post('/api/auth/register', { name: 'Test User', email: 'testapi@test.com', password: '123456', phone: '0999999999' });
  check('Register success', reg.body?.success === true, `${reg.status} ${reg.body?.message}`);

  console.log('\n========== 13. AUTH - Register Duplicate ==========');
  const regDup = await post('/api/auth/register', { name: 'Test User', email: 'testapi@test.com', password: '123456' });
  check('Duplicate register returns 400', regDup.status === 400, `Got ${regDup.status}`);

  console.log('\n========== 14. AUTH - Get Me ==========');
  const me = await get('/api/auth/me', { Authorization: 'Bearer ' + custToken });
  check('Get me success', me.body?.success === true);
  check('Get me has user', !!me.body?.user);

  console.log('\n========== 15. AUTH - Get Me without token ==========');
  const meNoToken = await get('/api/auth/me');
  check('No token returns 401', meNoToken.status === 401, `Got ${meNoToken.status}`);

  // ========== CART ==========
  console.log('\n========== 16. CART - Get Cart ==========');
  const cart = await get('/api/cart', { Authorization: 'Bearer ' + custToken });
  check('Get cart success', cart.body?.success === true);

  console.log('\n========== 17. CART - Add to Cart ==========');
  const addCart = await post('/api/cart/add', { productId: pid, quantity: 2 }, { Authorization: 'Bearer ' + custToken });
  check('Add to cart success', addCart.body?.success === true, `${addCart.status} ${addCart.body?.message}`);
  check('Cart has items', addCart.body?.data?.items?.length > 0);

  console.log('\n========== 18. CART - Update Quantity ==========');
  const updateCart = await put('/api/cart/update', { productId: pid, quantity: 3 }, { Authorization: 'Bearer ' + custToken });
  check('Update quantity success', updateCart.body?.success === true, `${updateCart.status} ${JSON.stringify(updateCart.body?.message)}`);

  // ========== ORDER ==========
  console.log('\n========== 19. ORDER - Create with COD uppercase (should fail - enum is lowercase) ==========');
  const orderCOD = await post('/api/orders', {
    shippingAddress: { name: 'Nguyen Van A', phone: '0912345678', address: '123 Nguyen Hue, Q1, HCM' },
    paymentMethod: 'COD',
    note: 'Test order uppercase COD'
  }, { Authorization: 'Bearer ' + custToken });
  check('Order COD uppercase rejected', orderCOD.body?.success !== true, `Status: ${orderCOD.status} Msg: ${orderCOD.body?.message}`);

  console.log('\n========== 20. ORDER - Create with cod lowercase ==========');
  const orderCod = await post('/api/orders', {
    shippingAddress: { name: 'Nguyen Van A', phone: '0912345678', address: '123 Nguyen Hue, Q1, HCM' },
    paymentMethod: 'cod',
    note: 'Test order lowercase cod'
  }, { Authorization: 'Bearer ' + custToken });
  check('Order cod lowercase', orderCod.body?.success === true, `Status: ${orderCod.status} Msg: ${orderCod.body?.message}`);

  console.log('\n========== 20b. ORDER - Stock validation ==========');
  // Add 9999 to cart - should exceed stock
  await post('/api/cart/add', { productId: pid, quantity: 9999 }, { Authorization: 'Bearer ' + custToken });
  const orderOverstock = await post('/api/orders', {
    shippingAddress: { name: 'Test', phone: '0912345678', address: 'Test' },
    paymentMethod: 'cod'
  }, { Authorization: 'Bearer ' + custToken });
  check('Order exceeding stock rejected', orderOverstock.status === 400, `Status: ${orderOverstock.status} Msg: ${orderOverstock.body?.message}`);
  check('Stock error has product name', orderOverstock.body?.message?.includes('còn'), `Msg: ${orderOverstock.body?.message}`);

  console.log('\n========== 21. ORDER - My Orders ==========');
  const myOrders = await get('/api/orders/my-orders', { Authorization: 'Bearer ' + custToken });
  check('My orders success', myOrders.body?.success === true);
  check('My orders has data', myOrders.body?.data?.length >= 0);

  // ========== ADMIN ==========
  console.log('\n========== 22. ADMIN - Order Stats ==========');
  const stats = await get('/api/orders/admin/stats', { Authorization: 'Bearer ' + adminToken });
  check('Admin stats success', stats.body?.success === true);
  check('Stats has totalOrders', stats.body?.data?.totalOrders !== undefined, `Got: ${JSON.stringify(stats.body?.data)}`);

  console.log('\n========== 23. ADMIN - All Orders ==========');
  const allOrders = await get('/api/orders/admin/all', { Authorization: 'Bearer ' + adminToken });
  check('Admin all orders success', allOrders.body?.success === true);

  console.log('\n========== 24. ADMIN - All Users ==========');
  const allUsers = await get('/api/users', { Authorization: 'Bearer ' + adminToken });
  check('Admin all users success', allUsers.body?.success === true);
  check('Users has data', allUsers.body?.data?.length > 0);

  console.log('\n========== 25. ADMIN - User Stats ==========');
  const userStats = await get('/api/users/stats', { Authorization: 'Bearer ' + adminToken });
  check('User stats success', userStats.body?.success === true);

  console.log('\n========== 26. ADMIN - All Products ==========');
  const adminProds = await get('/api/products/admin/all', { Authorization: 'Bearer ' + adminToken });
  check('Admin products success', adminProds.body?.success === true);

  console.log('\n========== 27. ADMIN - Unauthorized access ==========');
  const unauth = await get('/api/users', { Authorization: 'Bearer ' + custToken });
  check('Customer cannot access admin routes', unauth.status === 403, `Got ${unauth.status}`);

  // ========== REVIEWS ==========
  console.log('\n========== 28. REVIEW - Create ==========');
  const reviewRes = await post('/api/reviews', { productId: pid, rating: 5, comment: 'San pham rat tot' }, { Authorization: 'Bearer ' + custToken });
  check('Create review success', reviewRes.body?.success === true, `Status: ${reviewRes.status} Msg: ${reviewRes.body?.message}`);

  console.log('\n========== 29. REVIEW - Get by Product ==========');
  const reviews = await get('/api/reviews/product/' + pid);
  check('Get reviews success', reviews.body?.success === true);
  check('Reviews has data', reviews.body?.data?.length > 0, `Got ${reviews.body?.data?.length}`);

  // ========== PROFILE ==========
  console.log('\n========== 30. PROFILE - Update ==========');
  const updateProfile = await put('/api/auth/profile', { name: 'Nguyen Van A Updated', phone: '0912345679' }, { Authorization: 'Bearer ' + custToken });
  check('Update profile success', updateProfile.body?.success === true, `${updateProfile.status} ${updateProfile.body?.message}`);

  console.log('\n========== 31. PROFILE - Change Password ==========');
  const changePw = await put('/api/auth/change-password', { currentPassword: '123456', newPassword: '654321' }, { Authorization: 'Bearer ' + custToken });
  check('Change password success', changePw.body?.success === true, `${changePw.status} ${changePw.body?.message}`);
  // Change back
  const custLogin2 = await post('/api/auth/login', { email: 'nguyenvana@gmail.com', password: '654321' });
  const custToken2 = custLogin2.body?.token;
  await put('/api/auth/change-password', { currentPassword: '654321', newPassword: '123456' }, { Authorization: 'Bearer ' + custToken2 });

  // ========== SUMMARY ==========
  console.log('\n==========================================');
  console.log(`PASSED: ${passed}`);
  console.log(`FAILED: ${failed}`);
  if (errors.length > 0) {
    console.log('\nFAILED TESTS:');
    errors.forEach(e => console.log(`  - ${e.name}: ${e.detail}`));
  }
  console.log('==========================================');

  process.exit(failed > 0 ? 1 : 0);
}

runTests().catch(e => { console.error('Test error:', e); process.exit(1); });
