import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [tailwindcss(), react()],
  server: {
    port: 5330,
    host: true,
    proxy: {
      '/api': {
        target: 'http://localhost:5329',
        changeOrigin: true,
      },
    },
  },
})
