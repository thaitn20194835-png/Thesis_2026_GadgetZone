import { BrowserRouter as Router, Routes, Route, Outlet } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { AuthProvider } from './context/AuthContext';
import { CartProvider } from './context/CartContext';

import Header from './components/layout/Header';
import Footer from './components/layout/Footer';
import AdminLayout from './components/layout/AdminLayout';
import ChatWidget from './components/chatbot/ChatWidget';

import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Login from './pages/auth/Login';
import Register from './pages/auth/Register';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Orders from './pages/Orders';
import OrderDetail from './pages/OrderDetail';
import Profile from './pages/Profile';
import VnpayReturn from './pages/VnpayReturn';
import News from './pages/News';
import NewsDetail from './pages/NewsDetail';
import About from './pages/About';
import Contact from './pages/Contact';

import Dashboard from './pages/admin/Dashboard';
import AdminProducts from './pages/admin/AdminProducts';
import AdminProductForm from './pages/admin/AdminProductForm';
import AdminCategories from './pages/admin/AdminCategories';
import AdminBrands from './pages/admin/AdminBrands';
import AdminOrders from './pages/admin/AdminOrders';
import AdminUsers from './pages/admin/AdminUsers';
import AdminNews from './pages/admin/AdminNews';
import AdminNewsForm from './pages/admin/AdminNewsForm';
import AdminReviews from './pages/admin/AdminReviews';
import AdminOrderDetail from './pages/admin/AdminOrderDetail';
import AdminVouchers from './pages/admin/AdminVouchers';
import AdminSuppliers from './pages/admin/AdminSuppliers';
import AdminNewsComments from './pages/admin/AdminNewsComments';

const MainLayout = () => (
  <div className="flex flex-col min-h-screen">
    <Header />
    <main className="flex-1">
      <Outlet />
    </main>
    <Footer />
    <ChatWidget />
  </div>
);

function App() {
  return (
    <Router>
      <AuthProvider>
        <CartProvider>
          <Routes>
            {/* Auth routes — no Header/Footer */}
            <Route path="/dang-nhap" element={<Login />} />
            <Route path="/dang-ky" element={<Register />} />

            <Route element={<MainLayout />}>
              <Route path="/" element={<Home />} />
              <Route path="/san-pham" element={<Products />} />
              <Route path="/san-pham/:id" element={<ProductDetail />} />
              <Route path="/gio-hang" element={<Cart />} />
              <Route path="/dat-hang" element={<Checkout />} />
              <Route path="/don-hang" element={<Orders />} />
              <Route path="/don-hang/:id" element={<OrderDetail />} />
              <Route path="/tai-khoan" element={<Profile />} />
              <Route path="/vnpay-return" element={<VnpayReturn />} />
              <Route path="/tin-tuc" element={<News />} />
              <Route path="/tin-tuc/:id" element={<NewsDetail />} />
              <Route path="/gioi-thieu" element={<About />} />
              <Route path="/lien-he" element={<Contact />} />
            </Route>

            <Route path="/admin" element={<AdminLayout />}>
              <Route index element={<Dashboard />} />
              <Route path="san-pham" element={<AdminProducts />} />
              <Route path="san-pham/them" element={<AdminProductForm />} />
              <Route path="san-pham/sua/:id" element={<AdminProductForm />} />
              <Route path="danh-muc" element={<AdminCategories />} />
              <Route path="thuong-hieu" element={<AdminBrands />} />
              <Route path="don-hang" element={<AdminOrders />} />
              <Route path="don-hang/:id" element={<AdminOrderDetail />} />
              <Route path="nguoi-dung" element={<AdminUsers />} />
              <Route path="tin-tuc" element={<AdminNews />} />
              <Route path="tin-tuc/them" element={<AdminNewsForm />} />
              <Route path="tin-tuc/sua/:id" element={<AdminNewsForm />} />
              <Route path="binh-luan" element={<AdminNewsComments />} />
              <Route path="danh-gia" element={<AdminReviews />} />
              <Route path="voucher" element={<AdminVouchers />} />
              <Route path="ncc" element={<AdminSuppliers />} />
            </Route>
          </Routes>
          <ToastContainer
            position="top-right"
            autoClose={3000}
            hideProgressBar={false}
            closeOnClick
            pauseOnHover
            theme="light"
          />
        </CartProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;
