import api from './api';

export const newsCommentService = {
  getByNews: (newsId) => api.get(`/news-comments/news/${newsId}`),
  create: (newsId, content) => api.post('/news-comments', { newsId, content }),
  adminGetAll: () => api.get('/news-comments/admin/all'),
  toggleApprove: (id) => api.put(`/news-comments/${id}/approve`),
  delete: (id) => api.delete(`/news-comments/${id}`),
};
