import api from './api';

export const voucherService = {
  getActive: () => api.get('/vouchers/active'),
  verify: (code, orderAmount) => api.post('/vouchers/verify', { code, orderAmount }),
  adminGetAll: () => api.get('/vouchers/admin/all'),
  create: (data) => api.post('/vouchers', data),
  update: (id, data) => api.put(`/vouchers/${id}`, data),
  delete: (id) => api.delete(`/vouchers/${id}`),
};
