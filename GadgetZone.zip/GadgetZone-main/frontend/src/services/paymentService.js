import api from './api';

export const paymentService = {
  createVnpayUrl: (orderId) => api.post('/payment/vnpay/create', { orderId }),
  // Forward toàn bộ query VNPay trả về cho backend verify chữ ký + cập nhật đơn hàng
  verifyVnpayReturn: (search) => api.get(`/payment/vnpay/return${search}`),
};
