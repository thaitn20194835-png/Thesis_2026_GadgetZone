import api from './api';

export const newsService = {
  getAll: (params) => api.get('/news', { params }),
  adminGetAll: () => api.get('/news/admin/all'),
  getById: (id) => api.get(`/news/${id}`),
  create: (data) => api.post('/news', data),
  update: (id, data) => api.put(`/news/${id}`, data),
  delete: (id) => api.delete(`/news/${id}`),
};
