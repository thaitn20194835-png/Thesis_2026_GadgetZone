import api from './api';

export const userService = {
  getAll: () => api.get('/users'),
  toggleActive: (id) => api.put(`/users/${id}/toggle-active`),
  getStats: () => api.get('/users/stats'),
};
