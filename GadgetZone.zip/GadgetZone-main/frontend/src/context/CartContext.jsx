import { createContext, useContext, useState, useEffect } from 'react';
import { cartService } from '../services/cartService';
import { useAuth } from './AuthContext';

const CartContext = createContext();

export const useCart = () => useContext(CartContext);

export const CartProvider = ({ children }) => {
  const { user } = useAuth();
  const [cart, setCart] = useState(null);
  const [cartCount, setCartCount] = useState(0);

  const fetchCart = async () => {
    if (!user) {
      setCart(null);
      setCartCount(0);
      return;
    }
    try {
      const res = await cartService.getCart();
      setCart(res.data.data);
      setCartCount(res.data.data.items?.reduce((sum, item) => sum + item.quantity, 0) || 0);
    } catch {
      setCart(null);
      setCartCount(0);
    }
  };

  useEffect(() => {
    fetchCart();
  }, [user]);

  const addToCart = async (productId, quantity = 1) => {
    const res = await cartService.addToCart(productId, quantity);
    setCart(res.data.data);
    setCartCount(res.data.data.items?.reduce((sum, item) => sum + item.quantity, 0) || 0);
    return res.data;
  };

  const updateQuantity = async (productId, quantity) => {
    const res = await cartService.updateQuantity(productId, quantity);
    setCart(res.data.data);
    setCartCount(res.data.data.items?.reduce((sum, item) => sum + item.quantity, 0) || 0);
  };

  const removeFromCart = async (productId) => {
    const res = await cartService.removeFromCart(productId);
    setCart(res.data.data);
    setCartCount(res.data.data.items?.reduce((sum, item) => sum + item.quantity, 0) || 0);
  };

  const clearCart = async () => {
    await cartService.clearCart();
    setCart(null);
    setCartCount(0);
  };

  return (
    <CartContext.Provider value={{ cart, cartCount, fetchCart, addToCart, updateQuantity, removeFromCart, clearCart }}>
      {children}
    </CartContext.Provider>
  );
};
