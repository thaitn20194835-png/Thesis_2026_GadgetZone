import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  FiArrowRight, FiArrowUpRight, FiTruck, FiShield, FiRefreshCw, FiHeadphones,
  FiSmartphone, FiMonitor, FiTablet, FiWatch, FiZap, FiClock, FiTrendingUp,
} from 'react-icons/fi';
import { categoryService } from '../services/categoryService';
import { productService } from '../services/productService';
import { brandService } from '../services/brandService';
import { newsService } from '../services/newsService';
import ProductCard from '../components/common/ProductCard';

const CATEGORY_ICONS = {
  'Điện thoại': FiSmartphone,
  'Laptop': FiMonitor,
  'Tablet': FiTablet,
  'Đồng hồ thông minh': FiWatch,
  'Âm thanh': FiHeadphones,
  'Phụ kiện': FiZap,
};

const TRUST = [
  { icon: FiTruck, title: 'Giao hàng miễn phí', desc: 'Đơn từ 500.000đ' },
  { icon: FiShield, title: 'Bảo hành chính hãng', desc: '12 tháng toàn quốc' },
  { icon: FiRefreshCw, title: 'Đổi trả 30 ngày', desc: 'Không cần lý do' },
  { icon: FiHeadphones, title: 'Hỗ trợ 24/7', desc: 'Hotline 1900 1234' },
];

const Home = () => {
  const [categories, setCategories] = useState([]);
  const [featured, setFeatured] = useState([]);
  const [allProducts, setAllProducts] = useState([]);
  const [brands, setBrands] = useState([]);
  const [news, setNews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [countdown, setCountdown] = useState({ h: 12, m: 30, s: 0 });

  useEffect(() => {
    const fetchAll = async () => {
      try {
        const [catRes, featRes, allRes, brandRes, newsRes] = await Promise.all([
          categoryService.getAll(),
          productService.getAll({ featured: true, limit: 8 }),
          productService.getAll({ limit: 12 }),
          brandService.getAll(),
          newsService.getAll({ limit: 3 }),
        ]);
        setCategories(catRes.data.data || catRes.data || []);
        setFeatured(featRes.data.data || featRes.data || []);
        setAllProducts(allRes.data.data || allRes.data || []);
        setBrands(brandRes.data.data || brandRes.data || []);
        setNews(newsRes.data.data || newsRes.data || []);
      } catch (err) {
        console.error('Lỗi tải trang chủ:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchAll();
  }, []);

  // Countdown for flash sale (visual only)
  useEffect(() => {
    const id = setInterval(() => {
      setCountdown((c) => {
        let { h, m, s } = c;
        if (s > 0) s -= 1;
        else if (m > 0) { m -= 1; s = 59; }
        else if (h > 0) { h -= 1; m = 59; s = 59; }
        return { h, m, s };
      });
    }, 1000);
    return () => clearInterval(id);
  }, []);

  const heroProduct = featured[0];
  const flashSaleProducts = allProducts.filter((p) => p.salePrice && p.salePrice < p.price).slice(0, 6);
  const newArrivals = allProducts.slice(0, 8);

  const pad = (n) => String(n).padStart(2, '0');

  return (
    <div className="bg-[#FAFAFA]">
      {/* ========== HERO — editorial split ========== */}
      <section className="bg-gradient-to-br from-blue-50 via-white to-orange-50 border-b border-slate-200 relative overflow-hidden">
        <div className="absolute -top-40 -right-40 w-[500px] h-[500px] rounded-full bg-primary/10 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-40 -left-40 w-[500px] h-[500px] rounded-full bg-accent/10 blur-3xl pointer-events-none" />
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-12 lg:py-16 grid lg:grid-cols-12 gap-10 items-center relative">
          {/* Left content */}
          <div className="lg:col-span-6 gz-reveal">
            <div className="inline-flex items-center gap-2 mb-5 bg-primary-light px-3 py-1.5 rounded-full">
              <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
              <span className="text-[11px] font-bold text-primary uppercase tracking-wider">Bộ sưu tập 2026</span>
            </div>

            <h1 className="font-heading font-black text-[44px] sm:text-[56px] lg:text-[68px] leading-[1] tracking-[-0.03em] text-[#0B1120]">
              Công nghệ
              <span className="block">định hình</span>
              <span className="block text-primary">phong cách.</span>
            </h1>

            <p className="text-slate-600 text-[15px] lg:text-[16px] mt-7 max-w-[460px] leading-relaxed">
              Khám phá những thiết bị điện tử mới nhất từ Apple, Samsung, Sony và các thương hiệu hàng đầu thế giới — chính hãng, giá tốt và giao tận tay trên toàn quốc.
            </p>

            <div className="flex flex-wrap gap-3 mt-9">
              <Link
                to="/san-pham"
                className="bg-[#0B1120] hover:bg-primary text-white px-7 py-4 rounded-lg font-semibold text-[14px] tracking-wide inline-flex items-center gap-2.5 transition-all hover:gap-3.5"
              >
                Mua sắm ngay
                <FiArrowRight />
              </Link>
              <Link
                to="/tin-tuc"
                className="px-7 py-4 rounded-lg font-medium text-[14px] text-[#0B1120] inline-flex items-center gap-2 hover:gap-3 transition-all border border-slate-300 hover:border-[#0B1120]"
              >
                Đọc tin công nghệ
                <FiArrowUpRight />
              </Link>
            </div>

            {/* Inline stats */}
            <div className="grid grid-cols-3 gap-6 mt-12 pt-8 border-t border-slate-200 max-w-[440px]">
              <div>
                <div className="font-heading text-[28px] font-extrabold text-[#0B1120] tracking-tight">1000+</div>
                <div className="text-[12px] text-slate-500 mt-0.5">Sản phẩm</div>
              </div>
              <div>
                <div className="font-heading text-[28px] font-extrabold text-[#0B1120] tracking-tight">63</div>
                <div className="text-[12px] text-slate-500 mt-0.5">Tỉnh thành</div>
              </div>
              <div>
                <div className="font-heading text-[28px] font-extrabold text-[#0B1120] tracking-tight">4.9★</div>
                <div className="text-[12px] text-slate-500 mt-0.5">Đánh giá</div>
              </div>
            </div>
          </div>

          {/* Right hero card */}
          <div className="lg:col-span-6 gz-reveal" style={{ animationDelay: '.15s' }}>
            <div className="relative">
              {/* Decorative number */}
              <div className="hidden lg:block absolute -top-6 -left-2 font-heading font-black text-[180px] leading-none text-slate-100 select-none pointer-events-none">
                01
              </div>

              <div className="relative bg-white border border-slate-200 rounded-2xl p-6 lg:p-10 overflow-hidden">
                {heroProduct ? (
                  <>
                    <div className="flex items-center justify-between mb-4">
                      <span className="gz-eyebrow text-primary">Sản phẩm nổi bật</span>
                      <span className="text-[11px] text-slate-400 font-mono">/ FEATURED</span>
                    </div>

                    <Link to={`/san-pham/${heroProduct._id}`} className="block group">
                      <div className="aspect-[4/3] bg-slate-50 rounded-xl overflow-hidden mb-5">
                        {heroProduct.images?.[0] && (
                          <img
                            src={heroProduct.images[0]}
                            alt={heroProduct.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                          />
                        )}
                      </div>

                      <div className="flex items-end justify-between gap-4">
                        <div className="min-w-0">
                          <span className="text-[10.5px] tracking-[0.18em] uppercase font-bold text-slate-400">
                            {heroProduct.brand?.name}
                          </span>
                          <h3 className="font-heading text-[20px] lg:text-[22px] font-bold text-[#0B1120] mt-1 leading-tight line-clamp-2">
                            {heroProduct.name}
                          </h3>
                          <div className="flex items-baseline gap-2 mt-2.5">
                            <span className="text-[22px] font-extrabold text-[#0B1120]">
                              {((heroProduct.salePrice || heroProduct.price) / 1_000_000).toFixed(2).replace(/\.?0+$/, '').replace('.', ',')} triệu
                            </span>
                            {heroProduct.salePrice > 0 && (
                              <span className="text-[13px] text-slate-400 line-through">
                                {(heroProduct.price / 1_000_000).toFixed(2).replace(/\.?0+$/, '').replace('.', ',')} triệu
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="flex-shrink-0 w-12 h-12 rounded-full bg-[#0B1120] text-white flex items-center justify-center group-hover:bg-primary group-hover:rotate-45 transition-all">
                          <FiArrowUpRight className="text-lg" />
                        </div>
                      </div>
                    </Link>
                  </>
                ) : (
                  <div className="aspect-[4/3] bg-slate-100 rounded-xl flex items-center justify-center text-slate-400">
                    Đang tải sản phẩm...
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ========== TRUST BAR ========== */}
      <section className="bg-white border-b border-slate-200">
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-6 grid grid-cols-2 md:grid-cols-4 gap-4 lg:gap-6">
          {TRUST.map((t, i) => {
            const Icon = t.icon;
            return (
              <div key={i} className="flex items-center gap-3.5">
                <div className="w-10 h-10 rounded-lg bg-slate-100 flex items-center justify-center text-[#0B1120] flex-shrink-0">
                  <Icon className="text-[18px]" />
                </div>
                <div className="min-w-0">
                  <div className="text-[13px] font-bold text-[#0B1120] leading-tight">{t.title}</div>
                  <div className="text-[11.5px] text-slate-500 mt-0.5">{t.desc}</div>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* ========== CATEGORIES — bento grid ========== */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 py-16 bg-[#FAFAFA]">
        <div className="flex items-end justify-between mb-8 gap-4 flex-wrap">
          <div>
            <span className="gz-eyebrow text-primary">Danh mục</span>
            <h2 className="font-heading text-[28px] lg:text-[36px] font-extrabold text-[#0B1120] tracking-tight leading-tight mt-2">
              Mua sắm theo danh mục
            </h2>
          </div>
          <Link to="/san-pham" className="text-[13px] font-semibold text-[#0B1120] hover:text-primary inline-flex items-center gap-1.5 group">
            Xem tất cả <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {loading ? (
          <div className="text-slate-400 text-sm text-center py-12">Đang tải...</div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 lg:gap-4">
            {categories.map((cat, idx) => {
              const Icon = CATEGORY_ICONS[cat.name] || FiZap;
              const palettes = [
                { bg: 'bg-blue-50', icon: 'bg-primary text-white', border: 'hover:border-primary' },
                { bg: 'bg-orange-50', icon: 'bg-accent text-white', border: 'hover:border-accent' },
                { bg: 'bg-emerald-50', icon: 'bg-emerald-500 text-white', border: 'hover:border-emerald-500' },
                { bg: 'bg-purple-50', icon: 'bg-purple-500 text-white', border: 'hover:border-purple-500' },
                { bg: 'bg-pink-50', icon: 'bg-pink-500 text-white', border: 'hover:border-pink-500' },
                { bg: 'bg-amber-50', icon: 'bg-amber-500 text-white', border: 'hover:border-amber-500' },
              ];
              const c = palettes[idx % palettes.length];
              return (
                <Link
                  key={cat._id}
                  to={`/san-pham?category=${cat._id}`}
                  className={`group relative ${c.bg} border-2 border-transparent ${c.border} rounded-xl p-5 lg:p-6 transition-all overflow-hidden`}
                >
                  <div className="absolute top-3 right-3 text-[11px] text-slate-400 font-mono font-bold">
                    {String(idx + 1).padStart(2, '0')}
                  </div>
                  <div className={`w-12 h-12 rounded-xl ${c.icon} flex items-center justify-center text-[20px] mb-4 group-hover:scale-110 transition-transform`}>
                    <Icon />
                  </div>
                  <div className="font-semibold text-[14px] text-[#0B1120] leading-tight">{cat.name}</div>
                  <div className="flex items-center gap-1 text-[11.5px] text-slate-500 mt-1.5 font-medium">
                    Xem ngay
                    <FiArrowRight className="text-[10px] group-hover:translate-x-0.5 transition-transform" />
                  </div>
                </Link>
              );
            })}
          </div>
        )}
      </section>

      {/* ========== FLASH SALE ========== */}
      {flashSaleProducts.length > 0 && (
        <section className="bg-orange-50 border-y border-orange-200/60">
          <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-14">
            <div className="flex flex-wrap items-end justify-between gap-4 mb-8">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-accent text-white flex items-center justify-center">
                  <FiZap className="text-[22px]" />
                </div>
                <div>
                  <span className="gz-eyebrow text-accent">Khuyến mãi sốc</span>
                  <h2 className="font-heading text-[26px] lg:text-[32px] font-extrabold text-[#0B1120] tracking-tight leading-tight mt-1">
                    Flash Sale hôm nay
                  </h2>
                </div>
              </div>

              {/* Countdown */}
              <div className="flex items-center gap-3">
                <FiClock className="text-slate-400" />
                <span className="text-[12px] text-slate-500 font-medium">Kết thúc sau:</span>
                <div className="flex items-center gap-1 font-mono">
                  {[
                    { v: pad(countdown.h), l: 'GIỜ' },
                    { v: pad(countdown.m), l: 'PHÚT' },
                    { v: pad(countdown.s), l: 'GIÂY' },
                  ].map((u, i) => (
                    <div key={i} className="flex items-center gap-1">
                      <div className="bg-[#0B1120] text-white px-2.5 py-1.5 rounded-md text-[14px] font-bold min-w-[36px] text-center">
                        {u.v}
                      </div>
                      {i < 2 && <span className="text-slate-300">:</span>}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 lg:gap-4">
              {flashSaleProducts.map((p) => (
                <ProductCard key={p._id} product={p} compact />
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ========== FEATURED PRODUCTS ========== */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 py-16">
        <div className="flex items-end justify-between mb-8 gap-4 flex-wrap">
          <div>
            <span className="gz-eyebrow text-primary">Lựa chọn của tuần</span>
            <h2 className="font-heading text-[28px] lg:text-[36px] font-extrabold text-[#0B1120] tracking-tight leading-tight mt-2">
              Sản phẩm nổi bật
            </h2>
            <p className="text-slate-500 text-[14px] mt-2 max-w-[520px]">
              Những sản phẩm được khách hàng và biên tập viên GadgetZone đánh giá cao nhất.
            </p>
          </div>
          <Link to="/san-pham" className="text-[13px] font-semibold text-[#0B1120] hover:text-primary inline-flex items-center gap-1.5 group">
            Tất cả sản phẩm <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {loading ? (
          <div className="text-slate-400 text-sm text-center py-12">Đang tải...</div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-5">
            {featured.map((p) => <ProductCard key={p._id} product={p} />)}
          </div>
        )}
      </section>

      {/* ========== EDITORIAL BANNER ========== */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 pb-16">
        <div className="grid lg:grid-cols-2 gap-4 lg:gap-5">
          <div className="bg-[#0B1120] text-white rounded-2xl p-8 lg:p-10 relative overflow-hidden min-h-[280px] flex flex-col justify-between">
            <div className="absolute -bottom-12 -right-12 w-64 h-64 rounded-full bg-primary/20 blur-3xl pointer-events-none" />
            <div className="relative">
              <span className="gz-eyebrow text-blue-400">Apple · Mới ra mắt</span>
              <h3 className="font-heading text-[28px] lg:text-[36px] font-black tracking-tight leading-tight mt-3 max-w-[400px]">
                iPhone 15 Pro Max — Titan & Sức mạnh A17 Pro
              </h3>
            </div>
            <div className="relative">
              <Link to="/san-pham?search=iPhone" className="inline-flex items-center gap-2.5 text-[14px] font-semibold border-b-2 border-white pb-1.5 hover:gap-4 transition-all">
                Khám phá ngay <FiArrowRight />
              </Link>
            </div>
          </div>

          <div className="bg-accent text-white rounded-2xl p-8 lg:p-10 relative overflow-hidden min-h-[280px] flex flex-col justify-between">
            <div className="absolute -top-12 -left-12 w-64 h-64 rounded-full bg-white/10 blur-3xl pointer-events-none" />
            <div className="relative">
              <span className="gz-eyebrow text-orange-100">Laptop · Trả góp 0%</span>
              <h3 className="font-heading text-[28px] lg:text-[36px] font-black tracking-tight leading-tight mt-3 max-w-[400px]">
                Sở hữu MacBook Pro M3 chỉ từ 4 triệu/tháng
              </h3>
            </div>
            <div className="relative">
              <Link to="/san-pham?search=MacBook" className="inline-flex items-center gap-2.5 text-[14px] font-semibold border-b-2 border-white pb-1.5 hover:gap-4 transition-all">
                Xem chi tiết <FiArrowRight />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ========== NEW ARRIVALS ========== */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 pb-16">
        <div className="flex items-end justify-between mb-8 gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <FiTrendingUp className="text-primary text-[22px]" />
            <h2 className="font-heading text-[26px] lg:text-[32px] font-extrabold text-[#0B1120] tracking-tight leading-tight">
              Hàng mới về
            </h2>
          </div>
          <Link to="/san-pham?sort=newest" className="text-[13px] font-semibold text-[#0B1120] hover:text-primary inline-flex items-center gap-1.5 group">
            Xem thêm <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>

        {loading ? null : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 lg:gap-5">
            {newArrivals.map((p) => <ProductCard key={p._id} product={p} />)}
          </div>
        )}
      </section>

      {/* ========== BRAND STRIP ========== */}
      {brands.length > 0 && (
        <section className="bg-white border-y border-slate-200 py-10">
          <div className="max-w-[1240px] mx-auto px-4 lg:px-6">
            <p className="gz-eyebrow text-center text-slate-500 mb-6">Hợp tác cùng những thương hiệu hàng đầu thế giới</p>
            <div className="grid grid-cols-3 sm:grid-cols-5 lg:grid-cols-10 gap-6 items-center">
              {brands.map((b) => (
                <div key={b._id} className="h-10 flex items-center justify-center group">
                  {b.logo ? (
                    <img
                      src={b.logo}
                      alt={b.name}
                      className="h-7 w-auto object-contain opacity-50 group-hover:opacity-100 transition-opacity duration-300"
                      style={{ filter: 'grayscale(100%)' }}
                      onMouseEnter={(e) => e.target.style.filter = 'grayscale(0%)'}
                      onMouseLeave={(e) => e.target.style.filter = 'grayscale(100%)'}
                    />
                  ) : (
                    <span className="text-[13px] font-bold text-slate-400 group-hover:text-[#0B1120] transition-colors">
                      {b.name}
                    </span>
                  )}
                </div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ========== NEWS PREVIEW ========== */}
      {news.length > 0 && (
        <section className="max-w-[1240px] mx-auto px-4 lg:px-6 py-16">
          <div className="flex items-end justify-between mb-8 gap-4 flex-wrap">
            <div>
              <span className="gz-eyebrow text-primary">Tạp chí</span>
              <h2 className="font-heading text-[28px] lg:text-[36px] font-extrabold text-[#0B1120] tracking-tight leading-tight mt-2">
                Tin tức công nghệ
              </h2>
            </div>
            <Link to="/tin-tuc" className="text-[13px] font-semibold text-[#0B1120] hover:text-primary inline-flex items-center gap-1.5 group">
              Tất cả bài viết <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid lg:grid-cols-3 gap-5">
            {news.slice(0, 3).map((n, idx) => (
              <Link
                key={n._id}
                to={`/tin-tuc/${n._id}`}
                className={`group block bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-[#0B1120] transition ${idx === 0 ? 'lg:col-span-1' : ''}`}
              >
                <div className="aspect-[16/10] overflow-hidden bg-slate-100">
                  {n.image && (
                    <img
                      src={n.image}
                      alt={n.title}
                      loading="lazy"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                  )}
                </div>
                <div className="p-5 lg:p-6">
                  <div className="flex items-center gap-2 mb-3">
                    {n.tags?.slice(0, 2).map((t) => (
                      <span key={t} className="text-[10.5px] tracking-wider uppercase font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                        {t}
                      </span>
                    ))}
                  </div>
                  <h3 className="font-heading text-[17px] lg:text-[18px] font-bold text-[#0B1120] line-clamp-2 leading-tight group-hover:text-primary transition-colors">
                    {n.title}
                  </h3>
                  <p className="text-[13px] text-slate-500 mt-2 line-clamp-2 leading-relaxed">{n.summary}</p>
                  <div className="flex items-center gap-2 mt-4 text-[12px] text-slate-400 font-medium">
                    {n.author} · {new Date(n.createdAt || Date.now()).toLocaleDateString('vi-VN')}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      )}
    </div>
  );
};

export default Home;
