import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiEye, FiPackage } from 'react-icons/fi';
import { orderService } from '../services/orderService';
import { toast } from 'react-toastify';

const statusMap = {
  pending: { label: 'Chờ xác nhận', cls: 'bg-amber-50 text-amber-600' },
  confirmed: { label: 'Đã xác nhận', cls: 'bg-blue-50 text-blue-600' },
  shipping: { label: 'Đang giao', cls: 'bg-indigo-50 text-indigo-600' },
  delivered: { label: 'Đã giao', cls: 'bg-green-50 text-green-600' },
  cancelled: { label: 'Đã hủy', cls: 'bg-red-50 text-red-600' },
};

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrders = async () => {
      try {
        const res = await orderService.getMyOrders();
        setOrders(res.data.data || res.data || []);
      } catch {
        toast.error('Không thể tải danh sách đơn hàng');
      } finally {
        setLoading(false);
      }
    };
    fetchOrders();
  }, []);

  const formatPrice = (price) => price?.toLocaleString('vi-VN') + 'đ';

  if (loading)
    return (
      <div className="max-w-[960px] mx-auto px-4 py-10 text-center text-slate-500">
        Đang tải...
      </div>
    );

  return (
    <div className="max-w-[960px] mx-auto px-4 py-10">
      <h1 className="font-heading font-bold text-2xl mb-6">Lịch sử đơn hàng</h1>

      {orders.length === 0 ? (
        <div className="text-center py-16">
          <FiPackage className="mx-auto text-4xl text-slate-300 mb-4" />
          <h2 className="font-semibold text-lg text-slate-700">Chưa có đơn hàng</h2>
          <p className="text-sm text-slate-500 mt-1">Bạn chưa có đơn hàng nào.</p>
          <Link
            to="/san-pham"
            className="inline-block mt-5 bg-primary text-white px-6 py-2.5 rounded-lg text-sm font-semibold"
          >
            Mua sắm ngay
          </Link>
        </div>
      ) : (
        <div className="bg-white border rounded-lg overflow-hidden">
          <table className="w-full">
            <thead>
              <tr>
                <th className="bg-slate-50 px-4 py-3 text-left text-[11px] uppercase font-semibold text-slate-500 tracking-wider">
                  Mã đơn
                </th>
                <th className="bg-slate-50 px-4 py-3 text-left text-[11px] uppercase font-semibold text-slate-500 tracking-wider">
                  Ngày đặt
                </th>
                <th className="bg-slate-50 px-4 py-3 text-left text-[11px] uppercase font-semibold text-slate-500 tracking-wider">
                  Tổng tiền
                </th>
                <th className="bg-slate-50 px-4 py-3 text-left text-[11px] uppercase font-semibold text-slate-500 tracking-wider">
                  Trạng thái
                </th>
                <th className="bg-slate-50 px-4 py-3 text-left text-[11px] uppercase font-semibold text-slate-500 tracking-wider"></th>
              </tr>
            </thead>
            <tbody>
              {orders.map((order) => {
                const status = statusMap[order.status] || {
                  label: order.status,
                  cls: 'bg-amber-50 text-amber-600',
                };
                return (
                  <tr key={order._id}>
                    <td className="px-4 py-3 text-sm border-t border-slate-100 font-medium">
                      #{order._id?.slice(-8).toUpperCase()}
                    </td>
                    <td className="px-4 py-3 text-sm border-t border-slate-100">
                      {new Date(order.createdAt).toLocaleDateString('vi-VN')}
                    </td>
                    <td className="px-4 py-3 text-sm border-t border-slate-100 font-semibold text-accent">
                      {formatPrice(order.totalAmount)}
                    </td>
                    <td className="px-4 py-3 text-sm border-t border-slate-100">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-semibold ${status.cls}`}
                      >
                        {status.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-sm border-t border-slate-100">
                      <Link
                        to={`/don-hang/${order._id}`}
                        className="text-primary text-sm hover:underline inline-flex items-center gap-1"
                      >
                        <FiEye /> Chi tiết
                      </Link>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Orders;
