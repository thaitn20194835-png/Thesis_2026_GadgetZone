import { useState } from 'react';
import { FiUser, FiLock, FiSave } from 'react-icons/fi';
import { useAuth } from '../context/AuthContext';
import { authService } from '../services/authService';
import { toast } from 'react-toastify';

const Profile = () => {
  const { user, updateUser } = useAuth();
  const [activeTab, setActiveTab] = useState('info');
  const [loading, setLoading] = useState(false);

  const [profileForm, setProfileForm] = useState({
    name: user?.name || '',
    phone: user?.phone || '',
    address: user?.address || '',
  });

  const [passwordForm, setPasswordForm] = useState({
    currentPassword: '',
    newPassword: '',
    confirmPassword: '',
  });

  const handleProfileChange = (e) => {
    setProfileForm({ ...profileForm, [e.target.name]: e.target.value });
  };

  const handlePasswordChange = (e) => {
    setPasswordForm({ ...passwordForm, [e.target.name]: e.target.value });
  };

  const handleProfileSubmit = async (e) => {
    e.preventDefault();
    if (!profileForm.name) {
      toast.warning('Vui lòng nhập họ và tên');
      return;
    }
    setLoading(true);
    try {
      const res = await authService.updateProfile(profileForm);
      updateUser(res.data.user || res.data.data);
      toast.success('Cập nhật thông tin thành công');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Cập nhật thất bại');
    } finally {
      setLoading(false);
    }
  };

  const handlePasswordSubmit = async (e) => {
    e.preventDefault();
    if (!passwordForm.currentPassword || !passwordForm.newPassword || !passwordForm.confirmPassword) {
      toast.warning('Vui lòng nhập đầy đủ thông tin');
      return;
    }
    if (passwordForm.newPassword !== passwordForm.confirmPassword) {
      toast.error('Mật khẩu mới không khớp');
      return;
    }
    if (passwordForm.newPassword.length < 6) {
      toast.warning('Mật khẩu mới phải có ít nhất 6 ký tự');
      return;
    }
    setLoading(true);
    try {
      await authService.changePassword({
        currentPassword: passwordForm.currentPassword,
        newPassword: passwordForm.newPassword,
      });
      toast.success('Đổi mật khẩu thành công');
      setPasswordForm({ currentPassword: '', newPassword: '', confirmPassword: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Đổi mật khẩu thất bại');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-[640px] mx-auto px-4 py-10">
      <h1 className="font-heading font-bold text-2xl mb-6">Tài khoản</h1>

      <div className="flex border-b-2 border-slate-200">
        <button
          className={`px-5 py-3 text-sm font-semibold cursor-pointer flex items-center gap-1.5 transition-colors ${
            activeTab === 'info'
              ? 'text-primary border-b-2 border-primary -mb-[2px]'
              : 'text-slate-500 hover:text-slate-700'
          }`}
          onClick={() => setActiveTab('info')}
        >
          <FiUser /> Thông tin cá nhân
        </button>
        <button
          className={`px-5 py-3 text-sm font-semibold cursor-pointer flex items-center gap-1.5 transition-colors ${
            activeTab === 'password'
              ? 'text-primary border-b-2 border-primary -mb-[2px]'
              : 'text-slate-500 hover:text-slate-700'
          }`}
          onClick={() => setActiveTab('password')}
        >
          <FiLock /> Đổi mật khẩu
        </button>
      </div>

      <div className="bg-white border rounded-lg p-7 mt-6">
        {activeTab === 'info' ? (
          <form className="space-y-5" onSubmit={handleProfileSubmit}>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Email</label>
              <input
                type="email"
                value={user?.email || ''}
                disabled
                className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm bg-slate-50 text-slate-400 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Họ và tên</label>
              <input
                type="text"
                name="name"
                placeholder="Nhập họ và tên"
                value={profileForm.name}
                onChange={handleProfileChange}
                className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Số điện thoại
              </label>
              <input
                type="tel"
                name="phone"
                placeholder="Nhập số điện thoại"
                value={profileForm.phone}
                onChange={handleProfileChange}
                className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">Địa chỉ</label>
              <input
                type="text"
                name="address"
                placeholder="Nhập địa chỉ"
                value={profileForm.address}
                onChange={handleProfileChange}
                className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </div>

            <button
              type="submit"
              className="bg-primary text-white px-7 py-3 rounded-lg font-semibold text-sm inline-flex items-center gap-1.5 hover:bg-primary-hover transition-colors disabled:opacity-60"
              disabled={loading}
            >
              <FiSave /> {loading ? 'Đang lưu...' : 'Lưu thay đổi'}
            </button>
          </form>
        ) : (
          <form className="space-y-5" onSubmit={handlePasswordSubmit}>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Mật khẩu hiện tại
              </label>
              <input
                type="password"
                name="currentPassword"
                placeholder="Nhập mật khẩu hiện tại"
                value={passwordForm.currentPassword}
                onChange={handlePasswordChange}
                className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Mật khẩu mới
              </label>
              <input
                type="password"
                name="newPassword"
                placeholder="Nhập mật khẩu mới (tối thiểu 6 ký tự)"
                value={passwordForm.newPassword}
                onChange={handlePasswordChange}
                className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-1.5">
                Xác nhận mật khẩu mới
              </label>
              <input
                type="password"
                name="confirmPassword"
                placeholder="Nhập lại mật khẩu mới"
                value={passwordForm.confirmPassword}
                onChange={handlePasswordChange}
                className="w-full border border-slate-200 rounded-lg px-4 py-2.5 text-sm focus:outline-none focus:border-primary focus:ring-1 focus:ring-primary"
              />
            </div>

            <button
              type="submit"
              className="bg-primary text-white px-7 py-3 rounded-lg font-semibold text-sm inline-flex items-center gap-1.5 hover:bg-primary-hover transition-colors disabled:opacity-60"
              disabled={loading}
            >
              <FiSave /> {loading ? 'Đang xử lý...' : 'Đổi mật khẩu'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
};

export default Profile;
