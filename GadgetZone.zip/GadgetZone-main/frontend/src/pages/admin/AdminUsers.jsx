import { useState, useEffect } from 'react';
import { FiLock, FiUnlock, FiSearch, FiUsers, FiShield, FiUser, FiMail, FiPhone } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { userService } from '../../services/userService';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('all');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try { setLoading(true); const res = await userService.getAll(); setUsers(res.data.data || res.data || []); }
    catch { toast.error('Không thể tải người dùng'); }
    finally { setLoading(false); }
  };

  const handleToggle = async (id, currentActive) => {
    const action = currentActive ? 'khóa' : 'mở khóa';
    if (!window.confirm(`Bạn có chắc muốn ${action} tài khoản này?`)) return;
    try {
      await userService.toggleActive(id);
      toast.success(`Đã ${action} tài khoản`);
      setUsers((prev) => prev.map((u) => (u._id === id ? { ...u, isActive: !u.isActive } : u)));
    } catch { toast.error('Không thể thực hiện'); }
  };

  const filtered = users.filter((u) => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!u.name?.toLowerCase().includes(q) && !u.email?.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  const stats = {
    total: users.length,
    admin: users.filter((u) => u.role === 'admin').length,
    customer: users.filter((u) => u.role !== 'admin').length,
    active: users.filter((u) => u.isActive !== false).length,
  };

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      <div>
        <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Người dùng</span>
        <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1">Quản lý tài khoản</h1>
        <p className="text-[13px] text-slate-500 mt-1">{users.length} tài khoản trong hệ thống</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { icon: FiUsers, label: 'Tổng số', value: stats.total, light: 'bg-blue-50', text: 'text-blue-600' },
          { icon: FiShield, label: 'Admin', value: stats.admin, light: 'bg-purple-50', text: 'text-purple-600' },
          { icon: FiUser, label: 'Khách hàng', value: stats.customer, light: 'bg-emerald-50', text: 'text-emerald-600' },
          { icon: FiUnlock, label: 'Hoạt động', value: stats.active, light: 'bg-amber-50', text: 'text-amber-600' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg ${s.light} ${s.text} flex items-center justify-center`}>
                <Icon className="text-[16px]" />
              </div>
              <div>
                <div className="text-[20px] font-extrabold text-[#0B1120]">{s.value}</div>
                <div className="text-[11px] text-slate-500">{s.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filter bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1">
          {[
            { k: 'all', label: 'Tất cả' },
            { k: 'customer', label: 'Khách hàng' },
            { k: 'admin', label: 'Admin' },
          ].map((t) => (
            <button
              key={t.k} onClick={() => setRoleFilter(t.k)}
              className={`px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition ${
                roleFilter === t.k ? 'bg-[#0B1120] text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex-1 min-w-[200px] flex items-center gap-2.5 px-3 bg-slate-50 rounded-lg h-10">
          <FiSearch className="text-slate-400" />
          <input
            value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm theo tên, email..."
            className="flex-1 bg-transparent outline-none text-[13px] placeholder:text-slate-400"
          />
        </div>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Người dùng</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Liên hệ</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Vai trò</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Trạng thái</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Ngày tạo</th>
                <th className="px-5 py-3 text-right text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-16 text-center">
                    <FiUsers className="text-3xl text-slate-300 mx-auto mb-3" />
                    <p className="text-slate-500 text-sm">Không có người dùng nào</p>
                  </td>
                </tr>
              ) : filtered.map((u) => {
                const isAdmin = u.role === 'admin';
                const isActive = u.isActive !== false;
                const palettes = ['bg-blue-500', 'bg-emerald-500', 'bg-purple-500', 'bg-pink-500', 'bg-orange-500', 'bg-amber-500'];
                const avatarColor = palettes[u._id?.charCodeAt(0) % palettes.length || 0];
                return (
                  <tr key={u._id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition group">
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-3">
                        <div className={`w-10 h-10 rounded-full ${avatarColor} text-white text-[14px] font-bold flex items-center justify-center flex-shrink-0`}>
                          {u.name?.charAt(0)?.toUpperCase() || '?'}
                        </div>
                        <div>
                          <div className="text-[13.5px] font-semibold text-[#0B1120]">{u.name}</div>
                          <div className="text-[11px] text-slate-500 font-mono">#{u._id?.slice(-6).toUpperCase()}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="space-y-1">
                        <div className="text-[12.5px] text-slate-700 flex items-center gap-1.5">
                          <FiMail className="text-slate-400 text-[11px]" /> {u.email}
                        </div>
                        {u.phone && (
                          <div className="text-[12px] text-slate-500 flex items-center gap-1.5">
                            <FiPhone className="text-slate-400 text-[11px]" /> {u.phone}
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-1 rounded-md ${
                        isAdmin ? 'bg-purple-50 text-purple-700' : 'bg-slate-100 text-slate-700'
                      }`}>
                        {isAdmin ? <FiShield className="text-[11px]" /> : <FiUser className="text-[11px]" />}
                        {isAdmin ? 'ADMIN' : 'KHÁCH HÀNG'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={`inline-flex items-center gap-1.5 text-[11px] font-bold border px-2.5 py-1 rounded-full ${
                        isActive ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${isActive ? 'bg-emerald-500' : 'bg-red-500'}`} />
                        {isActive ? 'HOẠT ĐỘNG' : 'ĐÃ KHÓA'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5 text-[12.5px] text-slate-500">
                      {new Date(u.createdAt).toLocaleDateString('vi-VN')}
                    </td>
                    <td className="px-5 py-3.5 text-right">
                      {!isAdmin && (
                        <button
                          onClick={() => handleToggle(u._id, isActive)}
                          className={`inline-flex items-center gap-1.5 text-[12px] font-semibold px-3 py-1.5 rounded-lg border transition opacity-60 group-hover:opacity-100 ${
                            isActive
                              ? 'border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300'
                              : 'border-emerald-200 text-emerald-600 hover:bg-emerald-50 hover:border-emerald-300'
                          }`}
                        >
                          {isActive ? <><FiLock className="text-[11px]" /> Khóa</> : <><FiUnlock className="text-[11px]" /> Mở khóa</>}
                        </button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
