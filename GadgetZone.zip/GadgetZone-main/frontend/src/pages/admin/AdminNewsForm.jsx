import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import {
  FiArrowLeft, FiSave, FiUpload, FiX, FiImage, FiInfo, FiTag, FiFileText, FiEye,
} from 'react-icons/fi';
import { toast } from 'react-toastify';
import { newsService } from '../../services/newsService';
import { uploadService } from '../../services/uploadService';

const initialForm = {
  title: '', summary: '', content: '', image: '',
  author: 'Admin GadgetZone', tags: [], isPublished: true,
};

export default function AdminNewsForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [form, setForm] = useState(initialForm);
  const [tagInput, setTagInput] = useState('');
  const [loading, setLoading] = useState(isEdit);
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    if (!isEdit) return;
    (async () => {
      try {
        const res = await newsService.getById(id);
        const a = res.data.data || res.data;
        setForm({
          title: a.title || '', summary: a.summary || '', content: a.content || '',
          image: a.image || '', author: a.author || 'Admin GadgetZone',
          tags: a.tags || [], isPublished: a.isPublished !== false,
        });
      } catch { toast.error('Không thể tải bài viết'); }
      finally { setLoading(false); }
    })();
  }, [id, isEdit]);

  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const handleUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) { toast.warning('File không phải ảnh'); return; }
    if (file.size > 5 * 1024 * 1024) { toast.warning('Ảnh quá 5MB'); return; }

    setUploading(true);
    try {
      const res = await uploadService.uploadImage(file);
      const url = res.data.data?.url || res.data.url;
      if (url) {
        setField('image', url);
        toast.success('Đã upload ảnh lên Cloudinary');
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Upload thất bại');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const addTag = () => {
    const t = tagInput.trim();
    if (!t) return;
    if (form.tags.includes(t)) { toast.info('Tag đã tồn tại'); return; }
    setField('tags', [...form.tags, t]);
    setTagInput('');
  };

  const removeTag = (tag) => setField('tags', form.tags.filter((t) => t !== tag));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.summary || !form.content) {
      toast.error('Vui lòng nhập đủ Tiêu đề, Tóm tắt, Nội dung');
      return;
    }
    setSubmitting(true);
    try {
      if (isEdit) {
        await newsService.update(id, form);
        toast.success('Đã cập nhật bài viết');
      } else {
        await newsService.create(form);
        toast.success('Đã đăng bài viết mới');
      }
      navigate('/admin/tin-tuc');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Có lỗi xảy ra');
    } finally { setSubmitting(false); }
  };

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  const wordCount = form.content.split(/\s+/).filter(Boolean).length;
  const readingTime = Math.max(1, Math.ceil(wordCount / 200));

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <Link to="/admin/tin-tuc" className="inline-flex items-center gap-2 text-[12.5px] font-semibold text-slate-500 hover:text-[#0B1120] mb-2 transition group">
            <FiArrowLeft className="group-hover:-translate-x-1 transition-transform" />
            Quay lại danh sách
          </Link>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-primary">{isEdit ? 'Chỉnh sửa' : 'Bài viết mới'}</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1 leading-tight">
            {isEdit ? 'Sửa bài viết' : 'Viết bài tin tức mới'}
          </h1>
        </div>
        <div className="flex gap-2">
          <Link to="/admin/tin-tuc" className="border border-slate-200 bg-white px-5 py-2.5 rounded-lg text-[13px] font-semibold text-slate-600 hover:border-slate-300 transition">
            Hủy
          </Link>
          <button onClick={handleSubmit} disabled={submitting} className="bg-[#0B1120] hover:bg-primary text-white px-6 py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition disabled:opacity-60">
            <FiSave /> {submitting ? 'Đang lưu...' : isEdit ? 'Cập nhật' : 'Đăng bài'}
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-5">
        {/* Left main */}
        <div className="lg:col-span-2 space-y-5">
          {/* Content */}
          <Card title="Nội dung bài viết" icon={FiFileText} accent="bg-blue-50 text-blue-600">
            <Field label="Tiêu đề" required>
              <input value={form.title} onChange={(e) => setField('title', e.target.value)}
                placeholder="VD: iPhone 16 Pro Max chính thức ra mắt..."
                className="ipt text-[15px] font-semibold" />
            </Field>

            <Field label="Tóm tắt (1-2 câu)" required>
              <textarea value={form.summary} onChange={(e) => setField('summary', e.target.value)} rows={3}
                placeholder="Đoạn tóm tắt ngắn gọn hiển thị trên trang danh sách..."
                className="ipt resize-none leading-relaxed" />
              <p className="text-[11px] text-slate-500 mt-1">{form.summary.length} ký tự</p>
            </Field>

            <Field label="Nội dung đầy đủ" required>
              <textarea value={form.content} onChange={(e) => setField('content', e.target.value)} rows={20}
                placeholder="Viết nội dung chi tiết bài viết tại đây...

Hỗ trợ markdown đơn giản:
**Tiêu đề mục** sẽ in đậm thành heading
Đoạn văn mới: cách 2 dòng

Các đoạn được hiển thị với spacing tự động."
                className="ipt resize-y leading-[1.8] font-mono text-[13px]" />
              <div className="flex items-center justify-between mt-2 text-[11.5px] text-slate-500">
                <span>{wordCount} từ</span>
                <span>~{readingTime} phút đọc</span>
              </div>
            </Field>
          </Card>

          {/* Preview */}
          {form.image && form.title && (
            <Card title="Xem trước" icon={FiEye} accent="bg-emerald-50 text-emerald-600">
              <div className="border border-slate-200 rounded-xl overflow-hidden">
                <div className="aspect-[16/10] bg-slate-100">
                  <img src={form.image} alt={form.title} className="w-full h-full object-cover" />
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    {form.tags.slice(0, 2).map((t) => (
                      <span key={t} className="text-[10px] uppercase tracking-wider font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">{t}</span>
                    ))}
                  </div>
                  <h3 className="font-heading text-[18px] font-bold text-[#0B1120] line-clamp-2 leading-tight">{form.title}</h3>
                  <p className="text-[13px] text-slate-500 mt-2 line-clamp-2">{form.summary}</p>
                </div>
              </div>
            </Card>
          )}
        </div>

        {/* Right sidebar */}
        <div className="space-y-5">
          {/* Featured image */}
          <Card title="Ảnh đại diện" icon={FiImage} accent="bg-purple-50 text-purple-600">
            <input ref={fileInputRef} type="file" accept="image/*" onChange={handleUpload} className="hidden" />

            {form.image ? (
              <div className="relative group rounded-lg overflow-hidden border-2 border-slate-200">
                <img src={form.image} alt="cover" className="w-full aspect-[16/10] object-cover" />
                <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                  <button type="button" onClick={() => fileInputRef.current?.click()} className="bg-white text-[#0B1120] px-3 py-1.5 rounded-md text-[12px] font-semibold hover:bg-slate-100 transition">
                    Đổi ảnh
                  </button>
                  <button type="button" onClick={() => setField('image', '')} className="bg-red-500 text-white px-3 py-1.5 rounded-md text-[12px] font-semibold hover:bg-red-600 transition">
                    Xóa
                  </button>
                </div>
              </div>
            ) : (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                disabled={uploading}
                className="w-full border-2 border-dashed border-slate-300 hover:border-primary rounded-xl p-6 transition group bg-slate-50 hover:bg-primary-light disabled:opacity-60"
              >
                <div className="flex flex-col items-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-white border border-slate-200 group-hover:border-primary flex items-center justify-center text-slate-400 group-hover:text-primary transition">
                    {uploading ? (
                      <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                    ) : (
                      <FiUpload />
                    )}
                  </div>
                  <p className="text-[13px] font-semibold text-[#0B1120]">
                    {uploading ? 'Đang upload...' : 'Tải ảnh đại diện'}
                  </p>
                  <p className="text-[11px] text-slate-500">PNG, JPG — tối đa 5MB</p>
                </div>
              </button>
            )}

            <div className="mt-3">
              <p className="text-[11px] text-slate-500 mb-1.5 font-bold uppercase tracking-wide">Hoặc dán URL ảnh</p>
              <input value={form.image} onChange={(e) => setField('image', e.target.value)}
                placeholder="https://..."
                className="ipt text-[12px]" />
            </div>
          </Card>

          {/* Tags */}
          <Card title="Tags" icon={FiTag} accent="bg-pink-50 text-pink-600">
            <div className="flex flex-wrap gap-1.5 mb-3 min-h-[24px]">
              {form.tags.length === 0 ? (
                <p className="text-[12px] text-slate-400">Chưa có tag nào</p>
              ) : form.tags.map((t) => (
                <span key={t} className="inline-flex items-center gap-1 bg-primary-light text-primary text-[11.5px] font-semibold px-2.5 py-1 rounded-full">
                  {t}
                  <button type="button" onClick={() => removeTag(t)} className="hover:bg-primary/20 rounded-full">
                    <FiX className="text-[11px]" />
                  </button>
                </span>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
                placeholder="Apple, iPhone, Review..."
                className="ipt flex-1"
              />
              <button type="button" onClick={addTag} className="bg-[#0B1120] hover:bg-primary text-white px-4 rounded-lg text-[12.5px] font-semibold transition">
                Thêm
              </button>
            </div>
            <p className="text-[10.5px] text-slate-500 mt-2">Nhấn Enter hoặc bấm Thêm. Tối đa 5 tag.</p>
          </Card>

          {/* Settings */}
          <Card title="Xuất bản" icon={FiInfo} accent="bg-amber-50 text-amber-600">
            <Field label="Tác giả">
              <input value={form.author} onChange={(e) => setField('author', e.target.value)} className="ipt" />
            </Field>

            <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition cursor-pointer">
              <input type="checkbox" checked={form.isPublished} onChange={(e) => setField('isPublished', e.target.checked)} className="w-4 h-4 accent-primary" />
              <div className="flex-1">
                <div className="text-[13px] font-semibold text-[#0B1120]">Đăng ngay</div>
                <div className="text-[11px] text-slate-500">{form.isPublished ? 'Bài viết hiển thị công khai' : 'Lưu dưới dạng nháp'}</div>
              </div>
              {form.isPublished ? (
                <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full">PUBLIC</span>
              ) : (
                <span className="text-[10px] font-bold uppercase tracking-wider bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-full">DRAFT</span>
              )}
            </label>
          </Card>
        </div>
      </form>

      <style>{`
        .ipt {
          width: 100%;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 8px;
          padding: 10px 14px;
          font-size: 13.5px;
          outline: none;
          transition: all .15s;
        }
        .ipt:focus { background: #fff; border-color: #0B1120; box-shadow: 0 0 0 3px rgba(11,17,32,0.08); }
      `}</style>
    </div>
  );
}

function Card({ title, icon: Icon, accent, children }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-3">
        <div className={`w-9 h-9 rounded-lg ${accent} flex items-center justify-center`}>
          <Icon className="text-[16px]" />
        </div>
        <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">{title}</h2>
      </div>
      <div className="p-6 space-y-4">{children}</div>
    </div>
  );
}

function Field({ label, required, children }) {
  return (
    <div>
      <label className="block text-[12px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
        {label} {required && <span className="text-red-500 normal-case">*</span>}
      </label>
      {children}
    </div>
  );
}
