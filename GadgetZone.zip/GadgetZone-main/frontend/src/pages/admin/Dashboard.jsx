import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  FiShoppingCart, FiDollarSign, FiClock, FiCheckCircle,
  FiTrendingUp, FiArrowRight, FiActivity, FiPackage, FiUsers, FiShoppingBag,
  FiAward, FiBarChart2,
} from 'react-icons/fi';
import { toast } from 'react-toastify';
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar, Legend,
} from 'recharts';
import { orderService } from '../../services/orderService';

const STATUS = {
  pending:   { label: 'Chờ xử lý', color: '#F59E0B', cls: 'bg-amber-50 text-amber-700 border-amber-200' },
  confirmed: { label: 'Đã xác nhận', color: '#3B82F6', cls: 'bg-blue-50 text-blue-700 border-blue-200' },
  shipping:  { label: 'Đang giao', color: '#6366F1', cls: 'bg-indigo-50 text-indigo-700 border-indigo-200' },
  delivered: { label: 'Đã giao', color: '#10B981', cls: 'bg-emerald-50 text-emerald-700 border-emerald-200' },
  cancelled: { label: 'Đã hủy', color: '#EF4444', cls: 'bg-red-50 text-red-700 border-red-200' },
};

export default function Dashboard() {
  const [stats, setStats] = useState({ totalOrders: 0, totalRevenue: 0, pendingOrders: 0, deliveredOrders: 0 });
  const [advanced, setAdvanced] = useState({ revenueByDay: [], topProducts: [], statusBreakdown: [] });
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [days, setDays] = useState(14);

  useEffect(() => {
    (async () => {
      try {
        setLoading(true);
        const [statsRes, advRes, ordersRes] = await Promise.all([
          orderService.getStats(),
          orderService.getStatsAdvanced(days),
          orderService.getAllOrders(),
        ]);
        setStats(statsRes.data.data || statsRes.data);
        setAdvanced(advRes.data.data || advRes.data);
        const sorted = (ordersRes.data.data || ordersRes.data || [])
          .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
          .slice(0, 6);
        setRecentOrders(sorted);
      } catch { toast.error('Không thể tải dữ liệu dashboard'); }
      finally { setLoading(false); }
    })();
  }, [days]);

  const fmt = (v) => (v || 0).toLocaleString('vi-VN') + '₫';
  const fmtShort = (v) => {
    const n = v || 0;
    if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, '').replace('.', ',')}tr`;
    if (n >= 1_000) return `${(n / 1_000).toFixed(0)}k`;
    return `${n}`;
  };

  const today = new Date().toLocaleDateString('vi-VN', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải dashboard...</div>;

  const STATS = [
    { icon: FiShoppingCart, label: 'Tổng đơn hàng', value: stats.totalOrders, accent: 'bg-blue-500', light: 'bg-blue-50', text: 'text-blue-600' },
    { icon: FiDollarSign, label: 'Doanh thu', value: fmt(stats.totalRevenue), short: true, accent: 'bg-emerald-500', light: 'bg-emerald-50', text: 'text-emerald-600' },
    { icon: FiClock, label: 'Đơn chờ xử lý', value: stats.pendingOrders, accent: 'bg-amber-500', light: 'bg-amber-50', text: 'text-amber-600' },
    { icon: FiCheckCircle, label: 'Đơn đã giao', value: stats.deliveredOrders, accent: 'bg-purple-500', light: 'bg-purple-50', text: 'text-purple-600' },
  ];

  const revenueData = advanced.revenueByDay.map((r) => ({
    date: new Date(r._id).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit' }),
    revenue: r.revenue,
    orders: r.orders,
  }));

  const pieData = advanced.statusBreakdown.map((s) => ({
    name: STATUS[s._id]?.label || s._id,
    value: s.count,
    color: STATUS[s._id]?.color || '#94A3B8',
  }));

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Bảng điều khiển</span>
          <h1 className="font-heading text-[28px] lg:text-[32px] font-extrabold tracking-tight text-[#0B1120] mt-1 leading-tight">
            Chào buổi sáng, Admin 👋
          </h1>
          <p className="text-[13px] text-slate-500 mt-1 capitalize">{today}</p>
        </div>
        <div className="flex items-center gap-2">
          <select value={days} onChange={(e) => setDays(Number(e.target.value))}
            className="bg-white border border-slate-200 rounded-lg px-3 py-2.5 text-[13px] font-semibold outline-none focus:border-[#0B1120] cursor-pointer">
            <option value={7}>7 ngày qua</option>
            <option value={14}>14 ngày qua</option>
            <option value={30}>30 ngày qua</option>
            <option value={90}>90 ngày qua</option>
          </select>
          <Link to="/admin/don-hang" className="bg-[#0B1120] hover:bg-primary text-white text-[13px] font-semibold px-4 py-2.5 rounded-lg flex items-center gap-2 transition">
            <FiShoppingBag /> Xem đơn hàng <FiArrowRight />
          </Link>
        </div>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {STATS.map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="relative bg-white border border-slate-200 rounded-2xl p-5 overflow-hidden hover:border-[#0B1120] transition">
              <div className={`absolute top-0 left-0 right-0 h-1 ${s.accent}`} />
              <div className="flex items-start justify-between">
                <div className={`w-11 h-11 rounded-xl ${s.light} ${s.text} flex items-center justify-center`}>
                  <Icon className="text-[18px]" />
                </div>
                <FiTrendingUp className="text-emerald-500" />
              </div>
              <div className={`font-heading font-extrabold mt-4 tracking-tight text-[#0B1120] ${s.short ? 'text-[20px]' : 'text-[28px]'}`}>
                {s.value}
              </div>
              <div className="text-[12.5px] text-slate-500 mt-1">{s.label}</div>
            </div>
          );
        })}
      </div>

      {/* Chart row 1: revenue line + pie */}
      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-6">
          <div className="flex items-center justify-between mb-5">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center"><FiBarChart2 /></div>
              <div>
                <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Doanh thu {days} ngày</h2>
                <p className="text-[11.5px] text-slate-500">Xu hướng theo ngày</p>
              </div>
            </div>
          </div>

          {revenueData.length === 0 ? (
            <div className="h-[280px] flex items-center justify-center text-slate-400 text-sm">Chưa có dữ liệu</div>
          ) : (
            <ResponsiveContainer width="100%" height={280}>
              <AreaChart data={revenueData} margin={{ left: -10, right: 10, top: 10 }}>
                <defs>
                  <linearGradient id="grad-rev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="0%" stopColor="#2563EB" stopOpacity={0.35} />
                    <stop offset="100%" stopColor="#2563EB" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" vertical={false} />
                <XAxis dataKey="date" stroke="#94A3B8" fontSize={11} tickLine={false} />
                <YAxis stroke="#94A3B8" fontSize={11} tickLine={false} tickFormatter={(v) => fmtShort(v)} />
                <Tooltip
                  contentStyle={{ background: '#0B1120', border: 'none', borderRadius: 8, color: '#fff' }}
                  formatter={(value) => [fmt(value), 'Doanh thu']}
                />
                <Area type="monotone" dataKey="revenue" stroke="#2563EB" strokeWidth={2.5} fill="url(#grad-rev)" />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl p-6">
          <div className="flex items-center gap-3 mb-5">
            <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center"><FiActivity /></div>
            <div>
              <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Trạng thái đơn</h2>
              <p className="text-[11.5px] text-slate-500">Phân bố hiện tại</p>
            </div>
          </div>

          {pieData.length === 0 ? (
            <div className="h-[200px] flex items-center justify-center text-slate-400 text-sm">Chưa có dữ liệu</div>
          ) : (
            <>
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={pieData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={80} paddingAngle={2}>
                    {pieData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="space-y-1.5 mt-3">
                {pieData.map((p) => (
                  <div key={p.name} className="flex items-center justify-between text-[12px]">
                    <div className="flex items-center gap-2">
                      <span className="w-2.5 h-2.5 rounded-full" style={{ background: p.color }} />
                      <span className="text-slate-600">{p.name}</span>
                    </div>
                    <span className="font-bold text-[#0B1120]">{p.value}</span>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Chart row 2: top products bar + recent orders */}
      <div className="grid lg:grid-cols-3 gap-5">
        <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center"><FiAward /></div>
              <div>
                <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Top sản phẩm bán chạy</h2>
                <p className="text-[11.5px] text-slate-500">Theo số lượng bán</p>
              </div>
            </div>
            <Link to="/admin/san-pham" className="text-[12.5px] font-semibold text-primary hover:underline">Tất cả →</Link>
          </div>

          {advanced.topProducts.length === 0 ? (
            <div className="py-16 text-center text-slate-400 text-sm">Chưa có dữ liệu</div>
          ) : (
            <div className="divide-y divide-slate-100">
              {advanced.topProducts.map((p, i) => {
                const max = advanced.topProducts[0]?.totalSold || 1;
                const pct = (p.totalSold / max) * 100;
                return (
                  <div key={p._id} className="flex items-center gap-4 p-4">
                    <div className="text-[20px] font-mono font-bold text-slate-300 w-8">{i + 1}</div>
                    <div className="w-12 h-12 rounded-lg bg-slate-100 overflow-hidden flex-shrink-0">
                      {p.image && <img src={p.image} alt={p.name} className="w-full h-full object-cover" />}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-[13px] font-semibold text-[#0B1120] line-clamp-1">{p.name}</p>
                      <div className="mt-1.5 h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-amber-400 to-orange-500 rounded-full" style={{ width: `${pct}%` }} />
                      </div>
                    </div>
                    <div className="text-right flex-shrink-0">
                      <div className="text-[14px] font-bold text-[#0B1120]">{p.totalSold}</div>
                      <div className="text-[11px] text-slate-500">{fmtShort(p.revenue)}</div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center"><FiActivity /></div>
              <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Đơn mới</h2>
            </div>
            <Link to="/admin/don-hang" className="text-[12.5px] font-semibold text-primary hover:underline">Tất cả →</Link>
          </div>
          <div className="divide-y divide-slate-100 max-h-[420px] overflow-y-auto">
            {recentOrders.length === 0 ? (
              <div className="py-12 text-center text-slate-400 text-sm">Chưa có đơn nào</div>
            ) : recentOrders.map((o) => {
              const st = STATUS[o.status] || { label: o.status, cls: 'bg-slate-50' };
              return (
                <Link to={`/admin/don-hang/${o._id}`} key={o._id} className="flex items-center gap-3 p-4 hover:bg-slate-50 transition">
                  <div className="w-9 h-9 rounded-full bg-slate-100 text-slate-700 text-[12px] font-bold flex items-center justify-center flex-shrink-0">
                    {(o.user?.name || 'A').charAt(0).toUpperCase()}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-mono font-bold text-[12px] text-[#0B1120]">#{o._id.slice(-6).toUpperCase()}</span>
                      <span className="text-[12.5px] font-bold text-[#0B1120]">{fmtShort(o.totalAmount)}</span>
                    </div>
                    <div className="flex items-center justify-between mt-0.5 gap-2">
                      <span className="text-[11.5px] text-slate-500 truncate">{o.user?.name || '---'}</span>
                      <span className={`text-[9.5px] font-bold border px-1.5 py-0.5 rounded ${st.cls}`}>
                        {st.label}
                      </span>
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
