import { useState, useEffect } from 'react';
import {
  FiPlus, FiEdit2, FiTrash2, FiX, FiTruck, FiSearch, FiMail, FiPhone, FiMapPin, FiGlobe, FiHash, FiUser,
} from 'react-icons/fi';
import { toast } from 'react-toastify';
import { supplierService } from '../../services/supplierService';
import { brandService } from '../../services/brandService';

const initialForm = {
  name: '', contactPerson: '', email: '', phone: '', address: '',
  website: '', taxCode: '', logo: '', brands: [], note: '', isActive: true,
};

export default function AdminSuppliers() {
  const [suppliers, setSuppliers] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);
  const [search, setSearch] = useState('');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [supRes, brandRes] = await Promise.all([supplierService.getAll(), brandService.getAll()]);
      setSuppliers(supRes.data.data || supRes.data || []);
      setBrands(brandRes.data.data || brandRes.data || []);
    } catch { toast.error('Không thể tải dữ liệu'); }
    finally { setLoading(false); }
  };

  const openAdd = () => { setEditingId(null); setForm(initialForm); setShowModal(true); };

  const openEdit = (s) => {
    setEditingId(s._id);
    setForm({
      name: s.name || '', contactPerson: s.contactPerson || '', email: s.email || '',
      phone: s.phone || '', address: s.address || '', website: s.website || '',
      taxCode: s.taxCode || '', logo: s.logo || '',
      brands: (s.brands || []).map((b) => b._id || b), note: s.note || '',
      isActive: s.isActive !== false,
    });
    setShowModal(true);
  };

  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const toggleBrand = (id) => {
    const exists = form.brands.includes(id);
    setField('brands', exists ? form.brands.filter((b) => b !== id) : [...form.brands, id]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name) { toast.error('Vui lòng nhập tên NCC'); return; }
    setSubmitting(true);
    try {
      if (editingId) { await supplierService.update(editingId, form); toast.success('Đã cập nhật'); }
      else { await supplierService.create(form); toast.success('Đã thêm NCC'); }
      setShowModal(false); fetchData();
    } catch (err) { toast.error(err.response?.data?.message || 'Lỗi'); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Xóa NCC này?')) return;
    try { await supplierService.delete(id); toast.success('Đã xóa'); fetchData(); }
    catch { toast.error('Không thể xóa'); }
  };

  const filtered = suppliers.filter((s) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return s.name?.toLowerCase().includes(q) || s.contactPerson?.toLowerCase().includes(q) || s.email?.toLowerCase().includes(q);
  });

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Đối tác cung ứng</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1">Nhà cung cấp</h1>
          <p className="text-[13px] text-slate-500 mt-1">{suppliers.length} đối tác</p>
        </div>
        <button onClick={openAdd} className="bg-[#0B1120] hover:bg-primary text-white px-5 py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition">
          <FiPlus /> Thêm NCC
        </button>
      </div>

      {/* Search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex items-center gap-3">
        <div className="flex-1 flex items-center gap-2.5 px-3">
          <FiSearch className="text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm theo tên, người liên hệ, email..."
            className="flex-1 bg-transparent outline-none text-[13.5px] placeholder:text-slate-400" />
        </div>
        <span className="text-[12px] text-slate-500 px-3">{filtered.length} kết quả</span>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl py-20 text-center">
          <FiTruck className="text-3xl text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Chưa có nhà cung cấp nào</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((s) => (
            <div key={s._id} className="group bg-white border border-slate-200 rounded-xl p-5 hover:border-[#0B1120] transition">
              <div className="flex items-start gap-3 mb-4">
                <div className="w-12 h-12 rounded-xl bg-slate-100 overflow-hidden flex items-center justify-center flex-shrink-0">
                  {s.logo ? <img src={s.logo} alt={s.name} className="w-full h-full object-contain p-1.5" /> : <FiTruck className="text-slate-400 text-xl" />}
                </div>
                <div className="flex-1 min-w-0">
                  <h3 className="font-heading text-[15px] font-bold text-[#0B1120] line-clamp-1">{s.name}</h3>
                  {s.contactPerson && <p className="text-[12px] text-slate-500 mt-0.5 flex items-center gap-1.5"><FiUser className="text-[10px]" /> {s.contactPerson}</p>}
                </div>
                {!s.isActive && <span className="text-[10px] bg-red-50 text-red-700 border border-red-200 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">Tắt</span>}
              </div>

              <div className="space-y-1.5 text-[12px] text-slate-600">
                {s.email && <div className="flex items-center gap-2"><FiMail className="text-[11px] text-slate-400" /> {s.email}</div>}
                {s.phone && <div className="flex items-center gap-2"><FiPhone className="text-[11px] text-slate-400" /> {s.phone}</div>}
                {s.address && <div className="flex items-start gap-2"><FiMapPin className="text-[11px] text-slate-400 mt-0.5" /> <span className="line-clamp-1">{s.address}</span></div>}
                {s.taxCode && <div className="flex items-center gap-2"><FiHash className="text-[11px] text-slate-400" /> MST: {s.taxCode}</div>}
                {s.website && <a href={s.website} target="_blank" rel="noreferrer" className="flex items-center gap-2 text-primary hover:underline"><FiGlobe className="text-[11px]" /> {s.website}</a>}
              </div>

              {s.brands?.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-3 pt-3 border-t border-slate-100">
                  {s.brands.map((b) => (
                    <span key={b._id || b} className="text-[10px] uppercase tracking-wider font-bold text-primary bg-primary-light px-2 py-0.5 rounded">
                      {b.name || b}
                    </span>
                  ))}
                </div>
              )}

              <div className="flex gap-1.5 mt-4 pt-3 border-t border-slate-100 opacity-60 group-hover:opacity-100 transition">
                <button onClick={() => openEdit(s)} className="flex-1 border border-slate-200 hover:border-primary hover:bg-primary-light hover:text-primary text-slate-600 text-[12px] font-semibold py-2 rounded-md inline-flex items-center justify-center gap-1.5 transition">
                  <FiEdit2 className="text-[12px]" /> Sửa
                </button>
                <button onClick={() => handleDelete(s._id)} className="border border-slate-200 hover:border-red-500 hover:bg-red-50 hover:text-red-500 text-slate-600 px-3 rounded-md transition">
                  <FiTrash2 className="text-[13px]" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-[#0B1120]/60 backdrop-blur-sm flex items-center justify-center z-[1000] p-4 gz-fadein" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl max-w-[640px] w-full overflow-hidden gz-reveal" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-7 py-5 border-b border-slate-200">
              <div>
                <span className="text-[10.5px] uppercase tracking-wider font-bold text-primary">{editingId ? 'Chỉnh sửa' : 'Tạo mới'}</span>
                <h2 className="font-heading font-bold text-[20px] text-[#0B1120]">{editingId ? 'Sửa NCC' : 'Thêm nhà cung cấp'}</h2>
              </div>
              <button onClick={() => setShowModal(false)} className="w-9 h-9 rounded-lg hover:bg-slate-100 text-slate-500 flex items-center justify-center transition"><FiX /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="px-7 py-5 max-h-[65vh] overflow-y-auto space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Tên NCC *</label>
                    <input value={form.name} onChange={(e) => setField('name', e.target.value)} placeholder="VD: Công ty TNHH ABC"
                      className="ipt" />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Người liên hệ</label>
                    <input value={form.contactPerson} onChange={(e) => setField('contactPerson', e.target.value)} placeholder="Anh A" className="ipt" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Email</label>
                    <input type="email" value={form.email} onChange={(e) => setField('email', e.target.value)} placeholder="contact@ncc.com" className="ipt" />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Số điện thoại</label>
                    <input value={form.phone} onChange={(e) => setField('phone', e.target.value)} placeholder="0901234567" className="ipt" />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Địa chỉ</label>
                  <input value={form.address} onChange={(e) => setField('address', e.target.value)} placeholder="Số nhà, đường, thành phố..." className="ipt" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Website</label>
                    <input value={form.website} onChange={(e) => setField('website', e.target.value)} placeholder="https://..." className="ipt" />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Mã số thuế</label>
                    <input value={form.taxCode} onChange={(e) => setField('taxCode', e.target.value)} placeholder="0123456789" className="ipt font-mono" />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">URL Logo</label>
                  <input value={form.logo} onChange={(e) => setField('logo', e.target.value)} placeholder="https://..." className="ipt" />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Cung cấp các thương hiệu</label>
                  <div className="flex flex-wrap gap-2 p-3 bg-slate-50 rounded-lg">
                    {brands.map((b) => {
                      const active = form.brands.includes(b._id);
                      return (
                        <button key={b._id} type="button" onClick={() => toggleBrand(b._id)}
                          className={`text-[12px] font-semibold px-3 py-1.5 rounded-full border transition ${active ? 'bg-[#0B1120] text-white border-[#0B1120]' : 'bg-white text-slate-600 border-slate-200 hover:border-[#0B1120]'}`}>
                          {b.name}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Ghi chú</label>
                  <textarea value={form.note} onChange={(e) => setField('note', e.target.value)} rows={3} placeholder="Ghi chú nội bộ..." className="ipt resize-none" />
                </div>

                <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg cursor-pointer">
                  <input type="checkbox" checked={form.isActive} onChange={(e) => setField('isActive', e.target.checked)} className="w-4 h-4 accent-primary" />
                  <span className="text-[13px] font-semibold text-[#0B1120]">Đang hợp tác</span>
                </label>
              </div>
              <div className="flex justify-end gap-2 px-7 py-4 border-t border-slate-200 bg-slate-50">
                <button type="button" onClick={() => setShowModal(false)} className="border border-slate-200 bg-white px-5 py-2.5 rounded-lg text-[13px] font-semibold text-slate-600 hover:border-slate-300 transition">Hủy</button>
                <button type="submit" disabled={submitting} className="bg-[#0B1120] hover:bg-primary text-white px-6 py-2.5 rounded-lg text-[13px] font-semibold transition disabled:opacity-60">
                  {submitting ? 'Đang lưu...' : editingId ? 'Cập nhật' : 'Thêm mới'}
                </button>
              </div>
            </form>
            <style>{`
              .ipt { width: 100%; background: #F8FAFC; border: 1px solid #E2E8F0; border-radius: 8px; padding: 10px 14px; font-size: 13.5px; outline: none; transition: all .15s; }
              .ipt:focus { background: #fff; border-color: #0B1120; }
            `}</style>
          </div>
        </div>
      )}
    </div>
  );
}
