import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiPlus, FiEdit2, FiTrash2, FiSearch, FiFileText, FiEye, FiEyeOff, FiCalendar, FiUser } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { newsService } from '../../services/newsService';

export default function AdminNews() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await newsService.adminGetAll();
      const data = res.data.data || res.data || [];
      setArticles(data.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
    } catch { toast.error('Không thể tải tin tức'); }
    finally { setLoading(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Xóa bài viết này?')) return;
    try { await newsService.delete(id); toast.success('Đã xóa'); fetchData(); }
    catch { toast.error('Không thể xóa'); }
  };

  const togglePublish = async (article) => {
    try {
      await newsService.update(article._id, { isPublished: !article.isPublished });
      toast.success(article.isPublished ? 'Đã ẩn bài viết' : 'Đã đăng bài viết');
      fetchData();
    } catch { toast.error('Không thể cập nhật'); }
  };

  const filtered = articles.filter((a) => {
    if (filter === 'published' && !a.isPublished) return false;
    if (filter === 'draft' && a.isPublished) return false;
    if (search && !a.title?.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  });

  const counts = {
    all: articles.length,
    published: articles.filter((a) => a.isPublished).length,
    draft: articles.filter((a) => !a.isPublished).length,
  };

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Nội dung</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1 leading-tight">
            Quản lý tin tức
          </h1>
          <p className="text-[13px] text-slate-500 mt-1">{articles.length} bài viết</p>
        </div>
        <Link to="/admin/tin-tuc/them" className="bg-[#0B1120] hover:bg-primary text-white px-5 py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition">
          <FiPlus /> Viết bài mới
        </Link>
      </div>

      {/* Filter tabs + search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1">
          {[
            { k: 'all', label: 'Tất cả' },
            { k: 'published', label: 'Đã đăng' },
            { k: 'draft', label: 'Bản nháp' },
          ].map((t) => (
            <button
              key={t.k} onClick={() => setFilter(t.k)}
              className={`px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition flex items-center gap-2 ${
                filter === t.k ? 'bg-[#0B1120] text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {t.label}
              <span className={`text-[10.5px] font-bold px-1.5 py-0.5 rounded-md ${filter === t.k ? 'bg-white/15' : 'bg-slate-100 text-slate-500'}`}>
                {counts[t.k]}
              </span>
            </button>
          ))}
        </div>
        <div className="flex-1 min-w-[200px] flex items-center gap-2.5 px-3 bg-slate-50 rounded-lg h-10">
          <FiSearch className="text-slate-400" />
          <input
            value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm theo tiêu đề..."
            className="flex-1 bg-transparent outline-none text-[13px] placeholder:text-slate-400"
          />
        </div>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl py-20 text-center">
          <FiFileText className="text-3xl text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Chưa có bài viết nào</p>
          <Link to="/admin/tin-tuc/them" className="inline-flex items-center gap-1.5 mt-4 bg-[#0B1120] text-white px-4 py-2 rounded-lg text-[12.5px] font-semibold hover:bg-primary transition">
            <FiPlus /> Viết bài đầu tiên
          </Link>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((a) => (
            <div key={a._id} className="bg-white border border-slate-200 rounded-xl overflow-hidden hover:border-[#0B1120] transition group">
              <div className="flex flex-col sm:flex-row gap-4 p-4">
                {/* Thumbnail */}
                <div className="w-full sm:w-[180px] aspect-[16/10] sm:aspect-auto sm:h-[110px] rounded-lg bg-slate-100 overflow-hidden flex-shrink-0">
                  {a.image ? (
                    <img src={a.image} alt={a.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-slate-300">
                      <FiFileText className="text-2xl" />
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0 flex flex-col">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      {a.isPublished ? (
                        <span className="text-[10px] font-bold tracking-wider uppercase bg-emerald-50 text-emerald-700 border border-emerald-200 px-2 py-0.5 rounded-full">Đã đăng</span>
                      ) : (
                        <span className="text-[10px] font-bold tracking-wider uppercase bg-amber-50 text-amber-700 border border-amber-200 px-2 py-0.5 rounded-full">Bản nháp</span>
                      )}
                      {a.tags?.slice(0, 3).map((t) => (
                        <span key={t} className="text-[10px] uppercase tracking-wider font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">{t}</span>
                      ))}
                    </div>
                  </div>

                  <Link to={`/admin/tin-tuc/sua/${a._id}`} className="font-heading font-bold text-[16px] text-[#0B1120] hover:text-primary line-clamp-1 leading-tight transition">
                    {a.title}
                  </Link>
                  <p className="text-[12.5px] text-slate-500 mt-1 line-clamp-2 leading-relaxed">{a.summary}</p>

                  <div className="flex items-center gap-4 mt-auto pt-3 text-[11.5px] text-slate-500 font-medium">
                    <span className="flex items-center gap-1.5"><FiUser className="text-[11px]" /> {a.author || 'Admin'}</span>
                    <span className="flex items-center gap-1.5"><FiCalendar className="text-[11px]" /> {new Date(a.createdAt).toLocaleDateString('vi-VN')}</span>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex sm:flex-col gap-1.5 sm:justify-center opacity-60 group-hover:opacity-100 transition">
                  <button
                    onClick={() => togglePublish(a)}
                    title={a.isPublished ? 'Ẩn' : 'Đăng'}
                    className={`w-9 h-9 rounded-lg border flex items-center justify-center transition ${
                      a.isPublished
                        ? 'border-amber-200 text-amber-600 hover:bg-amber-50'
                        : 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                    }`}
                  >
                    {a.isPublished ? <FiEyeOff className="text-[14px]" /> : <FiEye className="text-[14px]" />}
                  </button>
                  <Link to={`/admin/tin-tuc/sua/${a._id}`} className="w-9 h-9 rounded-lg border border-slate-200 hover:border-primary hover:bg-primary-light hover:text-primary text-slate-600 flex items-center justify-center transition">
                    <FiEdit2 className="text-[13px]" />
                  </Link>
                  <button onClick={() => handleDelete(a._id)} className="w-9 h-9 rounded-lg border border-slate-200 hover:border-red-500 hover:bg-red-50 hover:text-red-500 text-slate-600 flex items-center justify-center transition">
                    <FiTrash2 className="text-[13px]" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
