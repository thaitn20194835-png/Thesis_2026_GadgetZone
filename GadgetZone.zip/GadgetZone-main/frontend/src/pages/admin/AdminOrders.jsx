import { useState, useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { FiShoppingBag, FiSearch, FiFilter, FiCreditCard, FiDollarSign } from 'react-icons/fi';
import { orderService } from '../../services/orderService';

const STATUS = {
  pending:   { label: 'Chờ xử lý', cls: 'bg-amber-50 text-amber-700 border-amber-200', dot: 'bg-amber-500' },
  confirmed: { label: 'Đã xác nhận', cls: 'bg-blue-50 text-blue-700 border-blue-200', dot: 'bg-blue-500' },
  shipping:  { label: 'Đang giao', cls: 'bg-indigo-50 text-indigo-700 border-indigo-200', dot: 'bg-indigo-500' },
  delivered: { label: 'Đã giao', cls: 'bg-emerald-50 text-emerald-700 border-emerald-200', dot: 'bg-emerald-500' },
  cancelled: { label: 'Đã hủy', cls: 'bg-red-50 text-red-700 border-red-200', dot: 'bg-red-500' },
};

const PAYMENT = { cod: 'COD', vnpay: 'VNPay', momo: 'MoMo' };

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await orderService.getAllOrders();
      const sorted = (res.data.data || res.data || []).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
      setOrders(sorted);
    } catch { toast.error('Không thể tải đơn hàng'); }
    finally { setLoading(false); }
  };

  const handleStatusChange = async (id, newStatus) => {
    try {
      await orderService.updateStatus(id, newStatus);
      toast.success('Đã cập nhật trạng thái');
      setOrders((prev) => prev.map((o) => (o._id === id ? { ...o, status: newStatus } : o)));
    } catch { toast.error('Không thể cập nhật'); }
  };

  const fmt = (v) => (v || 0).toLocaleString('vi-VN') + '₫';

  const counts = useMemo(() => {
    const c = { all: orders.length, pending: 0, confirmed: 0, shipping: 0, delivered: 0, cancelled: 0 };
    orders.forEach((o) => { c[o.status] = (c[o.status] || 0) + 1; });
    return c;
  }, [orders]);

  const filtered = orders.filter((o) => {
    if (filter !== 'all' && o.status !== filter) return false;
    if (search) {
      const q = search.toLowerCase();
      const code = o._id?.toLowerCase() || '';
      const name = (o.user?.name || o.shippingAddress?.name || '').toLowerCase();
      if (!code.includes(q) && !name.includes(q)) return false;
    }
    return true;
  });

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      <div>
        <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Đơn hàng</span>
        <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1">Quản lý đơn hàng</h1>
        <p className="text-[13px] text-slate-500 mt-1">{orders.length} đơn hàng tổng</p>
      </div>

      {/* Status filter tabs */}
      <div className="bg-white border border-slate-200 rounded-xl p-2 flex items-center gap-1 overflow-x-auto no-scrollbar">
        {[
          { k: 'all', label: 'Tất cả' },
          { k: 'pending', label: STATUS.pending.label },
          { k: 'confirmed', label: STATUS.confirmed.label },
          { k: 'shipping', label: STATUS.shipping.label },
          { k: 'delivered', label: STATUS.delivered.label },
          { k: 'cancelled', label: STATUS.cancelled.label },
        ].map((t) => (
          <button
            key={t.k}
            onClick={() => setFilter(t.k)}
            className={`px-4 py-2 rounded-lg text-[12.5px] font-semibold whitespace-nowrap transition flex items-center gap-2 ${
              filter === t.k ? 'bg-[#0B1120] text-white' : 'text-slate-600 hover:bg-slate-100'
            }`}
          >
            {t.label}
            <span className={`text-[10.5px] font-bold px-1.5 py-0.5 rounded-md ${filter === t.k ? 'bg-white/15' : 'bg-slate-100 text-slate-500'}`}>
              {counts[t.k] || 0}
            </span>
          </button>
        ))}
      </div>

      {/* Search */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex items-center gap-3">
        <div className="flex-1 flex items-center gap-2.5 px-3">
          <FiSearch className="text-slate-400" />
          <input
            value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm theo mã đơn hoặc tên khách..."
            className="flex-1 bg-transparent outline-none text-[13.5px] placeholder:text-slate-400"
          />
        </div>
        <span className="text-[12px] text-slate-500 px-3 flex items-center gap-1.5">
          <FiFilter className="text-[12px]" /> {filtered.length} kết quả
        </span>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Mã đơn</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Khách hàng</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Tổng tiền</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Thanh toán</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Trạng thái</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Ngày đặt</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-5 py-16 text-center">
                    <FiShoppingBag className="text-3xl text-slate-300 mx-auto mb-3" />
                    <p className="text-slate-500 text-sm">Không có đơn hàng nào</p>
                  </td>
                </tr>
              ) : filtered.map((o) => {
                const st = STATUS[o.status] || { label: o.status, cls: 'bg-slate-50 text-slate-600 border-slate-200', dot: 'bg-slate-400' };
                return (
                  <tr key={o._id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition">
                    <td className="px-5 py-3.5">
                      <Link to={`/admin/don-hang/${o._id}`} className="text-[13px] font-mono font-bold text-[#0B1120] hover:text-primary transition">
                        #{o._id?.slice(-6).toUpperCase()}
                      </Link>
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-slate-100 text-slate-600 text-[12px] font-bold flex items-center justify-center">
                          {(o.user?.name || o.shippingAddress?.name || 'A').charAt(0).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <div className="text-[13px] font-semibold text-[#0B1120] truncate max-w-[200px]">
                            {o.user?.name || o.shippingAddress?.name || '---'}
                          </div>
                          <div className="text-[11px] text-slate-500">{o.shippingAddress?.phone || ''}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="text-[14px] font-bold text-[#0B1120] flex items-center gap-1">
                        <FiDollarSign className="text-emerald-500 text-[12px]" />
                        {fmt(o.totalAmount)}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className="inline-flex items-center gap-1.5 text-[12px] font-semibold text-slate-700 bg-slate-100 px-2.5 py-1 rounded-md">
                        <FiCreditCard className="text-[11px]" />
                        {PAYMENT[o.paymentMethod] || o.paymentMethod || '---'}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <select
                        value={o.status}
                        onChange={(e) => handleStatusChange(o._id, e.target.value)}
                        className={`text-[11px] font-bold border-2 px-2.5 py-1 rounded-full outline-none cursor-pointer appearance-none ${st.cls}`}
                      >
                        {Object.entries(STATUS).map(([k, v]) => (
                          <option key={k} value={k}>{v.label}</option>
                        ))}
                      </select>
                    </td>
                    <td className="px-5 py-3.5 text-[12.5px] text-slate-500">
                      {new Date(o.createdAt).toLocaleDateString('vi-VN', { day: '2-digit', month: '2-digit', year: 'numeric' })}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
