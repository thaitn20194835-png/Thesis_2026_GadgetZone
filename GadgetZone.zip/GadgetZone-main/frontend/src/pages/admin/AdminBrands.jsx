import { useState, useEffect } from 'react';
import { FiPlus, FiEdit2, FiTrash2, FiX, FiTag } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { brandService } from '../../services/brandService';

const initialForm = { name: '', logo: '' };

export default function AdminBrands() {
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try { setLoading(true); const res = await brandService.getAll(); setBrands(res.data.data || res.data || []); }
    catch { toast.error('Không thể tải thương hiệu'); }
    finally { setLoading(false); }
  };

  const openAdd = () => { setEditingId(null); setForm(initialForm); setShowModal(true); };
  const openEdit = (b) => { setEditingId(b._id); setForm({ name: b.name || '', logo: b.logo || '' }); setShowModal(true); };
  const handleChange = (e) => setForm((p) => ({ ...p, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error('Vui lòng nhập tên'); return; }
    try {
      setSubmitting(true);
      if (editingId) { await brandService.update(editingId, form); toast.success('Đã cập nhật'); }
      else { await brandService.create(form); toast.success('Đã thêm thương hiệu'); }
      setShowModal(false); fetchData();
    } catch (err) { toast.error(err.response?.data?.message || 'Lỗi'); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Xóa thương hiệu này?')) return;
    try { await brandService.delete(id); toast.success('Đã xóa'); fetchData(); }
    catch { toast.error('Không thể xóa'); }
  };

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Đối tác</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1">Quản lý thương hiệu</h1>
          <p className="text-[13px] text-slate-500 mt-1">{brands.length} thương hiệu</p>
        </div>
        <button onClick={openAdd} className="bg-[#0B1120] hover:bg-primary text-white px-5 py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition">
          <FiPlus /> Thêm thương hiệu
        </button>
      </div>

      {brands.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl py-20 text-center">
          <FiTag className="text-3xl text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Chưa có thương hiệu nào</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
          {brands.map((b) => (
            <div key={b._id} className="group bg-white border border-slate-200 rounded-xl p-5 hover:border-[#0B1120] transition flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-slate-50 rounded-xl flex items-center justify-center p-3 mb-3">
                {b.logo ? (
                  <img src={b.logo} alt={b.name} className="max-w-full max-h-full object-contain" style={{ filter: 'grayscale(100%)' }}
                    onMouseEnter={(e) => e.target.style.filter = 'grayscale(0%)'}
                    onMouseLeave={(e) => e.target.style.filter = 'grayscale(100%)'} />
                ) : (
                  <FiTag className="text-2xl text-slate-300" />
                )}
              </div>
              <h3 className="font-heading font-bold text-[14px] text-[#0B1120]">{b.name}</h3>
              <p className="text-[10.5px] font-mono text-slate-400 mt-0.5">{b.slug}</p>
              <div className="flex gap-1 mt-3 pt-3 border-t border-slate-100 w-full justify-center opacity-60 group-hover:opacity-100 transition">
                <button onClick={() => openEdit(b)} className="w-8 h-8 rounded-lg border border-slate-200 hover:border-primary hover:bg-primary-light hover:text-primary text-slate-600 flex items-center justify-center transition">
                  <FiEdit2 className="text-[12px]" />
                </button>
                <button onClick={() => handleDelete(b._id)} className="w-8 h-8 rounded-lg border border-slate-200 hover:border-red-500 hover:bg-red-50 hover:text-red-500 text-slate-600 flex items-center justify-center transition">
                  <FiTrash2 className="text-[12px]" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-[#0B1120]/60 backdrop-blur-sm flex items-center justify-center z-[1000] p-4 gz-fadein" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl max-w-[480px] w-full overflow-hidden gz-reveal" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-7 py-5 border-b border-slate-200">
              <div>
                <span className="text-[10.5px] uppercase tracking-wider font-bold text-primary">{editingId ? 'Chỉnh sửa' : 'Tạo mới'}</span>
                <h2 className="font-heading font-bold text-[20px] text-[#0B1120]">
                  {editingId ? 'Sửa thương hiệu' : 'Thêm thương hiệu'}
                </h2>
              </div>
              <button onClick={() => setShowModal(false)} className="w-9 h-9 rounded-lg hover:bg-slate-100 text-slate-500 flex items-center justify-center transition">
                <FiX />
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="px-7 py-5 space-y-4">
                <div>
                  <label className="block text-[12px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Tên thương hiệu <span className="text-red-500 normal-case">*</span></label>
                  <input name="name" value={form.name} onChange={handleChange} placeholder="VD: Apple"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
                <div>
                  <label className="block text-[12px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">URL Logo</label>
                  <input name="logo" value={form.logo} onChange={handleChange} placeholder="https://cdn.simpleicons.org/apple/000000"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                  {form.logo && (
                    <div className="mt-3 p-3 bg-slate-50 rounded-lg flex items-center justify-center">
                      <img src={form.logo} alt="preview" className="h-10 object-contain" />
                    </div>
                  )}
                </div>
              </div>
              <div className="flex justify-end gap-2 px-7 py-4 border-t border-slate-200 bg-slate-50">
                <button type="button" onClick={() => setShowModal(false)} className="border border-slate-200 bg-white px-5 py-2.5 rounded-lg text-[13px] font-semibold text-slate-600 hover:border-slate-300 transition">
                  Hủy
                </button>
                <button type="submit" disabled={submitting} className="bg-[#0B1120] hover:bg-primary text-white px-6 py-2.5 rounded-lg text-[13px] font-semibold transition disabled:opacity-60">
                  {submitting ? 'Đang xử lý...' : editingId ? 'Cập nhật' : 'Thêm mới'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
