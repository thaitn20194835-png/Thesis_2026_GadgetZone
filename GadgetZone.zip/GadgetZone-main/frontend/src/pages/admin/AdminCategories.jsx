import { useState, useEffect } from 'react';
import { FiPlus, FiEdit2, FiTrash2, FiX, FiLayers } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { categoryService } from '../../services/categoryService';

const initialForm = { name: '', description: '' };

export default function AdminCategories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try { setLoading(true); const res = await categoryService.getAll(); setCategories(res.data.data || res.data || []); }
    catch { toast.error('Không thể tải danh mục'); }
    finally { setLoading(false); }
  };

  const openAdd = () => { setEditingId(null); setForm(initialForm); setShowModal(true); };
  const openEdit = (c) => { setEditingId(c._id); setForm({ name: c.name || '', description: c.description || '' }); setShowModal(true); };
  const handleChange = (e) => setForm((p) => ({ ...p, [e.target.name]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) { toast.error('Vui lòng nhập tên'); return; }
    try {
      setSubmitting(true);
      if (editingId) { await categoryService.update(editingId, form); toast.success('Đã cập nhật'); }
      else { await categoryService.create(form); toast.success('Đã thêm danh mục'); }
      setShowModal(false); fetchData();
    } catch (err) { toast.error(err.response?.data?.message || 'Lỗi'); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Xóa danh mục này?')) return;
    try { await categoryService.delete(id); toast.success('Đã xóa'); fetchData(); }
    catch { toast.error('Không thể xóa'); }
  };

  const PALETTES = [
    { bg: 'bg-blue-50', text: 'text-blue-600', dot: 'bg-blue-500' },
    { bg: 'bg-emerald-50', text: 'text-emerald-600', dot: 'bg-emerald-500' },
    { bg: 'bg-purple-50', text: 'text-purple-600', dot: 'bg-purple-500' },
    { bg: 'bg-orange-50', text: 'text-orange-600', dot: 'bg-orange-500' },
    { bg: 'bg-pink-50', text: 'text-pink-600', dot: 'bg-pink-500' },
    { bg: 'bg-amber-50', text: 'text-amber-600', dot: 'bg-amber-500' },
  ];

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Phân loại</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1">Quản lý danh mục</h1>
          <p className="text-[13px] text-slate-500 mt-1">{categories.length} danh mục</p>
        </div>
        <button onClick={openAdd} className="bg-[#0B1120] hover:bg-primary text-white px-5 py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition">
          <FiPlus /> Thêm danh mục
        </button>
      </div>

      {/* Cards grid */}
      {categories.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl py-20 text-center">
          <FiLayers className="text-3xl text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Chưa có danh mục nào</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {categories.map((cat, i) => {
            const c = PALETTES[i % PALETTES.length];
            return (
              <div key={cat._id} className="group bg-white border border-slate-200 rounded-xl p-5 hover:border-[#0B1120] transition relative overflow-hidden">
                <div className={`absolute top-0 right-0 w-24 h-24 ${c.bg} rounded-full -translate-y-12 translate-x-12 opacity-50`} />
                <div className="relative">
                  <div className={`w-11 h-11 rounded-xl ${c.dot} text-white flex items-center justify-center`}>
                    <FiLayers className="text-[18px]" />
                  </div>
                  <h3 className="font-heading font-bold text-[15px] text-[#0B1120] mt-4 leading-tight">{cat.name}</h3>
                  <p className="text-[11.5px] text-slate-500 mt-1 line-clamp-2 min-h-[32px]">{cat.description || 'Không có mô tả'}</p>
                  <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between">
                    <span className="text-[10.5px] font-mono text-slate-400">{cat.slug}</span>
                    <div className="flex gap-1">
                      <button onClick={() => openEdit(cat)} className="w-7 h-7 rounded-md hover:bg-primary-light hover:text-primary text-slate-500 flex items-center justify-center transition">
                        <FiEdit2 className="text-[12px]" />
                      </button>
                      <button onClick={() => handleDelete(cat._id)} className="w-7 h-7 rounded-md hover:bg-red-50 hover:text-red-500 text-slate-500 flex items-center justify-center transition">
                        <FiTrash2 className="text-[12px]" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-[#0B1120]/60 backdrop-blur-sm flex items-center justify-center z-[1000] p-4 gz-fadein" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl max-w-[480px] w-full overflow-hidden gz-reveal" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-7 py-5 border-b border-slate-200">
              <div>
                <span className="text-[10.5px] uppercase tracking-wider font-bold text-primary">{editingId ? 'Chỉnh sửa' : 'Tạo mới'}</span>
                <h2 className="font-heading font-bold text-[20px] text-[#0B1120]">
                  {editingId ? 'Sửa danh mục' : 'Thêm danh mục'}
                </h2>
              </div>
              <button onClick={() => setShowModal(false)} className="w-9 h-9 rounded-lg hover:bg-slate-100 text-slate-500 flex items-center justify-center transition">
                <FiX />
              </button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="px-7 py-5 space-y-4">
                <div>
                  <label className="block text-[12px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Tên danh mục <span className="text-red-500 normal-case">*</span></label>
                  <input name="name" value={form.name} onChange={handleChange} placeholder="VD: Điện thoại"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
                <div>
                  <label className="block text-[12px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Mô tả</label>
                  <textarea name="description" value={form.description} onChange={handleChange} rows={3} placeholder="Mô tả ngắn về danh mục..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition resize-none" />
                </div>
              </div>
              <div className="flex justify-end gap-2 px-7 py-4 border-t border-slate-200 bg-slate-50">
                <button type="button" onClick={() => setShowModal(false)} className="border border-slate-200 bg-white px-5 py-2.5 rounded-lg text-[13px] font-semibold text-slate-600 hover:border-slate-300 transition">
                  Hủy
                </button>
                <button type="submit" disabled={submitting} className="bg-[#0B1120] hover:bg-primary text-white px-6 py-2.5 rounded-lg text-[13px] font-semibold transition disabled:opacity-60">
                  {submitting ? 'Đang xử lý...' : editingId ? 'Cập nhật' : 'Thêm mới'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
