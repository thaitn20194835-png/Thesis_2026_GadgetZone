import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiTrash2, FiSearch, FiMessageSquare, FiCheck, FiEyeOff, FiUser, FiFileText } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { newsCommentService } from '../../services/newsCommentService';

export default function AdminNewsComments() {
  const [comments, setComments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await newsCommentService.adminGetAll();
      setComments(res.data.data || res.data || []);
    } catch { toast.error('Không thể tải bình luận'); }
    finally { setLoading(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Xóa bình luận này?')) return;
    try { await newsCommentService.delete(id); toast.success('Đã xóa'); fetchData(); }
    catch { toast.error('Không thể xóa'); }
  };

  const handleToggle = async (id) => {
    try { await newsCommentService.toggleApprove(id); toast.success('Đã cập nhật'); fetchData(); }
    catch { toast.error('Không thể cập nhật'); }
  };

  const filtered = comments.filter((c) => {
    if (filter === 'approved' && !c.isApproved) return false;
    if (filter === 'hidden' && c.isApproved) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!c.content?.toLowerCase().includes(q) && !c.user?.name?.toLowerCase().includes(q) && !c.news?.title?.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  const counts = {
    all: comments.length,
    approved: comments.filter((c) => c.isApproved).length,
    hidden: comments.filter((c) => !c.isApproved).length,
  };

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      <div>
        <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Tương tác</span>
        <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1">Bình luận tin tức</h1>
        <p className="text-[13px] text-slate-500 mt-1">{comments.length} bình luận</p>
      </div>

      {/* Filter */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1">
          {[
            { k: 'all', label: 'Tất cả' },
            { k: 'approved', label: 'Đã duyệt' },
            { k: 'hidden', label: 'Đã ẩn' },
          ].map((t) => (
            <button key={t.k} onClick={() => setFilter(t.k)}
              className={`px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition flex items-center gap-2 ${
                filter === t.k ? 'bg-[#0B1120] text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}>
              {t.label}
              <span className={`text-[10.5px] font-bold px-1.5 py-0.5 rounded-md ${filter === t.k ? 'bg-white/15' : 'bg-slate-100 text-slate-500'}`}>
                {counts[t.k]}
              </span>
            </button>
          ))}
        </div>
        <div className="flex-1 min-w-[200px] flex items-center gap-2.5 px-3 bg-slate-50 rounded-lg h-10">
          <FiSearch className="text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm theo nội dung, tác giả, bài viết..."
            className="flex-1 bg-transparent outline-none text-[13px] placeholder:text-slate-400" />
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl py-20 text-center">
          <FiMessageSquare className="text-3xl text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Không có bình luận nào</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((c) => (
            <div key={c._id} className={`bg-white border rounded-xl p-5 hover:border-[#0B1120] transition group ${!c.isApproved ? 'border-amber-200 bg-amber-50/30' : 'border-slate-200'}`}>
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 rounded-full bg-primary text-white text-[14px] font-bold flex items-center justify-center flex-shrink-0">
                  {c.user?.name?.charAt(0)?.toUpperCase() || 'A'}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <div className="text-[13.5px] font-bold text-[#0B1120] flex items-center gap-2">
                        <FiUser className="text-[11px] text-slate-400" /> {c.user?.name || 'Ẩn danh'}
                        {!c.isApproved && (
                          <span className="text-[9.5px] font-bold uppercase tracking-wider bg-amber-100 text-amber-700 px-1.5 py-0.5 rounded">Đã ẩn</span>
                        )}
                      </div>
                      <div className="text-[11px] text-slate-500">{c.user?.email}</div>
                    </div>
                    <span className="text-[11.5px] text-slate-500">
                      {new Date(c.createdAt).toLocaleString('vi-VN')}
                    </span>
                  </div>

                  <p className="text-[13.5px] text-slate-700 leading-relaxed mt-2 bg-slate-50 border border-slate-100 rounded-lg p-3">
                    "{c.content}"
                  </p>

                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
                    <Link to={c.news ? `/tin-tuc/${c.news._id}` : '#'} className="text-[12px] text-slate-500 hover:text-primary inline-flex items-center gap-1.5 transition">
                      <FiFileText className="text-[11px]" /> {c.news?.title || '(Đã xóa)'}
                    </Link>
                    <div className="flex gap-1.5 opacity-60 group-hover:opacity-100 transition">
                      <button onClick={() => handleToggle(c._id)} title={c.isApproved ? 'Ẩn' : 'Duyệt'}
                        className={`w-8 h-8 rounded-lg border flex items-center justify-center transition ${
                          c.isApproved
                            ? 'border-amber-200 text-amber-600 hover:bg-amber-50'
                            : 'border-emerald-200 text-emerald-600 hover:bg-emerald-50'
                        }`}>
                        {c.isApproved ? <FiEyeOff className="text-[13px]" /> : <FiCheck className="text-[13px]" />}
                      </button>
                      <button onClick={() => handleDelete(c._id)} className="w-8 h-8 rounded-lg border border-slate-200 hover:border-red-500 hover:bg-red-50 hover:text-red-500 text-slate-600 flex items-center justify-center transition">
                        <FiTrash2 className="text-[13px]" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
