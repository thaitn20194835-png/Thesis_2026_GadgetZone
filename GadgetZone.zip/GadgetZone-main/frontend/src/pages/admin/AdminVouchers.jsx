import { useState, useEffect } from 'react';
import {
  FiPlus, FiEdit2, FiTrash2, FiX, FiTag, FiPercent, FiDollarSign,
  FiCalendar, FiUsers, FiCopy,
} from 'react-icons/fi';
import { toast } from 'react-toastify';
import { voucherService } from '../../services/voucherService';

const initialForm = {
  code: '', description: '', type: 'percent', value: 10,
  maxDiscount: 0, minOrderValue: 0, usageLimit: 0,
  startDate: new Date().toISOString().slice(0, 10),
  endDate: new Date(Date.now() + 30 * 86400000).toISOString().slice(0, 10),
  isActive: true,
};

export default function AdminVouchers() {
  const [vouchers, setVouchers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(initialForm);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try { setLoading(true); const res = await voucherService.adminGetAll(); setVouchers(res.data.data || res.data || []); }
    catch { toast.error('Không thể tải voucher'); }
    finally { setLoading(false); }
  };

  const openAdd = () => { setEditingId(null); setForm(initialForm); setShowModal(true); };

  const openEdit = (v) => {
    setEditingId(v._id);
    setForm({
      code: v.code, description: v.description || '', type: v.type, value: v.value,
      maxDiscount: v.maxDiscount || 0, minOrderValue: v.minOrderValue || 0,
      usageLimit: v.usageLimit || 0,
      startDate: new Date(v.startDate).toISOString().slice(0, 10),
      endDate: new Date(v.endDate).toISOString().slice(0, 10),
      isActive: v.isActive,
    });
    setShowModal(true);
  };

  const setField = (k, val) => setForm((p) => ({ ...p, [k]: val }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.code || !form.value || !form.endDate) { toast.error('Nhập đủ Mã, Giá trị, Ngày kết thúc'); return; }
    setSubmitting(true);
    try {
      const data = {
        ...form,
        value: Number(form.value),
        maxDiscount: Number(form.maxDiscount) || 0,
        minOrderValue: Number(form.minOrderValue) || 0,
        usageLimit: Number(form.usageLimit) || 0,
      };
      if (editingId) { await voucherService.update(editingId, data); toast.success('Đã cập nhật'); }
      else { await voucherService.create(data); toast.success('Đã thêm voucher'); }
      setShowModal(false); fetchData();
    } catch (err) { toast.error(err.response?.data?.message || 'Lỗi'); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Xóa voucher này?')) return;
    try { await voucherService.delete(id); toast.success('Đã xóa'); fetchData(); }
    catch { toast.error('Không thể xóa'); }
  };

  const copyCode = (code) => { navigator.clipboard?.writeText(code); toast.success(`Đã sao chép ${code}`); };

  const fmt = (v) => (v || 0).toLocaleString('vi-VN');
  const isExpired = (v) => new Date(v.endDate) < new Date();

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Khuyến mãi</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1">Quản lý voucher</h1>
          <p className="text-[13px] text-slate-500 mt-1">{vouchers.length} mã giảm giá</p>
        </div>
        <button onClick={openAdd} className="bg-[#0B1120] hover:bg-primary text-white px-5 py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition">
          <FiPlus /> Tạo voucher
        </button>
      </div>

      {vouchers.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl py-20 text-center">
          <FiTag className="text-3xl text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Chưa có voucher nào</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {vouchers.map((v) => {
            const expired = isExpired(v);
            const usedUp = v.usageLimit > 0 && v.usedCount >= v.usageLimit;
            const inactive = !v.isActive || expired || usedUp;
            return (
              <div key={v._id} className={`group relative bg-white border-2 rounded-xl overflow-hidden transition ${inactive ? 'border-slate-200 opacity-70' : 'border-accent hover:border-[#0B1120]'}`}>
                {/* Coupon header */}
                <div className={`${inactive ? 'bg-slate-100 text-slate-500' : 'bg-accent text-white'} p-4 relative`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      {v.type === 'percent' ? <FiPercent className="text-[18px]" /> : <FiDollarSign className="text-[18px]" />}
                      <span className="text-[10.5px] uppercase tracking-wider font-bold">{v.type === 'percent' ? 'Giảm %' : 'Giảm cố định'}</span>
                    </div>
                    {inactive && (
                      <span className="text-[9px] bg-slate-700 text-white px-2 py-0.5 rounded uppercase tracking-wider font-bold">
                        {expired ? 'Hết hạn' : usedUp ? 'Hết lượt' : 'Tắt'}
                      </span>
                    )}
                  </div>
                  <div className="font-heading text-[28px] font-black tracking-tight mt-2">
                    {v.value}{v.type === 'percent' ? '%' : 'đ'}
                  </div>
                </div>

                {/* Body */}
                <div className="p-4">
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <code className="text-[14px] font-mono font-bold text-[#0B1120] bg-slate-100 border border-dashed border-slate-300 px-2.5 py-1 rounded">
                      {v.code}
                    </code>
                    <button onClick={() => copyCode(v.code)} className="text-slate-400 hover:text-primary transition" title="Sao chép">
                      <FiCopy className="text-[14px]" />
                    </button>
                  </div>

                  {v.description && <p className="text-[12.5px] text-slate-600 line-clamp-2 mb-3">{v.description}</p>}

                  <div className="space-y-1.5 text-[11.5px] text-slate-600">
                    {v.minOrderValue > 0 && (
                      <div className="flex items-center gap-1.5">
                        <FiDollarSign className="text-[10px]" /> Đơn tối thiểu: <span className="font-bold text-[#0B1120]">{fmt(v.minOrderValue)}đ</span>
                      </div>
                    )}
                    {v.maxDiscount > 0 && (
                      <div className="flex items-center gap-1.5">
                        <FiPercent className="text-[10px]" /> Tối đa: <span className="font-bold text-[#0B1120]">{fmt(v.maxDiscount)}đ</span>
                      </div>
                    )}
                    <div className="flex items-center gap-1.5">
                      <FiCalendar className="text-[10px]" /> Hết hạn: <span className={`font-bold ${expired ? 'text-red-500' : 'text-[#0B1120]'}`}>{new Date(v.endDate).toLocaleDateString('vi-VN')}</span>
                    </div>
                    <div className="flex items-center gap-1.5">
                      <FiUsers className="text-[10px]" /> Đã dùng: <span className="font-bold text-[#0B1120]">{v.usedCount}{v.usageLimit > 0 ? `/${v.usageLimit}` : ''}</span>
                    </div>
                  </div>

                  <div className="flex gap-1.5 mt-4 pt-3 border-t border-slate-100">
                    <button onClick={() => openEdit(v)} className="flex-1 border border-slate-200 hover:border-primary hover:bg-primary-light hover:text-primary text-slate-600 text-[12px] font-semibold py-2 rounded-md inline-flex items-center justify-center gap-1.5 transition">
                      <FiEdit2 className="text-[12px]" /> Sửa
                    </button>
                    <button onClick={() => handleDelete(v._id)} className="border border-slate-200 hover:border-red-500 hover:bg-red-50 hover:text-red-500 text-slate-600 px-3 rounded-md transition">
                      <FiTrash2 className="text-[13px]" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {showModal && (
        <div className="fixed inset-0 bg-[#0B1120]/60 backdrop-blur-sm flex items-center justify-center z-[1000] p-4 gz-fadein" onClick={() => setShowModal(false)}>
          <div className="bg-white rounded-2xl max-w-[560px] w-full overflow-hidden gz-reveal" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between px-7 py-5 border-b border-slate-200">
              <div>
                <span className="text-[10.5px] uppercase tracking-wider font-bold text-primary">{editingId ? 'Chỉnh sửa' : 'Tạo mới'}</span>
                <h2 className="font-heading font-bold text-[20px] text-[#0B1120]">
                  {editingId ? 'Sửa voucher' : 'Tạo voucher mới'}
                </h2>
              </div>
              <button onClick={() => setShowModal(false)} className="w-9 h-9 rounded-lg hover:bg-slate-100 text-slate-500 flex items-center justify-center transition"><FiX /></button>
            </div>
            <form onSubmit={handleSubmit}>
              <div className="px-7 py-5 max-h-[65vh] overflow-y-auto space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Mã code *</label>
                    <input value={form.code} onChange={(e) => setField('code', e.target.value.toUpperCase())} placeholder="WELCOME20"
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[14px] font-mono outline-none focus:border-[#0B1120]" />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Loại</label>
                    <select value={form.type} onChange={(e) => setField('type', e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[14px] outline-none focus:border-[#0B1120]">
                      <option value="percent">Giảm theo %</option>
                      <option value="fixed">Giảm số tiền cố định</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Mô tả</label>
                  <input value={form.description} onChange={(e) => setField('description', e.target.value)} placeholder="Giảm 20% cho khách mới"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[14px] outline-none focus:border-[#0B1120]" />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
                      {form.type === 'percent' ? 'Giảm (%) *' : 'Giảm (₫) *'}
                    </label>
                    <input type="number" value={form.value} onChange={(e) => setField('value', e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[14px] font-mono outline-none focus:border-[#0B1120]" />
                  </div>
                  {form.type === 'percent' && (
                    <div>
                      <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Giảm tối đa (₫)</label>
                      <input type="number" value={form.maxDiscount} onChange={(e) => setField('maxDiscount', e.target.value)} placeholder="0 = không giới hạn"
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[14px] font-mono outline-none focus:border-[#0B1120]" />
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Đơn tối thiểu (₫)</label>
                    <input type="number" value={form.minOrderValue} onChange={(e) => setField('minOrderValue', e.target.value)} placeholder="0"
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[14px] font-mono outline-none focus:border-[#0B1120]" />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Giới hạn lượt dùng</label>
                    <input type="number" value={form.usageLimit} onChange={(e) => setField('usageLimit', e.target.value)} placeholder="0 = vô hạn"
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[14px] font-mono outline-none focus:border-[#0B1120]" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Bắt đầu</label>
                    <input type="date" value={form.startDate} onChange={(e) => setField('startDate', e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-[#0B1120]" />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Kết thúc *</label>
                    <input type="date" value={form.endDate} onChange={(e) => setField('endDate', e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-[#0B1120]" />
                  </div>
                </div>

                <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg cursor-pointer">
                  <input type="checkbox" checked={form.isActive} onChange={(e) => setField('isActive', e.target.checked)} className="w-4 h-4 accent-primary" />
                  <span className="text-[13px] font-semibold text-[#0B1120]">Kích hoạt voucher</span>
                </label>
              </div>
              <div className="flex justify-end gap-2 px-7 py-4 border-t border-slate-200 bg-slate-50">
                <button type="button" onClick={() => setShowModal(false)} className="border border-slate-200 bg-white px-5 py-2.5 rounded-lg text-[13px] font-semibold text-slate-600 hover:border-slate-300 transition">Hủy</button>
                <button type="submit" disabled={submitting} className="bg-[#0B1120] hover:bg-primary text-white px-6 py-2.5 rounded-lg text-[13px] font-semibold transition disabled:opacity-60">
                  {submitting ? 'Đang lưu...' : editingId ? 'Cập nhật' : 'Tạo mới'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
