import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  FiArrowLeft, FiSave, FiUser, FiPhone, FiMapPin, FiPackage,
  FiCreditCard, FiTruck, FiClock, FiCheckCircle, FiXCircle, FiPrinter,
  FiTag, FiFileText,
} from 'react-icons/fi';
import { toast } from 'react-toastify';
import { orderService } from '../../services/orderService';

const STATUS_FLOW = [
  { key: 'pending', label: 'Chờ xử lý', color: 'amber', icon: FiClock },
  { key: 'confirmed', label: 'Đã xác nhận', color: 'blue', icon: FiCheckCircle },
  { key: 'shipping', label: 'Đang giao', color: 'indigo', icon: FiTruck },
  { key: 'delivered', label: 'Đã giao', color: 'emerald', icon: FiPackage },
];

const SHIPPING_PROVIDERS = ['GHN - Giao Hàng Nhanh', 'GHTK - Giao Hàng Tiết Kiệm', 'Viettel Post', 'J&T Express', 'Ninja Van', 'Khác'];

export default function AdminOrderDetail() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [tracking, setTracking] = useState({ trackingNumber: '', shippingProvider: '', adminNote: '' });
  const [statusUpdate, setStatusUpdate] = useState({ status: '', note: '' });

  useEffect(() => { fetchData(); }, [id]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await orderService.getOrderById(id);
      const data = res.data.data || res.data;
      setOrder(data);
      setTracking({
        trackingNumber: data.trackingNumber || '',
        shippingProvider: data.shippingProvider || '',
        adminNote: data.adminNote || '',
      });
      setStatusUpdate({ status: data.status, note: '' });
    } catch { toast.error('Không thể tải đơn hàng'); }
    finally { setLoading(false); }
  };

  const fmt = (v) => (v || 0).toLocaleString('vi-VN') + '₫';

  const saveTracking = async () => {
    setSaving(true);
    try {
      await orderService.updateOrder(id, tracking);
      toast.success('Đã lưu thông tin vận chuyển');
      fetchData();
    } catch { toast.error('Lỗi khi lưu'); }
    finally { setSaving(false); }
  };

  const updateStatus = async () => {
    if (statusUpdate.status === order.status) {
      toast.info('Trạng thái không thay đổi');
      return;
    }
    setSaving(true);
    try {
      await orderService.updateOrder(id, { status: statusUpdate.status, note: statusUpdate.note });
      toast.success('Đã cập nhật trạng thái');
      setStatusUpdate({ status: statusUpdate.status, note: '' });
      fetchData();
    } catch { toast.error('Lỗi khi cập nhật'); }
    finally { setSaving(false); }
  };

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;
  if (!order) return <div className="py-20 text-center text-slate-400">Không tìm thấy đơn hàng</div>;

  const currentStep = STATUS_FLOW.findIndex((s) => s.key === order.status);
  const isCancelled = order.status === 'cancelled';

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <Link to="/admin/don-hang" className="inline-flex items-center gap-2 text-[12.5px] font-semibold text-slate-500 hover:text-[#0B1120] mb-2 transition group">
            <FiArrowLeft className="group-hover:-translate-x-1 transition-transform" /> Quay lại
          </Link>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-primary">Đơn hàng</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1 leading-tight">
            #{order._id?.slice(-8).toUpperCase()}
          </h1>
          <p className="text-[13px] text-slate-500 mt-1">
            Tạo lúc {new Date(order.createdAt).toLocaleString('vi-VN')}
          </p>
        </div>
        <button onClick={() => window.print()} className="border border-slate-200 bg-white px-5 py-2.5 rounded-lg text-[13px] font-semibold text-slate-700 hover:border-[#0B1120] inline-flex items-center gap-2 transition">
          <FiPrinter /> In hóa đơn
        </button>
      </div>

      {/* Status flow */}
      {!isCancelled ? (
        <div className="bg-white border border-slate-200 rounded-2xl p-6">
          <div className="flex items-center justify-between gap-2 overflow-x-auto">
            {STATUS_FLOW.map((s, i) => {
              const done = i <= currentStep;
              const active = i === currentStep;
              const Icon = s.icon;
              return (
                <div key={s.key} className="flex items-center gap-2 flex-1 min-w-0">
                  <div className="flex flex-col items-center gap-2">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center transition ${
                      done ? `bg-${s.color}-500 text-white` : 'bg-slate-100 text-slate-400'
                    } ${active ? 'ring-4 ring-primary/20 scale-110' : ''}`}>
                      <Icon className="text-[18px]" />
                    </div>
                    <div className={`text-[11.5px] font-bold uppercase tracking-wider whitespace-nowrap ${done ? 'text-[#0B1120]' : 'text-slate-400'}`}>
                      {s.label}
                    </div>
                  </div>
                  {i < STATUS_FLOW.length - 1 && (
                    <div className={`flex-1 h-0.5 ${i < currentStep ? `bg-${s.color}-500` : 'bg-slate-200'}`} />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      ) : (
        <div className="bg-red-50 border border-red-200 rounded-2xl p-6 flex items-center gap-3">
          <FiXCircle className="text-red-500 text-2xl" />
          <div>
            <div className="font-bold text-red-700">Đơn hàng đã hủy</div>
            <div className="text-[12.5px] text-red-600">Đơn hàng này đã bị hủy và không thể tiếp tục xử lý.</div>
          </div>
        </div>
      )}

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Left: items + history */}
        <div className="lg:col-span-2 space-y-5">
          {/* Items */}
          <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
            <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center"><FiPackage /></div>
              <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Sản phẩm ({order.items.length})</h2>
            </div>
            <div className="divide-y divide-slate-100">
              {order.items.map((item, i) => (
                <div key={i} className="flex items-center gap-4 p-5">
                  <div className="w-16 h-16 rounded-lg bg-slate-100 overflow-hidden flex-shrink-0">
                    {item.image ? <img src={item.image} alt={item.name} className="w-full h-full object-cover" /> : null}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[13.5px] font-semibold text-[#0B1120] line-clamp-2">{item.name}</p>
                    <p className="text-[12.5px] text-slate-500 mt-1">SL: {item.quantity} × {fmt(item.price)}</p>
                  </div>
                  <div className="text-[14px] font-bold text-[#0B1120] flex-shrink-0">
                    {fmt(item.price * item.quantity)}
                  </div>
                </div>
              ))}
            </div>

            {/* Totals */}
            <div className="px-6 py-4 bg-slate-50 border-t border-slate-100 space-y-2">
              <div className="flex justify-between text-[13px]">
                <span className="text-slate-600">Tạm tính</span>
                <span className="text-[#0B1120] font-semibold">{fmt(order.subtotal || order.totalAmount)}</span>
              </div>
              {order.discount > 0 && (
                <div className="flex justify-between text-[13px]">
                  <span className="text-slate-600 flex items-center gap-1.5">
                    <FiTag className="text-accent text-[12px]" /> Giảm giá ({order.voucherCode})
                  </span>
                  <span className="text-accent font-semibold">-{fmt(order.discount)}</span>
                </div>
              )}
              <div className="flex justify-between text-[13px]">
                <span className="text-slate-600">Phí vận chuyển</span>
                <span className="text-emerald-600 font-bold">Miễn phí</span>
              </div>
              <div className="border-t border-slate-200 pt-2 mt-2 flex justify-between items-baseline">
                <span className="text-[14px] text-slate-700 font-semibold">Tổng cộng</span>
                <span className="font-heading text-[24px] font-extrabold text-[#0B1120]">{fmt(order.totalAmount)}</span>
              </div>
            </div>
          </div>

          {/* Status History */}
          {order.statusHistory?.length > 0 && (
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-5">
                <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center"><FiClock /></div>
                <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Lịch sử trạng thái</h2>
              </div>
              <div className="border-l-2 border-slate-200 pl-6 space-y-5 ml-3">
                {order.statusHistory.slice().reverse().map((h, i) => (
                  <div key={i} className="relative">
                    <div className="absolute -left-[34px] top-1 w-5 h-5 rounded-full bg-primary border-4 border-white" />
                    <div className="text-[12.5px] font-mono text-primary font-bold">
                      {new Date(h.at).toLocaleString('vi-VN')}
                    </div>
                    <div className="text-[14px] font-semibold text-[#0B1120] mt-0.5">
                      Trạng thái: <span className="text-primary">{h.status}</span>
                    </div>
                    {h.note && <div className="text-[13px] text-slate-600 mt-1">{h.note}</div>}
                    {h.by?.name && <div className="text-[11.5px] text-slate-500 mt-1">bởi {h.by.name}</div>}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Right: customer info + actions */}
        <div className="space-y-5">
          {/* Customer */}
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-lg bg-pink-50 text-pink-600 flex items-center justify-center"><FiUser /></div>
              <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Khách hàng</h2>
            </div>
            <div className="space-y-2.5">
              <div className="flex items-start gap-2 text-[13px]"><FiUser className="text-slate-400 mt-0.5 flex-shrink-0" /><span className="font-semibold text-[#0B1120]">{order.shippingAddress.name}</span></div>
              <div className="flex items-start gap-2 text-[13px]"><FiPhone className="text-slate-400 mt-0.5 flex-shrink-0" /><span className="text-slate-700">{order.shippingAddress.phone}</span></div>
              <div className="flex items-start gap-2 text-[13px]"><FiMapPin className="text-slate-400 mt-0.5 flex-shrink-0" /><span className="text-slate-700">{order.shippingAddress.address}</span></div>
              {order.note && (
                <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 mt-3">
                  <div className="text-[10.5px] uppercase tracking-wider font-bold text-amber-700 mb-1">Ghi chú khách</div>
                  <div className="text-[12.5px] text-amber-900">{order.note}</div>
                </div>
              )}
            </div>
          </div>

          {/* Payment */}
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-lg bg-purple-50 text-purple-600 flex items-center justify-center"><FiCreditCard /></div>
              <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Thanh toán</h2>
            </div>
            <div className="flex items-center justify-between text-[13px]">
              <span className="text-slate-600">Phương thức</span>
              <span className="font-bold text-[#0B1120] uppercase">{order.paymentMethod}</span>
            </div>
            <div className="flex items-center justify-between text-[13px] mt-2">
              <span className="text-slate-600">Trạng thái</span>
              <span className={`text-[11px] font-bold border px-2.5 py-1 rounded-full ${
                order.paymentStatus === 'paid' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-amber-50 text-amber-700 border-amber-200'
              }`}>
                {order.paymentStatus === 'paid' ? 'ĐÃ THANH TOÁN' : 'CHƯA THANH TOÁN'}
              </span>
            </div>
          </div>

          {/* Update status */}
          {!isCancelled && (
            <div className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-9 h-9 rounded-lg bg-blue-50 text-blue-600 flex items-center justify-center"><FiClock /></div>
                <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Cập nhật trạng thái</h2>
              </div>
              <select value={statusUpdate.status} onChange={(e) => setStatusUpdate({ ...statusUpdate, status: e.target.value })}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-[#0B1120]">
                <option value="pending">Chờ xử lý</option>
                <option value="confirmed">Đã xác nhận</option>
                <option value="shipping">Đang giao</option>
                <option value="delivered">Đã giao</option>
                <option value="cancelled">Hủy đơn</option>
              </select>
              <textarea value={statusUpdate.note} onChange={(e) => setStatusUpdate({ ...statusUpdate, note: e.target.value })}
                placeholder="Ghi chú khi đổi trạng thái (tùy chọn)..." rows={2}
                className="w-full mt-2 bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-[13px] outline-none focus:border-[#0B1120] resize-none" />
              <button onClick={updateStatus} disabled={saving}
                className="w-full mt-3 bg-[#0B1120] hover:bg-primary text-white py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center justify-center gap-2 transition disabled:opacity-60">
                <FiSave /> {saving ? 'Đang lưu...' : 'Cập nhật'}
              </button>
            </div>
          )}

          {/* Tracking */}
          <div className="bg-white border border-slate-200 rounded-xl p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 flex items-center justify-center"><FiTruck /></div>
              <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">Vận chuyển</h2>
            </div>
            <div className="space-y-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Đơn vị vận chuyển</label>
                <select value={tracking.shippingProvider} onChange={(e) => setTracking({ ...tracking, shippingProvider: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[13px] outline-none focus:border-[#0B1120]">
                  <option value="">-- Chọn --</option>
                  {SHIPPING_PROVIDERS.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Mã vận đơn</label>
                <input value={tracking.trackingNumber} onChange={(e) => setTracking({ ...tracking, trackingNumber: e.target.value })}
                  placeholder="VD: GHN12345678"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2.5 text-[13px] font-mono outline-none focus:border-[#0B1120]" />
              </div>
              <div>
                <label className="block text-[11px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">Ghi chú nội bộ</label>
                <textarea value={tracking.adminNote} onChange={(e) => setTracking({ ...tracking, adminNote: e.target.value })}
                  rows={2} placeholder="Chỉ admin thấy..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-3 py-2 text-[13px] outline-none focus:border-[#0B1120] resize-none" />
              </div>
              <button onClick={saveTracking} disabled={saving}
                className="w-full bg-[#0B1120] hover:bg-primary text-white py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center justify-center gap-2 transition disabled:opacity-60">
                <FiSave /> {saving ? 'Đang lưu...' : 'Lưu thông tin'}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
