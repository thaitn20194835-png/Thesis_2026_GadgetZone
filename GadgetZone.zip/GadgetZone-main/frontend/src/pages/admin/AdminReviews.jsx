import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiStar, FiTrash2, FiSearch, FiMessageSquare, FiUser } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { reviewService } from '../../services/reviewService';

export default function AdminReviews() {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filterRating, setFilterRating] = useState(0);

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await reviewService.adminGetAll();
      setReviews(res.data.data || res.data || []);
    } catch { toast.error('Không thể tải đánh giá'); }
    finally { setLoading(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Xóa đánh giá này? Sau khi xóa sẽ tính lại rating sản phẩm.')) return;
    try { await reviewService.delete(id); toast.success('Đã xóa'); fetchData(); }
    catch { toast.error('Không thể xóa'); }
  };

  const filtered = reviews.filter((r) => {
    if (filterRating > 0 && r.rating !== filterRating) return false;
    if (search) {
      const q = search.toLowerCase();
      if (!r.comment?.toLowerCase().includes(q) && !r.user?.name?.toLowerCase().includes(q) && !r.product?.name?.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  const stats = {
    total: reviews.length,
    avg: reviews.length ? (reviews.reduce((s, r) => s + r.rating, 0) / reviews.length).toFixed(1) : 0,
    fiveStar: reviews.filter((r) => r.rating === 5).length,
    lowRating: reviews.filter((r) => r.rating <= 2).length,
  };

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      <div>
        <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Phản hồi khách hàng</span>
        <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1">Quản lý đánh giá</h1>
        <p className="text-[13px] text-slate-500 mt-1">{reviews.length} đánh giá tổng</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { icon: FiMessageSquare, label: 'Tổng đánh giá', value: stats.total, light: 'bg-blue-50', text: 'text-blue-600' },
          { icon: FiStar, label: 'Trung bình', value: `${stats.avg}★`, light: 'bg-amber-50', text: 'text-amber-600' },
          { icon: FiStar, label: '5 sao', value: stats.fiveStar, light: 'bg-emerald-50', text: 'text-emerald-600' },
          { icon: FiStar, label: '≤ 2 sao', value: stats.lowRating, light: 'bg-red-50', text: 'text-red-600' },
        ].map((s, i) => {
          const Icon = s.icon;
          return (
            <div key={i} className="bg-white border border-slate-200 rounded-xl p-4 flex items-center gap-3">
              <div className={`w-10 h-10 rounded-lg ${s.light} ${s.text} flex items-center justify-center`}>
                <Icon className="text-[16px]" />
              </div>
              <div>
                <div className="text-[20px] font-extrabold text-[#0B1120]">{s.value}</div>
                <div className="text-[11px] text-slate-500">{s.label}</div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Filter */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex flex-wrap items-center gap-3">
        <div className="flex items-center gap-1">
          {[
            { v: 0, label: 'Tất cả' },
            { v: 5, label: '5 ★' },
            { v: 4, label: '4 ★' },
            { v: 3, label: '3 ★' },
            { v: 2, label: '2 ★' },
            { v: 1, label: '1 ★' },
          ].map((t) => (
            <button
              key={t.v} onClick={() => setFilterRating(t.v)}
              className={`px-3.5 py-2 rounded-lg text-[12.5px] font-semibold transition ${
                filterRating === t.v ? 'bg-[#0B1120] text-white' : 'text-slate-600 hover:bg-slate-100'
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
        <div className="flex-1 min-w-[200px] flex items-center gap-2.5 px-3 bg-slate-50 rounded-lg h-10">
          <FiSearch className="text-slate-400" />
          <input value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm theo nội dung, khách, sản phẩm..."
            className="flex-1 bg-transparent outline-none text-[13px] placeholder:text-slate-400" />
        </div>
      </div>

      {/* List */}
      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl py-20 text-center">
          <FiMessageSquare className="text-3xl text-slate-300 mx-auto mb-3" />
          <p className="text-slate-500 text-sm">Không có đánh giá nào</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((r) => (
            <div key={r._id} className="bg-white border border-slate-200 rounded-xl p-5 hover:border-[#0B1120] transition group">
              <div className="flex gap-4">
                <Link to={r.product ? `/san-pham/${r.product._id}` : '#'} className="w-16 h-16 rounded-lg bg-slate-100 overflow-hidden flex-shrink-0">
                  {r.product?.images?.[0] ? (
                    <img src={r.product.images[0]} alt={r.product.name} className="w-full h-full object-cover" />
                  ) : <div className="w-full h-full flex items-center justify-center text-slate-300">?</div>}
                </Link>
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-3 flex-wrap">
                    <div>
                      <div className="text-[10.5px] uppercase tracking-wider font-bold text-slate-400">Sản phẩm</div>
                      <Link to={r.product ? `/san-pham/${r.product._id}` : '#'} className="text-[13.5px] font-bold text-[#0B1120] hover:text-primary line-clamp-1 transition">
                        {r.product?.name || '(Đã xóa)'}
                      </Link>
                    </div>
                    <div className="flex items-center gap-1">
                      {[1,2,3,4,5].map((i) => (
                        <FiStar key={i} className={i <= r.rating ? 'fill-amber-400 text-amber-400 text-[14px]' : 'fill-slate-200 text-slate-200 text-[14px]'} />
                      ))}
                      <span className="ml-1 text-[12px] font-bold text-[#0B1120]">{r.rating}.0</span>
                    </div>
                  </div>

                  <p className="text-[13.5px] text-slate-700 leading-relaxed mt-2 bg-slate-50 border border-slate-100 rounded-lg p-3">
                    "{r.comment}"
                  </p>

                  <div className="flex items-center justify-between mt-3 pt-3 border-t border-slate-100">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-primary text-white text-[11px] font-bold flex items-center justify-center">
                        {r.user?.name?.charAt(0)?.toUpperCase() || 'A'}
                      </div>
                      <div>
                        <div className="text-[12.5px] font-semibold text-[#0B1120] flex items-center gap-1.5">
                          <FiUser className="text-[10px] text-slate-400" /> {r.user?.name || 'Ẩn danh'}
                        </div>
                        <div className="text-[10.5px] text-slate-500">{r.user?.email}</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-[11.5px] text-slate-500">
                        {new Date(r.createdAt).toLocaleDateString('vi-VN')}
                      </span>
                      <button onClick={() => handleDelete(r._id)} className="opacity-60 group-hover:opacity-100 w-8 h-8 rounded-lg border border-slate-200 hover:border-red-500 hover:bg-red-50 hover:text-red-500 text-slate-600 flex items-center justify-center transition">
                        <FiTrash2 className="text-[13px]" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
