import { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import {
  FiArrowLeft, FiSave, FiUpload, FiX, FiImage, FiStar, FiPlus, FiTrash2,
  FiInfo, FiCheckCircle, FiAlertCircle,
} from 'react-icons/fi';
import { toast } from 'react-toastify';
import { productService } from '../../services/productService';
import { categoryService } from '../../services/categoryService';
import { brandService } from '../../services/brandService';
import { supplierService } from '../../services/supplierService';
import { uploadService } from '../../services/uploadService';

const initialForm = {
  name: '', price: '', salePrice: '', category: '', brand: '', supplier: '', stock: '',
  description: '', images: [], isFeatured: false, specs: [{ key: '', value: '' }],
};

export default function AdminProductForm() {
  const { id } = useParams();
  const navigate = useNavigate();
  const isEdit = Boolean(id);

  const [form, setForm] = useState(initialForm);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  useEffect(() => {
    (async () => {
      try {
        const [catRes, brandRes, supRes] = await Promise.all([
          categoryService.getAll(), brandService.getAll(), supplierService.getAll().catch(() => ({ data: { data: [] } })),
        ]);
        setCategories(catRes.data.data || catRes.data || []);
        setBrands(brandRes.data.data || brandRes.data || []);
        setSuppliers(supRes.data.data || supRes.data || []);

        if (isEdit) {
          const prodRes = await productService.getById(id);
          const p = prodRes.data.data || prodRes.data;
          const specsArr = p.specs ? Object.entries(p.specs).map(([k, v]) => ({ key: k, value: v })) : [{ key: '', value: '' }];
          setForm({
            name: p.name || '', price: p.price || '', salePrice: p.salePrice || '',
            category: p.category?._id || p.category || '',
            brand: p.brand?._id || p.brand || '',
            supplier: p.supplier?._id || p.supplier || '',
            stock: p.stock || '', description: p.description || '',
            images: p.images || [],
            isFeatured: p.isFeatured || false,
            specs: specsArr.length ? specsArr : [{ key: '', value: '' }],
          });
        }
      } catch { toast.error('Không thể tải dữ liệu'); }
      finally { setLoading(false); }
    })();
  }, [id, isEdit]);

  const setField = (k, v) => setForm((p) => ({ ...p, [k]: v }));

  const handleUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    setUploading(true);
    try {
      const uploaded = [];
      for (const file of files) {
        if (!file.type.startsWith('image/')) {
          toast.warning(`${file.name} không phải ảnh`);
          continue;
        }
        if (file.size > 5 * 1024 * 1024) {
          toast.warning(`${file.name} quá 5MB`);
          continue;
        }
        const res = await uploadService.uploadImage(file);
        const url = res.data.data?.url || res.data.url;
        if (url) uploaded.push(url);
      }
      if (uploaded.length) {
        setField('images', [...form.images, ...uploaded]);
        toast.success(`Đã upload ${uploaded.length} ảnh lên Cloudinary`);
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Upload thất bại');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const removeImage = (idx) => {
    setField('images', form.images.filter((_, i) => i !== idx));
  };

  const moveImage = (from, to) => {
    if (to < 0 || to >= form.images.length) return;
    const arr = [...form.images];
    [arr[from], arr[to]] = [arr[to], arr[from]];
    setField('images', arr);
  };

  const updateSpec = (i, key, value) => {
    const next = [...form.specs];
    next[i] = { ...next[i], [key]: value };
    setField('specs', next);
  };
  const addSpec = () => setField('specs', [...form.specs, { key: '', value: '' }]);
  const removeSpec = (i) => setField('specs', form.specs.filter((_, idx) => idx !== i));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.price || !form.category) {
      toast.error('Vui lòng nhập đủ Tên, Giá, Danh mục');
      return;
    }
    setSubmitting(true);
    try {
      const specsObj = {};
      form.specs.forEach((s) => { if (s.key.trim() && s.value.trim()) specsObj[s.key.trim()] = s.value.trim(); });

      const data = {
        name: form.name,
        price: Number(form.price),
        salePrice: form.salePrice ? Number(form.salePrice) : 0,
        category: form.category,
        brand: form.brand || undefined,
        supplier: form.supplier || null,
        stock: Number(form.stock) || 0,
        description: form.description,
        images: form.images,
        isFeatured: form.isFeatured,
        specs: Object.keys(specsObj).length ? specsObj : undefined,
      };

      if (isEdit) {
        await productService.update(id, data);
        toast.success('Cập nhật sản phẩm thành công');
      } else {
        await productService.create(data);
        toast.success('Đã thêm sản phẩm mới');
      }
      navigate('/admin/san-pham');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Có lỗi xảy ra');
    } finally { setSubmitting(false); }
  };

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  const fmt = (v) => (Number(v) || 0).toLocaleString('vi-VN') + '₫';
  const hasDiscount = form.salePrice > 0 && form.salePrice < form.price;
  const discountPct = hasDiscount ? Math.round((1 - form.salePrice / form.price) * 100) : 0;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <Link to="/admin/san-pham" className="inline-flex items-center gap-2 text-[12.5px] font-semibold text-slate-500 hover:text-[#0B1120] mb-2 transition group">
            <FiArrowLeft className="group-hover:-translate-x-1 transition-transform" />
            Quay lại danh sách
          </Link>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-primary">{isEdit ? 'Chỉnh sửa' : 'Tạo mới'}</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1 leading-tight">
            {isEdit ? 'Sửa sản phẩm' : 'Thêm sản phẩm mới'}
          </h1>
        </div>
        <div className="flex gap-2">
          <Link to="/admin/san-pham" className="border border-slate-200 bg-white px-5 py-2.5 rounded-lg text-[13px] font-semibold text-slate-600 hover:border-slate-300 transition">
            Hủy
          </Link>
          <button onClick={handleSubmit} disabled={submitting} className="bg-[#0B1120] hover:bg-primary text-white px-6 py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition disabled:opacity-60">
            <FiSave /> {submitting ? 'Đang lưu...' : isEdit ? 'Cập nhật' : 'Thêm sản phẩm'}
          </button>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="grid lg:grid-cols-3 gap-5">
        {/* Left main */}
        <div className="lg:col-span-2 space-y-5">
          {/* Basic info */}
          <Card title="Thông tin cơ bản" icon={FiInfo} accent="bg-blue-50 text-blue-600">
            <Field label="Tên sản phẩm" required>
              <input value={form.name} onChange={(e) => setField('name', e.target.value)}
                placeholder="VD: iPhone 15 Pro Max 256GB - Titan Tự Nhiên"
                className="ipt" />
            </Field>

            <Field label="Mô tả">
              <textarea value={form.description} onChange={(e) => setField('description', e.target.value)} rows={5}
                placeholder="Mô tả chi tiết, đặc điểm nổi bật, công nghệ..."
                className="ipt resize-none leading-relaxed" />
            </Field>
          </Card>

          {/* Images upload */}
          <Card title="Hình ảnh sản phẩm" icon={FiImage} accent="bg-purple-50 text-purple-600">
            <input
              ref={fileInputRef} type="file" multiple accept="image/*"
              onChange={handleUpload} className="hidden"
            />

            {/* Drag drop zone */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={uploading}
              className="w-full border-2 border-dashed border-slate-300 hover:border-primary rounded-xl p-8 transition group bg-slate-50 hover:bg-primary-light disabled:opacity-60"
            >
              <div className="flex flex-col items-center gap-3">
                <div className="w-14 h-14 rounded-full bg-white border border-slate-200 group-hover:border-primary flex items-center justify-center text-slate-400 group-hover:text-primary transition">
                  {uploading ? (
                    <div className="w-5 h-5 border-2 border-primary border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <FiUpload className="text-xl" />
                  )}
                </div>
                <div>
                  <p className="text-[14px] font-semibold text-[#0B1120]">
                    {uploading ? 'Đang upload lên Cloudinary...' : 'Kéo thả hoặc bấm để chọn ảnh'}
                  </p>
                  <p className="text-[12px] text-slate-500 mt-1">PNG, JPG, WEBP — tối đa 5MB mỗi ảnh, có thể chọn nhiều</p>
                </div>
              </div>
            </button>

            {/* Image grid */}
            {form.images.length > 0 && (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4">
                {form.images.map((url, i) => (
                  <div key={i} className="relative group aspect-square rounded-lg overflow-hidden border-2 border-slate-200 bg-slate-50">
                    <img src={url} alt={`img ${i}`} className="w-full h-full object-cover" />
                    {i === 0 && (
                      <span className="absolute top-2 left-2 bg-primary text-white text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider">
                        Ảnh chính
                      </span>
                    )}
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/40 transition flex items-center justify-center gap-1.5 opacity-0 group-hover:opacity-100">
                      {i > 0 && (
                        <button type="button" onClick={() => moveImage(i, i - 1)} className="w-8 h-8 bg-white/90 rounded-md text-[#0B1120] hover:bg-white text-[12px] font-bold transition" title="Lên trước">←</button>
                      )}
                      {i < form.images.length - 1 && (
                        <button type="button" onClick={() => moveImage(i, i + 1)} className="w-8 h-8 bg-white/90 rounded-md text-[#0B1120] hover:bg-white text-[12px] font-bold transition" title="Xuống sau">→</button>
                      )}
                      <button type="button" onClick={() => removeImage(i)} className="w-8 h-8 bg-red-500 text-white rounded-md hover:bg-red-600 transition" title="Xóa">
                        <FiX className="mx-auto text-[14px]" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <p className="text-[11.5px] text-slate-500 mt-3 flex items-start gap-1.5">
              <FiInfo className="text-[12px] mt-0.5 flex-shrink-0" />
              Ảnh đầu tiên sẽ là ảnh chính hiển thị trên card sản phẩm. Bạn có thể kéo thay đổi thứ tự bằng nút mũi tên.
            </p>
          </Card>

          {/* Specs */}
          <Card title="Thông số kỹ thuật" icon={FiCheckCircle} accent="bg-emerald-50 text-emerald-600">
            <div className="space-y-2">
              {form.specs.map((s, i) => (
                <div key={i} className="grid grid-cols-[1fr_2fr_40px] gap-2">
                  <input value={s.key} onChange={(e) => updateSpec(i, 'key', e.target.value)} placeholder="Màn hình" className="ipt" />
                  <input value={s.value} onChange={(e) => updateSpec(i, 'value', e.target.value)} placeholder="6.7 inch OLED, 120Hz" className="ipt" />
                  <button type="button" onClick={() => removeSpec(i)} className="border border-slate-200 hover:border-red-500 hover:bg-red-50 hover:text-red-500 text-slate-500 rounded-lg flex items-center justify-center transition">
                    <FiTrash2 className="text-[13px]" />
                  </button>
                </div>
              ))}
            </div>
            <button type="button" onClick={addSpec} className="mt-3 inline-flex items-center gap-1.5 text-[12.5px] font-semibold text-primary hover:text-primary-hover">
              <FiPlus /> Thêm thông số
            </button>
          </Card>
        </div>

        {/* Right sidebar */}
        <div className="space-y-5">
          {/* Pricing */}
          <Card title="Giá bán" icon={FiAlertCircle} accent="bg-amber-50 text-amber-600">
            <Field label="Giá gốc (₫)" required>
              <input type="number" value={form.price} onChange={(e) => setField('price', e.target.value)} placeholder="34990000" className="ipt font-mono" />
              {form.price > 0 && <p className="text-[11px] text-slate-500 mt-1">{fmt(form.price)}</p>}
            </Field>
            <Field label="Giá khuyến mãi (₫)">
              <input type="number" value={form.salePrice} onChange={(e) => setField('salePrice', e.target.value)} placeholder="0 = không sale" className="ipt font-mono" />
              {form.salePrice > 0 && <p className="text-[11px] text-slate-500 mt-1">{fmt(form.salePrice)}</p>}
            </Field>

            {hasDiscount && (
              <div className="bg-accent-light border border-accent/30 rounded-lg p-3 flex items-center justify-between">
                <div>
                  <span className="text-[10.5px] uppercase tracking-wider font-bold text-accent">Giảm giá</span>
                  <div className="font-heading font-extrabold text-[20px] text-accent">-{discountPct}%</div>
                </div>
                <div className="text-right text-[11.5px]">
                  <p className="text-slate-500">Tiết kiệm</p>
                  <p className="font-bold text-accent">{fmt(form.price - form.salePrice)}</p>
                </div>
              </div>
            )}
          </Card>

          {/* Organization */}
          <Card title="Phân loại" icon={FiInfo} accent="bg-pink-50 text-pink-600">
            <Field label="Danh mục" required>
              <select value={form.category} onChange={(e) => setField('category', e.target.value)} className="ipt">
                <option value="">-- Chọn danh mục --</option>
                {categories.map((c) => <option key={c._id} value={c._id}>{c.name}</option>)}
              </select>
            </Field>
            <Field label="Thương hiệu">
              <select value={form.brand} onChange={(e) => setField('brand', e.target.value)} className="ipt">
                <option value="">-- Chọn thương hiệu --</option>
                {brands.map((b) => <option key={b._id} value={b._id}>{b.name}</option>)}
              </select>
            </Field>
            <Field label="Nhà cung cấp">
              <select value={form.supplier} onChange={(e) => setField('supplier', e.target.value)} className="ipt">
                <option value="">-- Không có --</option>
                {suppliers.map((s) => <option key={s._id} value={s._id}>{s.name}</option>)}
              </select>
            </Field>
            <Field label="Tồn kho">
              <input type="number" value={form.stock} onChange={(e) => setField('stock', e.target.value)} placeholder="0" className="ipt font-mono" />
            </Field>
          </Card>

          {/* Settings */}
          <Card title="Cài đặt" icon={FiStar} accent="bg-blue-50 text-blue-600">
            <label className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg hover:bg-slate-100 transition cursor-pointer">
              <input type="checkbox" checked={form.isFeatured} onChange={(e) => setField('isFeatured', e.target.checked)} className="w-4 h-4 accent-primary" />
              <FiStar className={`${form.isFeatured ? 'text-amber-400 fill-amber-400' : 'text-slate-400'} text-[16px]`} />
              <div className="flex-1">
                <div className="text-[13px] font-semibold text-[#0B1120]">Sản phẩm nổi bật</div>
                <div className="text-[11px] text-slate-500">Hiển thị trên trang chủ</div>
              </div>
            </label>
          </Card>
        </div>
      </form>

      <style>{`
        .ipt {
          width: 100%;
          background: #F8FAFC;
          border: 1px solid #E2E8F0;
          border-radius: 8px;
          padding: 10px 14px;
          font-size: 13.5px;
          outline: none;
          transition: all .15s;
        }
        .ipt:focus { background: #fff; border-color: #0B1120; box-shadow: 0 0 0 3px rgba(11,17,32,0.08); }
      `}</style>
    </div>
  );
}

function Card({ title, icon: Icon, accent, children }) {
  return (
    <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
      <div className="px-6 py-4 border-b border-slate-100 flex items-center gap-3">
        <div className={`w-9 h-9 rounded-lg ${accent} flex items-center justify-center`}>
          <Icon className="text-[16px]" />
        </div>
        <h2 className="font-heading font-bold text-[15px] text-[#0B1120]">{title}</h2>
      </div>
      <div className="p-6 space-y-4">{children}</div>
    </div>
  );
}

function Field({ label, required, children }) {
  return (
    <div>
      <label className="block text-[12px] font-bold text-slate-700 mb-1.5 uppercase tracking-wide">
        {label} {required && <span className="text-red-500 normal-case">*</span>}
      </label>
      {children}
    </div>
  );
}
