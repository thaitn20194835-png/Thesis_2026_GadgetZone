import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiPlus, FiEdit2, FiTrash2, FiSearch, FiPackage, FiStar } from 'react-icons/fi';
import { toast } from 'react-toastify';
import { productService } from '../../services/productService';

export default function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => { fetchData(); }, []);

  const fetchData = async () => {
    try {
      setLoading(true);
      const res = await productService.adminGetAll();
      setProducts(res.data.data || res.data || []);
    } catch { toast.error('Không thể tải sản phẩm'); }
    finally { setLoading(false); }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Xóa sản phẩm này?')) return;
    try { await productService.delete(id); toast.success('Đã xóa'); fetchData(); }
    catch { toast.error('Không thể xóa'); }
  };

  const fmt = (v) => (v || 0).toLocaleString('vi-VN') + '₫';
  const filtered = products.filter((p) => p.name?.toLowerCase().includes(search.toLowerCase()));

  if (loading) return <div className="py-20 text-center text-slate-400 text-sm">Đang tải...</div>;

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <span className="text-[11px] tracking-[0.18em] uppercase font-bold text-slate-500">Catalog</span>
          <h1 className="font-heading text-[28px] font-extrabold tracking-tight text-[#0B1120] mt-1 leading-tight">
            Quản lý sản phẩm
          </h1>
          <p className="text-[13px] text-slate-500 mt-1">{products.length} sản phẩm trong hệ thống</p>
        </div>
        <Link to="/admin/san-pham/them" className="bg-[#0B1120] hover:bg-primary text-white px-5 py-2.5 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition">
          <FiPlus /> Thêm sản phẩm
        </Link>
      </div>

      {/* Search bar */}
      <div className="bg-white border border-slate-200 rounded-xl p-3 flex items-center gap-3">
        <div className="flex-1 flex items-center gap-2.5 px-3">
          <FiSearch className="text-slate-400" />
          <input
            value={search} onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm theo tên sản phẩm..."
            className="flex-1 bg-transparent outline-none text-[13.5px] placeholder:text-slate-400"
          />
        </div>
        <span className="text-[12px] text-slate-500 px-3">{filtered.length} kết quả</span>
      </div>

      {/* Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100">
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Sản phẩm</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Danh mục</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Thương hiệu</th>
                <th className="px-5 py-3 text-left text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Giá</th>
                <th className="px-5 py-3 text-center text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Tồn</th>
                <th className="px-5 py-3 text-center text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Trạng thái</th>
                <th className="px-5 py-3 text-right text-[10.5px] uppercase font-bold text-slate-500 tracking-wider">Thao tác</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-5 py-16 text-center">
                    <FiPackage className="text-3xl text-slate-300 mx-auto mb-3" />
                    <p className="text-slate-500 text-sm">Không tìm thấy sản phẩm nào</p>
                    <Link to="/admin/san-pham/them" className="inline-flex items-center gap-1.5 mt-4 bg-[#0B1120] text-white px-4 py-2 rounded-lg text-[12.5px] font-semibold hover:bg-primary transition">
                      <FiPlus /> Thêm sản phẩm đầu tiên
                    </Link>
                  </td>
                </tr>
              ) : filtered.map((p) => {
                const hasDiscount = p.salePrice > 0 && p.salePrice < p.price;
                return (
                  <tr key={p._id} className="border-b border-slate-100 last:border-0 hover:bg-slate-50/50 transition group">
                    <td className="px-5 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-lg bg-slate-100 overflow-hidden flex-shrink-0 border border-slate-200">
                          {p.images?.[0] ? (
                            <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-300"><FiPackage /></div>
                          )}
                        </div>
                        <div className="min-w-0 max-w-[280px]">
                          <Link to={`/admin/san-pham/sua/${p._id}`} className="text-[13px] font-semibold text-[#0B1120] hover:text-primary truncate flex items-center gap-1.5 transition">
                            {p.name}
                            {p.isFeatured && <FiStar className="text-amber-400 fill-amber-400 text-[12px] flex-shrink-0" />}
                          </Link>
                          <div className="text-[11px] text-slate-500 font-mono">#{p._id?.slice(-6).toUpperCase()}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-5 py-3 text-[12.5px] text-slate-700">{p.category?.name || '—'}</td>
                    <td className="px-5 py-3 text-[12.5px] text-slate-700">{p.brand?.name || '—'}</td>
                    <td className="px-5 py-3">
                      {hasDiscount ? (
                        <div>
                          <div className="text-[13px] font-bold text-accent">{fmt(p.salePrice)}</div>
                          <div className="text-[11px] text-slate-400 line-through">{fmt(p.price)}</div>
                        </div>
                      ) : (
                        <div className="text-[13px] font-bold text-[#0B1120]">{fmt(p.price)}</div>
                      )}
                    </td>
                    <td className="px-5 py-3 text-center">
                      <span className={`text-[13px] font-bold ${p.stock <= 5 ? 'text-red-500' : p.stock <= 20 ? 'text-amber-500' : 'text-[#0B1120]'}`}>
                        {p.stock}
                      </span>
                    </td>
                    <td className="px-5 py-3 text-center">
                      <span className={`text-[10.5px] font-bold border px-2.5 py-1 rounded-full ${
                        p.stock > 0 ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-red-50 text-red-700 border-red-200'
                      }`}>
                        {p.stock > 0 ? 'CÒN HÀNG' : 'HẾT HÀNG'}
                      </span>
                    </td>
                    <td className="px-5 py-3">
                      <div className="flex items-center justify-end gap-1.5 opacity-60 group-hover:opacity-100 transition">
                        <Link to={`/admin/san-pham/sua/${p._id}`} className="w-8 h-8 rounded-lg border border-slate-200 hover:border-primary hover:bg-primary-light hover:text-primary text-slate-600 flex items-center justify-center transition">
                          <FiEdit2 className="text-[13px]" />
                        </Link>
                        <button onClick={() => handleDelete(p._id)} className="w-8 h-8 rounded-lg border border-slate-200 hover:border-red-500 hover:bg-red-50 hover:text-red-500 text-slate-600 flex items-center justify-center transition">
                          <FiTrash2 className="text-[13px]" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
