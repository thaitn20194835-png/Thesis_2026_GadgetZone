import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import {
  FiCalendar, FiUser, FiArrowLeft, FiChevronRight, FiClock,
  FiCopy, FiFacebook, FiTwitter, FiLinkedin, FiMessageSquare, FiSend,
} from 'react-icons/fi';
import { newsService } from '../services/newsService';
import { newsCommentService } from '../services/newsCommentService';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const NewsDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [article, setArticle] = useState(null);
  const [related, setRelated] = useState([]);
  const [comments, setComments] = useState([]);
  const [commentInput, setCommentInput] = useState('');
  const [posting, setPosting] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      setLoading(true);
      try {
        const res = await newsService.getById(id);
        setArticle(res.data.data || res.data);
        const relRes = await newsService.getAll({ limit: 4 });
        const all = relRes.data.data || relRes.data || [];
        setRelated(all.filter((a) => (a._id || a.id) !== id).slice(0, 3));
        const cmRes = await newsCommentService.getByNews(id);
        setComments(cmRes.data.data || cmRes.data || []);
      } catch { setArticle(null); }
      finally { setLoading(false); }
    };
    fetch();
    window.scrollTo(0, 0);
  }, [id]);

  const submitComment = async (e) => {
    e.preventDefault();
    if (!user) { toast.warning('Vui lòng đăng nhập để bình luận'); navigate('/dang-nhap'); return; }
    if (!commentInput.trim()) return;
    setPosting(true);
    try {
      const res = await newsCommentService.create(id, commentInput);
      setComments([res.data.data || res.data, ...comments]);
      setCommentInput('');
      toast.success('Đã đăng bình luận');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Gửi thất bại');
    } finally { setPosting(false); }
  };

  const fmtDate = (d) => new Date(d).toLocaleDateString('vi-VN', { day: '2-digit', month: 'long', year: 'numeric' });

  const readingTime = (content) => {
    if (!content) return '3 phút đọc';
    const words = content.replace(/<[^>]*>/g, '').split(/\s+/).length;
    return `${Math.max(1, Math.ceil(words / 200))} phút đọc`;
  };

  const copyLink = () => {
    navigator.clipboard?.writeText(window.location.href);
    toast.success('Đã sao chép liên kết');
  };

  if (loading) return <div className="min-h-[60vh] flex items-center justify-center text-slate-400 text-sm">Đang tải...</div>;
  if (!article) return (
    <div className="min-h-[60vh] flex flex-col items-center justify-center gap-3">
      <p className="text-slate-500">Không tìm thấy bài viết.</p>
      <Link to="/tin-tuc" className="text-primary font-semibold flex items-center gap-1.5"><FiArrowLeft /> Quay lại</Link>
    </div>
  );

  // Convert markdown-ish content with **bold** and paragraphs
  const renderContent = (text) => {
    if (!text) return null;
    return text.split('\n\n').map((para, i) => {
      if (para.startsWith('**') && para.endsWith('**')) {
        return <h3 key={i} className="font-heading font-bold text-[20px] lg:text-[22px] text-[#0B1120] mt-10 mb-3 tracking-tight">{para.slice(2, -2)}</h3>;
      }
      const formatted = para.replace(/\*\*(.+?)\*\*/g, '<strong class="text-[#0B1120] font-bold">$1</strong>');
      return (
        <p
          key={i}
          className="text-[16px] leading-[1.85] text-slate-700 mb-5"
          dangerouslySetInnerHTML={{ __html: formatted }}
        />
      );
    });
  };

  return (
    <div className="bg-[#FAFAFA]">
      {/* Hero header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-[820px] mx-auto px-4 lg:px-6 py-10 lg:py-14">
          <nav className="flex items-center gap-1.5 text-[12.5px] text-slate-500 flex-wrap mb-6">
            <Link to="/" className="hover:text-[#0B1120]">Trang chủ</Link>
            <FiChevronRight className="text-[10px]" />
            <Link to="/tin-tuc" className="hover:text-[#0B1120]">Tin tức</Link>
            <FiChevronRight className="text-[10px]" />
            <span className="text-[#0B1120] font-medium truncate max-w-[280px]">{article.title}</span>
          </nav>

          {article.tags && article.tags.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-5">
              {article.tags.map((tag, i) => (
                <span key={i} className="text-[10.5px] tracking-wider uppercase font-bold text-primary bg-primary-light px-2.5 py-1 rounded">
                  {tag}
                </span>
              ))}
            </div>
          )}

          <h1 className="font-heading text-[30px] lg:text-[44px] font-black tracking-[-0.02em] text-[#0B1120] leading-[1.1]">
            {article.title}
          </h1>

          <p className="text-[16px] lg:text-[17px] text-slate-600 leading-relaxed mt-5">
            {article.summary}
          </p>

          <div className="flex items-center gap-4 text-[12.5px] text-slate-500 font-medium mt-6">
            <span className="flex items-center gap-1.5"><FiUser /> {article.author || 'Admin'}</span>
            <span className="w-1 h-1 bg-slate-300 rounded-full" />
            <span className="flex items-center gap-1.5"><FiCalendar /> {fmtDate(article.createdAt || article.date)}</span>
            <span className="w-1 h-1 bg-slate-300 rounded-full" />
            <span className="flex items-center gap-1.5"><FiClock /> {readingTime(article.content)}</span>
          </div>
        </div>
      </div>

      {/* Featured image */}
      {article.image && (
        <div className="max-w-[1100px] mx-auto px-4 lg:px-6 -mt-1">
          <div className="aspect-[16/9] bg-white border border-slate-200 rounded-2xl overflow-hidden mt-8">
            <img src={article.image} alt={article.title} className="w-full h-full object-cover" />
          </div>
        </div>
      )}

      {/* Article body */}
      <article className="max-w-[820px] mx-auto px-4 lg:px-6 py-12">
        {renderContent(article.content)}

        {/* Share */}
        <div className="mt-12 pt-8 border-t border-slate-200">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <span className="gz-eyebrow text-slate-500">Chia sẻ bài viết</span>
              <p className="text-[15px] text-[#0B1120] font-bold mt-1">Bạn thấy bài viết hữu ích?</p>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={copyLink} className="w-10 h-10 rounded-lg border border-slate-200 hover:bg-[#0B1120] hover:text-white hover:border-[#0B1120] flex items-center justify-center text-slate-600 transition" title="Sao chép link">
                <FiCopy />
              </button>
              <a target="_blank" rel="noreferrer" href={`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}`} className="w-10 h-10 rounded-lg border border-slate-200 hover:bg-[#1877F2] hover:text-white hover:border-[#1877F2] flex items-center justify-center text-slate-600 transition">
                <FiFacebook />
              </a>
              <a target="_blank" rel="noreferrer" href={`https://twitter.com/intent/tweet?url=${encodeURIComponent(window.location.href)}`} className="w-10 h-10 rounded-lg border border-slate-200 hover:bg-[#0B1120] hover:text-white hover:border-[#0B1120] flex items-center justify-center text-slate-600 transition">
                <FiTwitter />
              </a>
              <a target="_blank" rel="noreferrer" href={`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(window.location.href)}`} className="w-10 h-10 rounded-lg border border-slate-200 hover:bg-[#0A66C2] hover:text-white hover:border-[#0A66C2] flex items-center justify-center text-slate-600 transition">
                <FiLinkedin />
              </a>
            </div>
          </div>
        </div>

        <Link to="/tin-tuc" className="inline-flex items-center gap-2 text-[14px] font-semibold text-[#0B1120] mt-8 group">
          <FiArrowLeft className="group-hover:-translate-x-1 transition-transform" />
          Tất cả bài viết
        </Link>

        {/* Comments */}
        <div className="mt-12 pt-8 border-t border-slate-200">
          <div className="flex items-center gap-3 mb-6">
            <FiMessageSquare className="text-primary text-xl" />
            <h2 className="font-heading text-[22px] font-bold text-[#0B1120]">Bình luận ({comments.length})</h2>
          </div>

          <form onSubmit={submitComment} className="bg-white border border-slate-200 rounded-xl p-4 mb-6">
            <div className="flex gap-3">
              <div className="w-10 h-10 rounded-full bg-primary text-white text-[14px] font-bold flex items-center justify-center flex-shrink-0">
                {user?.name?.charAt(0)?.toUpperCase() || '?'}
              </div>
              <div className="flex-1">
                <textarea
                  value={commentInput} onChange={(e) => setCommentInput(e.target.value)}
                  rows={3} placeholder={user ? 'Chia sẻ ý kiến của bạn...' : 'Đăng nhập để bình luận'}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg p-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white resize-none transition"
                />
                <div className="flex justify-end mt-2">
                  <button type="submit" disabled={posting || !commentInput.trim()}
                    className="bg-[#0B1120] hover:bg-primary text-white px-5 py-2 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition disabled:opacity-60">
                    <FiSend className="text-[12px]" /> {posting ? 'Đang gửi...' : 'Gửi bình luận'}
                  </button>
                </div>
              </div>
            </div>
          </form>

          {comments.length === 0 ? (
            <p className="text-center text-slate-400 text-[13.5px] py-8">Chưa có bình luận nào — hãy là người đầu tiên!</p>
          ) : (
            <div className="space-y-4">
              {comments.map((c) => (
                <div key={c._id} className="flex gap-3">
                  <div className="w-10 h-10 rounded-full bg-slate-200 text-slate-700 text-[14px] font-bold flex items-center justify-center flex-shrink-0">
                    {c.user?.name?.charAt(0)?.toUpperCase() || '?'}
                  </div>
                  <div className="flex-1 bg-slate-50 border border-slate-100 rounded-xl p-4">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <strong className="text-[13.5px] text-[#0B1120]">{c.user?.name || 'Ẩn danh'}</strong>
                      <span className="text-[11.5px] text-slate-500">
                        {new Date(c.createdAt).toLocaleString('vi-VN')}
                      </span>
                    </div>
                    <p className="text-[13.5px] text-slate-700 mt-1.5 leading-relaxed whitespace-pre-line">{c.content}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </article>

      {/* Related */}
      {related.length > 0 && (
        <section className="bg-white border-t border-slate-200">
          <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-12">
            <h3 className="font-heading text-[24px] font-extrabold text-[#0B1120] tracking-tight mb-6">Bài viết liên quan</h3>
            <div className="grid sm:grid-cols-3 gap-5">
              {related.map((r) => (
                <Link key={r._id || r.id} to={`/tin-tuc/${r._id || r.id}`} className="group bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-[#0B1120] transition">
                  <div className="aspect-[16/10] overflow-hidden bg-slate-100">
                    {r.image && <img src={r.image} alt={r.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />}
                  </div>
                  <div className="p-5">
                    <h4 className="font-heading text-[15px] font-bold text-[#0B1120] line-clamp-2 leading-tight group-hover:text-primary transition">{r.title}</h4>
                    <p className="text-[12.5px] text-slate-500 mt-2">{fmtDate(r.createdAt || r.date)}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}
    </div>
  );
};

export default NewsDetail;
