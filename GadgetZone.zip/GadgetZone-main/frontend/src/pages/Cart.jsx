import { Link, useNavigate } from 'react-router-dom';
import {
  FiTrash2, FiMinus, FiPlus, FiShoppingCart,
  FiArrowRight, FiArrowLeft, FiTruck, FiShield, FiTag,
} from 'react-icons/fi';
import { useCart } from '../context/CartContext';
import { toast } from 'react-toastify';

const Cart = () => {
  const navigate = useNavigate();
  const { cart, updateQuantity, removeFromCart } = useCart();

  const fmt = (p) => (p || 0).toLocaleString('vi-VN') + 'đ';

  const handleUpdateQty = async (productId, newQty) => {
    if (newQty < 1) return;
    try { await updateQuantity(productId, newQty); }
    catch { toast.error('Cập nhật thất bại'); }
  };

  const handleRemove = async (productId) => {
    try { await removeFromCart(productId); toast.success('Đã xóa khỏi giỏ'); }
    catch { toast.error('Xóa thất bại'); }
  };

  const items = cart?.items || [];
  const subtotal = items.reduce((s, it) => {
    const p = it.product?.salePrice && it.product.salePrice < it.product.price
      ? it.product.salePrice : it.product?.price || 0;
    return s + p * it.quantity;
  }, 0);
  const savings = items.reduce((s, it) => {
    if (it.product?.salePrice && it.product.salePrice < it.product.price) {
      return s + (it.product.price - it.product.salePrice) * it.quantity;
    }
    return s;
  }, 0);

  if (items.length === 0) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center px-4 py-16 bg-[#FAFAFA]">
        <div className="max-w-[440px] text-center">
          <div className="w-20 h-20 rounded-full bg-white border border-slate-200 mx-auto flex items-center justify-center">
            <FiShoppingCart className="text-3xl text-slate-300" />
          </div>
          <h2 className="font-heading text-[26px] font-extrabold text-[#0B1120] tracking-tight mt-6">
            Giỏ hàng của bạn đang trống
          </h2>
          <p className="text-slate-500 text-[14px] mt-3 leading-relaxed">
            Có vẻ như bạn chưa thêm sản phẩm nào. Hãy khám phá hàng trăm sản phẩm công nghệ tuyệt vời tại GadgetZone.
          </p>
          <Link
            to="/san-pham"
            className="inline-flex items-center gap-2 bg-[#0B1120] hover:bg-primary text-white px-7 py-3.5 rounded-lg font-semibold text-[14px] mt-7 transition group"
          >
            <FiArrowLeft className="group-hover:-translate-x-1 transition-transform" />
            Khám phá sản phẩm
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#FAFAFA] min-h-screen">
      <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-8 lg:py-10">
        <span className="gz-eyebrow text-primary">Đơn hàng của bạn</span>
        <h1 className="font-heading text-[28px] lg:text-[36px] font-extrabold tracking-tight text-[#0B1120] mt-2 leading-tight">
          Giỏ hàng <span className="text-slate-400 font-light">({items.length} sản phẩm)</span>
        </h1>

        <div className="grid lg:grid-cols-12 gap-6 mt-8">
          {/* Items */}
          <div className="lg:col-span-8">
            <div className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              {/* Header */}
              <div className="hidden md:grid grid-cols-[1fr_140px_140px_60px] gap-4 px-5 py-3.5 bg-slate-50 border-b border-slate-100">
                <span className="text-[11.5px] uppercase font-bold tracking-wider text-slate-500">Sản phẩm</span>
                <span className="text-[11.5px] uppercase font-bold tracking-wider text-slate-500 text-center">Số lượng</span>
                <span className="text-[11.5px] uppercase font-bold tracking-wider text-slate-500 text-right">Tạm tính</span>
                <span />
              </div>

              <div className="divide-y divide-slate-100">
                {items.map((it) => {
                  const p = it.product;
                  const unit = p?.salePrice && p.salePrice < p.price ? p.salePrice : p?.price || 0;
                  return (
                    <div key={it._id || p?._id} className="grid grid-cols-1 md:grid-cols-[1fr_140px_140px_60px] gap-4 p-5 items-center">
                      {/* Product */}
                      <div className="flex items-center gap-4 min-w-0">
                        <Link to={`/san-pham/${p?._id}`} className="w-20 h-20 rounded-lg bg-slate-50 border border-slate-100 overflow-hidden flex-shrink-0">
                          {p?.images?.[0] ? (
                            <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-slate-300"><FiShoppingCart /></div>
                          )}
                        </Link>
                        <div className="min-w-0 flex-1">
                          {p?.brand?.name && (
                            <span className="text-[10.5px] uppercase tracking-wider font-bold text-slate-400">{p.brand.name}</span>
                          )}
                          <Link to={`/san-pham/${p?._id}`} className="block text-[14px] font-semibold text-[#0B1120] hover:text-primary line-clamp-2 transition">
                            {p?.name}
                          </Link>
                          <span className="text-[12.5px] text-slate-500 mt-0.5 block">Đơn giá: {fmt(unit)}</span>
                        </div>
                      </div>

                      {/* Qty */}
                      <div className="flex md:justify-center">
                        <div className="inline-flex items-center bg-slate-50 border border-slate-200 rounded-lg overflow-hidden">
                          <button onClick={() => handleUpdateQty(p._id, it.quantity - 1)} className="w-9 h-9 flex items-center justify-center text-slate-600 hover:bg-white transition">
                            <FiMinus className="text-xs" />
                          </button>
                          <span className="w-10 text-center text-[13px] font-bold text-[#0B1120]">{it.quantity}</span>
                          <button onClick={() => handleUpdateQty(p._id, it.quantity + 1)} className="w-9 h-9 flex items-center justify-center text-slate-600 hover:bg-white transition">
                            <FiPlus className="text-xs" />
                          </button>
                        </div>
                      </div>

                      {/* Subtotal */}
                      <div className="font-heading text-[16px] font-extrabold text-[#0B1120] md:text-right">
                        {fmt(unit * it.quantity)}
                      </div>

                      {/* Remove */}
                      <button
                        onClick={() => handleRemove(p._id)}
                        className="w-9 h-9 rounded-lg text-slate-400 hover:bg-red-50 hover:text-red-500 flex items-center justify-center transition justify-self-end"
                        aria-label="Xóa"
                      >
                        <FiTrash2 />
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            <Link
              to="/san-pham"
              className="inline-flex items-center gap-2 text-[13px] text-slate-600 hover:text-[#0B1120] mt-5 font-medium transition group"
            >
              <FiArrowLeft className="group-hover:-translate-x-1 transition-transform" />
              Tiếp tục mua sắm
            </Link>
          </div>

          {/* Summary */}
          <div className="lg:col-span-4">
            <div className="bg-white border border-slate-200 rounded-xl p-6 sticky top-[100px]">
              <h3 className="font-heading font-bold text-[16px] text-[#0B1120] mb-4">Tóm tắt đơn hàng</h3>

              <div className="space-y-2.5 text-[13.5px]">
                <div className="flex justify-between text-slate-600">
                  <span>Tạm tính ({items.length} sản phẩm)</span>
                  <span className="text-[#0B1120] font-semibold">{fmt(subtotal)}</span>
                </div>
                {savings > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-600">Tiết kiệm</span>
                    <span className="text-accent font-semibold">-{fmt(savings)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Phí vận chuyển</span>
                  <span className="text-success font-bold">Miễn phí</span>
                </div>
              </div>

              {/* Voucher placeholder */}
              <div className="flex items-center gap-2 mt-4 p-3 bg-slate-50 border border-dashed border-slate-300 rounded-lg cursor-pointer hover:border-primary transition">
                <FiTag className="text-primary" />
                <span className="text-[12.5px] text-slate-600 font-medium">Áp dụng mã giảm giá</span>
              </div>

              <div className="border-t border-slate-100 my-5" />

              <div className="flex justify-between items-baseline">
                <span className="text-[14px] text-slate-600">Tổng cộng</span>
                <strong className="font-heading text-[26px] font-extrabold text-[#0B1120] tracking-tight">{fmt(subtotal)}</strong>
              </div>
              <p className="text-[11.5px] text-slate-400 text-right mt-0.5">Đã bao gồm VAT (nếu có)</p>

              <button
                onClick={() => navigate('/dat-hang')}
                className="w-full bg-[#0B1120] hover:bg-primary text-white py-4 rounded-lg font-bold text-[14px] mt-5 flex items-center justify-center gap-2 transition group"
              >
                Tiến hành thanh toán
                <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
              </button>

              {/* Trust */}
              <div className="grid grid-cols-2 gap-2 mt-5 pt-5 border-t border-slate-100">
                <div className="flex items-center gap-2 text-[11.5px] text-slate-600">
                  <FiTruck className="text-primary" /> Giao nhanh 2 giờ
                </div>
                <div className="flex items-center gap-2 text-[11.5px] text-slate-600">
                  <FiShield className="text-primary" /> Bảo hành chính hãng
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
