import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { FiCheckCircle, FiXCircle, FiArrowRight, FiPackage, FiHome } from 'react-icons/fi';
import { useCart } from '../context/CartContext';
import { paymentService } from '../services/paymentService';

const VnpayReturn = () => {
  const [searchParams] = useSearchParams();
  const { clearCart } = useCart();
  const [status, setStatus] = useState('loading');

  useEffect(() => {
    let active = true;
    const verify = async () => {
      try {
        // Gửi nguyên query VNPay sang backend để verify chữ ký và cập nhật đơn hàng
        const res = await paymentService.verifyVnpayReturn(window.location.search);
        if (!active) return;
        if (res.data?.success) {
          setStatus('success');
          clearCart();
        } else {
          setStatus('failed');
        }
      } catch {
        if (active) setStatus('failed');
      }
    };
    verify();
    return () => { active = false; };
  }, [searchParams, clearCart]);

  const amount = searchParams.get('vnp_Amount');
  const txnRef = searchParams.get('vnp_TxnRef');
  const bankCode = searchParams.get('vnp_BankCode');

  if (status === 'loading') {
    return (
      <div className="min-h-[70vh] flex flex-col items-center justify-center gap-4 bg-[#FAFAFA]">
        <div className="w-12 h-12 border-[3px] border-[#0B1120] border-t-transparent rounded-full animate-spin" />
        <p className="text-[14px] text-slate-500">Đang xử lý kết quả thanh toán VNPay...</p>
      </div>
    );
  }

  const isSuccess = status === 'success';

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4 py-12 bg-[#FAFAFA]">
      <div className="bg-white border border-slate-200 rounded-2xl p-8 lg:p-12 max-w-[520px] w-full text-center">
        <div className={`w-20 h-20 ${isSuccess ? 'bg-emerald-50 text-emerald-500' : 'bg-red-50 text-red-500'} rounded-full mx-auto flex items-center justify-center`}>
          {isSuccess ? <FiCheckCircle className="text-4xl" /> : <FiXCircle className="text-4xl" />}
        </div>

        <span className={`gz-eyebrow mt-6 block ${isSuccess ? 'text-emerald-600' : 'text-red-500'}`}>VNPay</span>
        <h1 className="font-heading text-[28px] lg:text-[32px] font-extrabold tracking-tight text-[#0B1120] mt-2 leading-tight">
          {isSuccess ? 'Thanh toán thành công!' : 'Thanh toán thất bại'}
        </h1>
        <p className="text-[14px] text-slate-500 leading-relaxed mt-3 max-w-[400px] mx-auto">
          {isSuccess
            ? 'Đơn hàng của bạn đã được thanh toán thành công qua VNPay. Cảm ơn bạn đã mua sắm tại GadgetZone!'
            : 'Giao dịch không thành công. Vui lòng thử lại hoặc chọn phương thức thanh toán khác.'}
        </p>

        {(isSuccess && (amount || txnRef || bankCode)) && (
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 mt-6 text-left space-y-2">
            {txnRef && (
              <div className="flex items-center justify-between text-[12.5px]">
                <span className="text-slate-500">Mã giao dịch</span>
                <span className="font-mono font-bold text-[#0B1120]">{txnRef}</span>
              </div>
            )}
            {amount && (
              <div className="flex items-center justify-between text-[12.5px]">
                <span className="text-slate-500">Số tiền</span>
                <span className="font-bold text-emerald-600">{(Number(amount) / 100).toLocaleString('vi-VN')}₫</span>
              </div>
            )}
            {bankCode && (
              <div className="flex items-center justify-between text-[12.5px]">
                <span className="text-slate-500">Ngân hàng</span>
                <span className="font-bold text-[#0B1120]">{bankCode}</span>
              </div>
            )}
          </div>
        )}

        <div className="flex gap-3 justify-center flex-wrap mt-7">
          <Link to="/don-hang" className="bg-[#0B1120] hover:bg-primary text-white px-6 py-3 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition group">
            <FiPackage /> Xem đơn hàng <FiArrowRight className="group-hover:translate-x-1 transition" />
          </Link>
          <Link to="/" className="border border-slate-200 hover:border-[#0B1120] text-slate-700 px-6 py-3 rounded-lg text-[13px] font-semibold inline-flex items-center gap-2 transition">
            <FiHome /> Về trang chủ
          </Link>
        </div>
      </div>
    </div>
  );
};

export default VnpayReturn;
