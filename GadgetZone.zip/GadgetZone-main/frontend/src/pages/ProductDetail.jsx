import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import {
  FiStar, FiShoppingCart, FiMinus, FiPlus, FiImage, FiHeart,
  FiTruck, FiShield, FiRefreshCw, FiMessageSquare, FiSend,
  FiCheckCircle, FiZap, FiCreditCard, FiChevronRight,
} from 'react-icons/fi';
import { productService } from '../services/productService';
import { reviewService } from '../services/reviewService';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { toast } from 'react-toastify';

const ProductDetail = () => {
  const { id } = useParams();
  const { user } = useAuth();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);
  const [activeImage, setActiveImage] = useState(0);
  const [activeTab, setActiveTab] = useState('description');
  const [reviewForm, setReviewForm] = useState({ rating: 5, comment: '' });
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const [prodRes, revRes] = await Promise.all([
          productService.getById(id),
          reviewService.getByProduct(id),
        ]);
        setProduct(prodRes.data.data || prodRes.data);
        setReviews(revRes.data.data || revRes.data || []);
        setActiveImage(0);
      } catch (err) {
        console.error(err);
        toast.error('Không thể tải thông tin sản phẩm');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    window.scrollTo(0, 0);
  }, [id]);

  // Format đầy đủ kiểu VN: 24.990.000₫ (cần chính xác trên trang chi tiết & thanh toán)
  const fmt = (p) => (p || 0).toLocaleString('vi-VN') + '₫';
  // Format gọn cho khoản tiết kiệm: 24,99 triệu
  const fmtShort = (p) => {
    const n = p || 0;
    if (n >= 1_000_000) {
      const tr = (n / 1_000_000).toFixed(2).replace(/\.?0+$/, '').replace('.', ',');
      return `${tr} triệu`;
    }
    if (n >= 1_000) return `${(n / 1_000).toFixed(0)}k`;
    return `${n.toLocaleString('vi-VN')}đ`;
  };

  const renderStars = (rating, size = 'text-sm') => (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((i) => (
        <FiStar
          key={i}
          className={`${size} ${i <= Math.round(rating || 0) ? 'fill-amber-400 text-amber-400' : 'fill-slate-200 text-slate-200'}`}
        />
      ))}
    </div>
  );

  const handleAddToCart = async () => {
    if (!user) { toast.warning('Vui lòng đăng nhập'); return; }
    try { await addToCart(product._id, quantity); toast.success('Đã thêm vào giỏ hàng'); }
    catch { toast.error('Thêm thất bại'); }
  };

  const handleSubmitReview = async (e) => {
    e.preventDefault();
    if (!reviewForm.comment.trim()) { toast.warning('Vui lòng nhập nội dung'); return; }
    setSubmitting(true);
    try {
      await reviewService.create({ productId: id, rating: reviewForm.rating, comment: reviewForm.comment });
      toast.success('Cảm ơn đánh giá của bạn');
      setReviewForm({ rating: 5, comment: '' });
      const revRes = await reviewService.getByProduct(id);
      setReviews(revRes.data.data || revRes.data || []);
    } catch { toast.error('Gửi đánh giá thất bại'); }
    finally { setSubmitting(false); }
  };

  if (loading)
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center gap-4">
        <div className="w-10 h-10 border-[3px] border-[#0B1120] border-t-transparent rounded-full animate-spin" />
        <span className="text-slate-500 text-sm">Đang tải...</span>
      </div>
    );

  if (!product)
    return <div className="min-h-[60vh] flex items-center justify-center text-slate-500">Không tìm thấy sản phẩm</div>;

  const hasDiscount = product.salePrice > 0 && product.salePrice < product.price;
  const discountPercent = hasDiscount ? Math.round((1 - product.salePrice / product.price) * 100) : 0;
  const finalPrice = hasDiscount ? product.salePrice : product.price;
  const images = product.images?.length ? product.images : [];
  const specs = product.specs || product.specifications || {};
  const specEntries = Array.isArray(specs)
    ? specs.map((s) => [s.key, s.value])
    : Object.entries(specs);

  return (
    <div className="bg-[#FAFAFA]">
      <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-6">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-1.5 text-[12.5px] text-slate-500 mb-6">
          <Link to="/" className="hover:text-[#0B1120] transition">Trang chủ</Link>
          <FiChevronRight className="text-[10px]" />
          <Link to="/san-pham" className="hover:text-[#0B1120] transition">Sản phẩm</Link>
          <FiChevronRight className="text-[10px]" />
          {product.category?.name && (
            <>
              <Link to={`/san-pham?category=${product.category._id}`} className="hover:text-[#0B1120] transition">
                {product.category.name}
              </Link>
              <FiChevronRight className="text-[10px]" />
            </>
          )}
          <span className="text-[#0B1120] font-medium truncate max-w-[280px]">{product.name}</span>
        </nav>

        {/* Main split */}
        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
          {/* ==== Gallery ==== */}
          <div className="lg:col-span-7">
            <div className="grid lg:grid-cols-[88px_1fr] gap-4">
              {/* Thumbnails */}
              {images.length > 1 && (
                <div className="hidden lg:flex flex-col gap-2.5">
                  {images.map((img, i) => (
                    <button
                      key={i}
                      onClick={() => setActiveImage(i)}
                      className={`aspect-square w-[88px] rounded-lg overflow-hidden border-2 transition ${activeImage === i ? 'border-[#0B1120]' : 'border-slate-200 hover:border-slate-300'}`}
                    >
                      <img src={img} alt={`thumb ${i}`} className="w-full h-full object-cover bg-white" />
                    </button>
                  ))}
                </div>
              )}

              {/* Main image */}
              <div className="relative bg-white border border-slate-200 rounded-2xl overflow-hidden aspect-square">
                {hasDiscount && (
                  <div className="absolute top-4 left-4 z-10 bg-accent text-white text-[12px] font-bold px-3 py-1.5 rounded-md flex items-center gap-1.5 uppercase tracking-wider">
                    <FiZap className="text-[12px]" />
                    Giảm {discountPercent}%
                  </div>
                )}
                {images[activeImage] ? (
                  <img src={images[activeImage]} alt={product.name} className="w-full h-full object-cover" />
                ) : (
                  <div className="flex items-center justify-center h-full text-slate-300 text-5xl">
                    <FiImage />
                  </div>
                )}
              </div>
            </div>

            {/* Mobile thumbnails */}
            {images.length > 1 && (
              <div className="lg:hidden flex gap-2 mt-3 overflow-x-auto no-scrollbar">
                {images.map((img, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveImage(i)}
                    className={`flex-shrink-0 w-16 h-16 rounded-md overflow-hidden border-2 ${activeImage === i ? 'border-[#0B1120]' : 'border-slate-200'}`}
                  >
                    <img src={img} alt={`thumb ${i}`} className="w-full h-full object-cover bg-white" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* ==== Info ==== */}
          <div className="lg:col-span-5">
            {product.brand?.name && (
              <span className="gz-eyebrow text-primary">{product.brand.name}</span>
            )}

            <h1 className="font-heading text-[24px] lg:text-[30px] font-extrabold tracking-tight text-[#0B1120] mt-2 leading-tight">
              {product.name}
            </h1>

            {/* Rating */}
            <div className="flex items-center gap-3 mt-3">
              {renderStars(product.rating, 'text-[14px]')}
              <span className="text-[13px] font-semibold text-[#0B1120]">{product.rating?.toFixed(1) || '0.0'}</span>
              <span className="text-[12.5px] text-slate-400">·</span>
              <span className="text-[12.5px] text-slate-500">{product.numReviews || 0} đánh giá</span>
              {product.stock > 0 && (
                <>
                  <span className="text-[12.5px] text-slate-400">·</span>
                  <span className="text-[12.5px] text-success font-semibold flex items-center gap-1">
                    <FiCheckCircle className="text-xs" /> Còn hàng
                  </span>
                </>
              )}
            </div>

            {/* Price block */}
            <div className="mt-6 p-5 bg-white border border-slate-200 rounded-xl">
              <div className="flex items-baseline flex-wrap gap-x-3 gap-y-1">
                <span className="font-heading text-[36px] font-extrabold text-[#0B1120] tracking-tight">
                  {fmt(finalPrice)}
                </span>
                {hasDiscount && (
                  <>
                    <span className="text-[16px] text-slate-400 line-through">{fmt(product.price)}</span>
                    <span className="bg-accent-light text-accent text-[12px] font-bold px-2.5 py-1 rounded-md">
                      -{discountPercent}%
                    </span>
                  </>
                )}
              </div>
              {hasDiscount && (
                <p className="text-[13px] text-accent font-semibold mt-1.5">
                  Tiết kiệm {fmtShort(product.price - product.salePrice)} so với giá niêm yết
                </p>
              )}

              <div className="grid grid-cols-2 gap-2 mt-4 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-2 text-[12.5px] text-slate-600">
                  <FiCreditCard className="text-primary text-[14px]" /> Trả góp 0%
                </div>
                <div className="flex items-center gap-2 text-[12.5px] text-slate-600">
                  <FiTruck className="text-primary text-[14px]" /> Giao nhanh 2 giờ
                </div>
              </div>
            </div>

            {/* Quantity & CTA */}
            <div className="mt-6">
              <label className="block text-[12.5px] font-bold text-slate-600 mb-2">Số lượng</label>
              <div className="flex gap-3">
                <div className="inline-flex items-center bg-white border border-slate-200 rounded-lg overflow-hidden">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-11 h-12 flex items-center justify-center text-slate-600 hover:bg-slate-50 transition"
                  >
                    <FiMinus />
                  </button>
                  <input value={quantity} readOnly className="w-12 h-12 text-center font-bold border-x border-slate-200 outline-none bg-transparent" />
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="w-11 h-12 flex items-center justify-center text-slate-600 hover:bg-slate-50 transition"
                  >
                    <FiPlus />
                  </button>
                </div>
                <button
                  onClick={handleAddToCart}
                  className="flex-1 bg-[#0B1120] hover:bg-primary text-white font-semibold text-[14px] rounded-lg flex items-center justify-center gap-2.5 h-12 transition"
                >
                  <FiShoppingCart /> Thêm vào giỏ
                </button>
                <button
                  onClick={() => toast.info('Đã thêm yêu thích')}
                  className="w-12 h-12 border border-slate-200 rounded-lg flex items-center justify-center text-slate-600 hover:border-[#0B1120] hover:text-[#0B1120] transition"
                  aria-label="Yêu thích"
                >
                  <FiHeart />
                </button>
              </div>

              <button
                onClick={async () => { await handleAddToCart(); }}
                className="w-full mt-3 bg-accent hover:bg-accent-hover text-white font-semibold text-[14px] rounded-lg flex items-center justify-center gap-2 h-12 transition"
              >
                Mua ngay
              </button>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-3 mt-6">
              {[
                { icon: FiShield, label: 'Chính hãng', sub: '12 tháng' },
                { icon: FiRefreshCw, label: 'Đổi trả', sub: '30 ngày' },
                { icon: FiTruck, label: 'Giao hàng', sub: 'Toàn quốc' },
              ].map((t) => {
                const Icon = t.icon;
                return (
                  <div key={t.label} className="bg-white border border-slate-200 rounded-lg p-3 text-center">
                    <Icon className="text-[#0B1120] text-[18px] mx-auto" />
                    <div className="text-[12px] font-bold text-[#0B1120] mt-1">{t.label}</div>
                    <div className="text-[10.5px] text-slate-500">{t.sub}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* ==== Tabs: Description / Specs / Reviews ==== */}
        <div className="mt-14">
          <div className="flex items-center gap-1 border-b border-slate-200 overflow-x-auto no-scrollbar">
            {[
              { k: 'description', label: 'Mô tả' },
              { k: 'specs', label: 'Thông số kỹ thuật' },
              { k: 'reviews', label: `Đánh giá (${reviews.length})` },
            ].map((t) => (
              <button
                key={t.k}
                onClick={() => setActiveTab(t.k)}
                className={`px-5 py-3.5 text-[14px] font-semibold whitespace-nowrap transition border-b-2 ${activeTab === t.k ? 'text-[#0B1120] border-[#0B1120]' : 'text-slate-500 border-transparent hover:text-slate-700'}`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="bg-white border border-slate-200 border-t-0 rounded-b-xl p-6 lg:p-8">
            {activeTab === 'description' && (
              <div className="prose prose-slate max-w-none">
                <p className="text-[14.5px] leading-[1.8] text-slate-700 whitespace-pre-line">
                  {product.description || 'Chưa có mô tả chi tiết.'}
                </p>
              </div>
            )}

            {activeTab === 'specs' && (
              specEntries.length === 0 ? (
                <p className="text-slate-500 text-[13.5px]">Chưa cập nhật thông số.</p>
              ) : (
                <div className="grid sm:grid-cols-2 gap-x-10 gap-y-0">
                  {specEntries.map(([k, v], i) => (
                    <div key={i} className="grid grid-cols-[140px_1fr] gap-4 py-3.5 border-b border-slate-100 last:border-0">
                      <span className="text-[13px] text-slate-500 font-medium">{k}</span>
                      <span className="text-[13.5px] text-[#0B1120] font-medium">{v}</span>
                    </div>
                  ))}
                </div>
              )
            )}

            {activeTab === 'reviews' && (
              <div>
                {/* Review form */}
                {user && (
                  <form onSubmit={handleSubmitReview} className="bg-slate-50 border border-slate-200 rounded-xl p-5 mb-6">
                    <h3 className="font-heading text-[15px] font-bold text-[#0B1120] mb-3 flex items-center gap-2">
                      <FiMessageSquare /> Đánh giá của bạn
                    </h3>
                    <div className="flex items-center gap-3 mb-3">
                      <span className="text-[13px] text-slate-600">Số sao:</span>
                      <div className="flex items-center gap-1">
                        {[1,2,3,4,5].map((s) => (
                          <button
                            key={s} type="button"
                            onClick={() => setReviewForm({ ...reviewForm, rating: s })}
                            className="text-[20px]"
                          >
                            <FiStar className={s <= reviewForm.rating ? 'fill-amber-400 text-amber-400' : 'fill-slate-200 text-slate-200'} />
                          </button>
                        ))}
                      </div>
                    </div>
                    <textarea
                      rows={4}
                      placeholder="Chia sẻ trải nghiệm của bạn..."
                      value={reviewForm.comment}
                      onChange={(e) => setReviewForm({ ...reviewForm, comment: e.target.value })}
                      className="w-full bg-white border border-slate-200 rounded-lg p-3 text-[13.5px] outline-none focus:border-[#0B1120] resize-none transition"
                    />
                    <button
                      type="submit"
                      disabled={submitting}
                      className="mt-3 bg-[#0B1120] hover:bg-primary text-white px-5 py-2.5 rounded-lg font-semibold text-[13px] flex items-center gap-2 transition disabled:opacity-50"
                    >
                      <FiSend /> {submitting ? 'Đang gửi...' : 'Gửi đánh giá'}
                    </button>
                  </form>
                )}

                {/* Reviews list */}
                {reviews.length === 0 ? (
                  <p className="text-slate-500 text-[13.5px] text-center py-10">Chưa có đánh giá nào — hãy là người đầu tiên!</p>
                ) : (
                  <div className="divide-y divide-slate-100">
                    {reviews.map((r) => (
                      <div key={r._id} className="flex gap-4 py-5">
                        <div className="w-11 h-11 rounded-full bg-[#0B1120] text-white text-[14px] font-bold flex items-center justify-center flex-shrink-0">
                          {(r.user?.name || 'A').charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-3 flex-wrap">
                            <div>
                              <strong className="text-[13.5px] text-[#0B1120]">{r.user?.name || 'Ẩn danh'}</strong>
                              <span className="text-[11.5px] text-slate-400 ml-2">
                                {new Date(r.createdAt).toLocaleDateString('vi-VN')}
                              </span>
                            </div>
                            {renderStars(r.rating, 'text-[12px]')}
                          </div>
                          <p className="text-[13.5px] text-slate-600 mt-2 leading-relaxed">{r.comment}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
