import { Link } from 'react-router-dom';
import {
  FiShield, FiHeart, FiZap, FiUsers, FiArrowRight,
  FiTarget, FiAward, FiTrendingUp, FiArrowUpRight,
} from 'react-icons/fi';

const STATS = [
  { num: '5+', label: 'Năm phát triển' },
  { num: '50K+', label: 'Khách hàng tin tưởng' },
  { num: '1.000+', label: 'Sản phẩm chính hãng' },
  { num: '63', label: 'Tỉnh thành phục vụ' },
];

const VALUES = [
  { icon: FiShield, title: 'Chất lượng tuyệt đối', desc: '100% sản phẩm chính hãng, có giấy tờ và bảo hành đầy đủ từ nhà sản xuất.' },
  { icon: FiHeart, title: 'Khách hàng là trung tâm', desc: 'Mỗi quyết định đều xoay quanh việc mang lại trải nghiệm tốt nhất cho người mua.' },
  { icon: FiZap, title: 'Đổi mới liên tục', desc: 'Cập nhật xu hướng công nghệ mới nhất từ Apple, Samsung và các thương hiệu hàng đầu.' },
  { icon: FiUsers, title: 'Đội ngũ tận tâm', desc: 'Chuyên gia tư vấn được đào tạo bài bản, am hiểu sản phẩm và tận tâm với khách hàng.' },
];

const MILESTONES = [
  { year: '2021', title: 'Thành lập GadgetZone', desc: 'Cửa hàng đầu tiên tại Hà Nội' },
  { year: '2023', title: 'Mở rộng toàn quốc', desc: 'Phủ sóng tới 63 tỉnh thành với dịch vụ giao nhanh' },
  { year: '2025', title: 'Triển khai AI Chatbot', desc: 'Trợ lý AI tư vấn sản phẩm 24/7 ra mắt' },
  { year: '2026', title: 'Đối tác chiến lược Apple', desc: 'Trở thành Apple Authorized Reseller chính thức' },
];

const About = () => {
  return (
    <div className="bg-[#FAFAFA]">
      {/* Hero — editorial */}
      <section className="bg-emerald-50 border-b border-slate-200 relative overflow-hidden">
        <div className="absolute -top-40 -right-40 w-[400px] h-[400px] rounded-full bg-emerald-500/15 blur-3xl pointer-events-none" />
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-16 lg:py-24 grid lg:grid-cols-12 gap-10 relative">
          <div className="lg:col-span-7">
            <span className="gz-eyebrow text-emerald-600">Câu chuyện của chúng tôi</span>
            <h1 className="font-heading text-[44px] lg:text-[72px] font-black tracking-[-0.025em] text-[#0B1120] mt-4 leading-[0.98]">
              Mang công nghệ <span className="text-emerald-600">đến gần</span> người Việt.
            </h1>
            <p className="text-slate-600 text-[16px] lg:text-[17px] mt-6 max-w-[560px] leading-relaxed">
              GadgetZone không chỉ là một cửa hàng — chúng tôi là người bạn đồng hành trong hành trình khám phá công nghệ của bạn. Từ chiếc iPhone đầu tiên đến chiếc laptop tốt nhất cho công việc, chúng tôi có mặt ở đó.
            </p>
          </div>
          <div className="lg:col-span-5 grid grid-cols-2 gap-3 self-end">
            {STATS.map((s, i) => (
              <div key={i} className={`${i % 2 === 0 ? 'bg-[#0B1120] text-white' : 'bg-slate-100'} rounded-2xl p-6`}>
                <div className={`font-heading text-[36px] lg:text-[44px] font-black tracking-tight leading-none ${i % 2 === 0 ? 'text-white' : 'text-[#0B1120]'}`}>
                  {s.num}
                </div>
                <div className={`text-[12.5px] mt-2 ${i % 2 === 0 ? 'text-slate-400' : 'text-slate-500'}`}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 py-16 lg:py-20 grid lg:grid-cols-12 gap-12">
        <div className="lg:col-span-5">
          <span className="gz-eyebrow text-primary">Sứ mệnh</span>
          <h2 className="font-heading text-[32px] lg:text-[42px] font-extrabold tracking-tight text-[#0B1120] mt-3 leading-tight">
            Công nghệ phải <span className="text-primary">dễ tiếp cận.</span>
          </h2>
        </div>
        <div className="lg:col-span-7 space-y-5 text-[15.5px] leading-[1.8] text-slate-600">
          <p>
            Khi bắt đầu vào năm 2021, chúng tôi tin rằng mọi người đều xứng đáng được sở hữu công nghệ tốt nhất — không chỉ những người am hiểu kỹ thuật. Đó là lý do GadgetZone được sinh ra: nơi tư vấn rõ ràng, sản phẩm chính hãng và giá tốt thực sự.
          </p>
          <p>
            Sau 5 năm, chúng tôi đã phục vụ hơn 50.000 khách hàng trên toàn quốc, hợp tác với những thương hiệu hàng đầu thế giới và xây dựng một đội ngũ tư vấn được đào tạo bài bản. Nhưng điều quan trọng nhất, chúng tôi vẫn giữ đúng cam kết ban đầu — <strong className="text-[#0B1120]">đặt khách hàng lên trên hết.</strong>
          </p>
        </div>
      </section>

      {/* Values */}
      <section className="bg-white border-y border-slate-200 py-16 lg:py-20">
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6">
          <div className="flex items-end justify-between gap-6 flex-wrap mb-10">
            <div>
              <span className="gz-eyebrow text-primary">Giá trị cốt lõi</span>
              <h2 className="font-heading text-[28px] lg:text-[40px] font-extrabold tracking-tight text-[#0B1120] mt-2 leading-tight">
                Bốn điều luôn dẫn lối chúng tôi
              </h2>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-5">
            {VALUES.map((v, i) => {
              const Icon = v.icon;
              return (
                <div key={i} className="bg-[#FAFAFA] border border-slate-200 rounded-2xl p-6 lg:p-7 hover:border-[#0B1120] transition group">
                  <div className="flex items-center justify-between mb-5">
                    <div className="w-12 h-12 rounded-xl bg-[#0B1120] text-white flex items-center justify-center group-hover:bg-primary transition">
                      <Icon className="text-[20px]" />
                    </div>
                    <span className="text-[11px] font-mono text-slate-300">0{i + 1}</span>
                  </div>
                  <h3 className="font-heading text-[16px] font-bold text-[#0B1120] tracking-tight">{v.title}</h3>
                  <p className="text-[13.5px] text-slate-500 mt-2 leading-relaxed">{v.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 py-16 lg:py-20">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-4">
            <span className="gz-eyebrow text-primary">Hành trình</span>
            <h2 className="font-heading text-[32px] lg:text-[42px] font-extrabold tracking-tight text-[#0B1120] mt-3 leading-tight">
              5 năm phát triển không ngừng
            </h2>
          </div>
          <div className="lg:col-span-8">
            <div className="border-l-2 border-slate-200 pl-8 space-y-10">
              {MILESTONES.map((m, i) => (
                <div key={i} className="relative">
                  <div className="absolute -left-[42px] top-1 w-5 h-5 rounded-full bg-[#0B1120] border-4 border-[#FAFAFA]" />
                  <div className="font-mono text-[12.5px] text-primary font-bold tracking-wider">{m.year}</div>
                  <h3 className="font-heading text-[20px] font-bold text-[#0B1120] mt-1">{m.title}</h3>
                  <p className="text-[14px] text-slate-500 mt-1 leading-relaxed">{m.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 pb-20">
        <div className="bg-[#0B1120] text-white rounded-3xl p-10 lg:p-16 grid lg:grid-cols-2 gap-8 items-center relative overflow-hidden">
          <div className="absolute -bottom-20 -right-20 w-[400px] h-[400px] rounded-full bg-primary/20 blur-3xl pointer-events-none" />
          <div className="relative">
            <span className="gz-eyebrow text-blue-400">Sẵn sàng mua sắm?</span>
            <h2 className="font-heading text-[32px] lg:text-[44px] font-black tracking-tight leading-tight mt-4">
              Khám phá sản phẩm GadgetZone ngay hôm nay
            </h2>
          </div>
          <div className="relative flex flex-col sm:flex-row gap-3 lg:justify-end">
            <Link to="/san-pham" className="bg-white text-[#0B1120] hover:bg-primary hover:text-white px-7 py-4 rounded-lg font-semibold text-[14px] inline-flex items-center justify-center gap-2.5 transition group">
              Xem sản phẩm <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link to="/lien-he" className="border border-white/20 hover:border-white px-7 py-4 rounded-lg font-medium text-[14px] inline-flex items-center justify-center gap-2 transition">
              Liên hệ với chúng tôi <FiArrowUpRight />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
