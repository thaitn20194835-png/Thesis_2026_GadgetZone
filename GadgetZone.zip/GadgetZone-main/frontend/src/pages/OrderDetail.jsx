import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { FiArrowLeft, FiMapPin, FiShoppingCart } from 'react-icons/fi';
import { orderService } from '../services/orderService';
import { toast } from 'react-toastify';

const statusMap = {
  pending: { label: 'Chờ xác nhận', cls: 'bg-amber-50 text-amber-600' },
  confirmed: { label: 'Đã xác nhận', cls: 'bg-blue-50 text-blue-600' },
  shipping: { label: 'Đang giao', cls: 'bg-indigo-50 text-indigo-600' },
  delivered: { label: 'Đã giao', cls: 'bg-green-50 text-green-600' },
  cancelled: { label: 'Đã hủy', cls: 'bg-red-50 text-red-600' },
};

const OrderDetail = () => {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOrder = async () => {
      try {
        const res = await orderService.getOrderById(id);
        setOrder(res.data.data || res.data);
      } catch {
        toast.error('Không thể tải thông tin đơn hàng');
      } finally {
        setLoading(false);
      }
    };
    fetchOrder();
  }, [id]);

  const formatPrice = (price) => price?.toLocaleString('vi-VN') + 'đ';

  if (loading)
    return (
      <div className="max-w-[800px] mx-auto px-4 py-10 text-center text-slate-500">
        Đang tải...
      </div>
    );
  if (!order)
    return (
      <div className="max-w-[800px] mx-auto px-4 py-10 text-center text-slate-500">
        Không tìm thấy đơn hàng
      </div>
    );

  const status = statusMap[order.status] || {
    label: order.status,
    cls: 'bg-amber-50 text-amber-600',
  };

  return (
    <div className="max-w-[800px] mx-auto px-4 py-10">
      <Link
        to="/don-hang"
        className="text-sm text-slate-500 hover:text-primary flex items-center gap-1"
      >
        <FiArrowLeft /> Quay lại
      </Link>

      <div className="flex items-start justify-between mt-4">
        <div>
          <h1 className="font-heading font-bold text-2xl">
            Đơn hàng #{order._id?.slice(-8).toUpperCase()}
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Ngày đặt: {new Date(order.createdAt).toLocaleDateString('vi-VN')}
          </p>
        </div>
        <span className={`px-3 py-1 rounded-full text-xs font-semibold ${status.cls}`}>
          {status.label}
        </span>
      </div>

      <div className="grid grid-cols-2 max-sm:grid-cols-1 gap-4 mt-4">
        {/* Thông tin giao hàng */}
        <div className="bg-white border rounded-lg p-5">
          <h2 className="font-semibold text-sm flex items-center gap-1.5 mb-3">
            <FiMapPin className="text-primary" /> Thông tin giao hàng
          </h2>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-slate-500">Người nhận:</span>
              <strong>{order.shippingAddress?.name}</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Số điện thoại:</span>
              <strong>{order.shippingAddress?.phone}</strong>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Địa chỉ:</span>
              <strong className="text-right max-w-[60%]">{order.shippingAddress?.address}</strong>
            </div>
            {order.note && (
              <div className="flex justify-between">
                <span className="text-slate-500">Ghi chú:</span>
                <strong className="text-right max-w-[60%]">{order.note}</strong>
              </div>
            )}
            <div className="flex justify-between">
              <span className="text-slate-500">Thanh toán:</span>
              <strong>
                {order.paymentMethod === 'vnpay'
                  ? 'VNPay'
                  : 'Thanh toán khi nhận hàng'}
              </strong>
            </div>
          </div>
        </div>

        {/* Danh sách sản phẩm */}
        <div className="bg-white border rounded-lg p-5">
          <h2 className="font-semibold text-sm flex items-center gap-1.5 mb-3">
            <FiShoppingCart className="text-primary" /> Sản phẩm đã đặt
          </h2>
        </div>
      </div>

      {/* Items */}
      <div className="bg-white border rounded-lg overflow-hidden mt-4 divide-y">
        {(order.items || []).map((item, idx) => {
          const product = item.product;
          const unitPrice = item.price || product?.price || 0;
          return (
            <div key={idx} className="flex items-center gap-3 px-5 py-3">
              <div className="w-12 h-12 rounded-md overflow-hidden flex-shrink-0 bg-slate-100">
                {product?.images && product.images.length > 0 ? (
                  <img
                    src={product.images[0]}
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-slate-400">
                    <FiShoppingCart />
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <span className="text-sm font-medium block truncate">
                  {product?.name || 'Sản phẩm'}
                </span>
                <span className="text-xs text-slate-500">
                  SL: {item.quantity} x {formatPrice(unitPrice)}
                </span>
              </div>
              <span className="text-sm font-semibold text-accent whitespace-nowrap">
                {formatPrice(unitPrice * item.quantity)}
              </span>
            </div>
          );
        })}
        <div className="flex items-center justify-between px-5 py-4 bg-slate-50">
          <span className="text-sm font-medium">Tổng cộng:</span>
          <strong className="text-accent text-xl font-bold">
            {formatPrice(order.totalAmount)}
          </strong>
        </div>
      </div>
    </div>
  );
};

export default OrderDetail;
