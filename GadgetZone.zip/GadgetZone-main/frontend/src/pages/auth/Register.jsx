import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FiUser, FiMail, FiPhone, FiLock, FiArrowRight, FiCheckCircle, FiTag, FiGift } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'react-toastify';

const Register = () => {
  const navigate = useNavigate();
  const { register } = useAuth();
  const [form, setForm] = useState({ name: '', email: '', phone: '', password: '', confirmPassword: '' });
  const [loading, setLoading] = useState(false);

  const handle = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.password || !form.confirmPassword) { toast.warning('Vui lòng nhập đầy đủ'); return; }
    if (form.password !== form.confirmPassword) { toast.error('Mật khẩu không khớp'); return; }
    if (form.password.length < 6) { toast.warning('Mật khẩu tối thiểu 6 ký tự'); return; }
    setLoading(true);
    try {
      await register({ name: form.name, email: form.email, phone: form.phone, password: form.password });
      toast.success('Đăng ký thành công');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Đăng ký thất bại');
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-white">
      {/* Form panel */}
      <div className="flex items-center justify-center p-6 lg:p-12 order-2 lg:order-1">
        <div className="w-full max-w-[480px]">
          <Link to="/" className="lg:hidden inline-flex items-center gap-2.5 mb-8">
            <div className="w-10 h-10 bg-[#0B1120] rounded-lg flex items-center justify-center">
              <span className="font-heading font-black text-white text-[15px] tracking-tighter">GZ</span>
            </div>
            <span className="font-heading font-extrabold text-[22px] tracking-tight">
              Gadget<span className="text-primary">Zone</span>
            </span>
          </Link>

          <span className="gz-eyebrow text-primary">Đăng ký</span>
          <h1 className="font-heading text-[32px] lg:text-[36px] font-extrabold tracking-tight text-[#0B1120] mt-2">
            Tạo tài khoản mới
          </h1>
          <p className="text-slate-500 text-[14px] mt-2">
            Đã có tài khoản?{' '}
            <Link to="/dang-nhap" className="font-bold text-[#0B1120] hover:text-primary border-b border-[#0B1120] hover:border-primary transition">
              Đăng nhập
            </Link>
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[12.5px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Họ và tên</label>
                <div className="relative">
                  <FiUser className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input value={form.name} onChange={handle('name')} placeholder="Nguyễn Văn A"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3.5 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
              </div>
              <div>
                <label className="block text-[12.5px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Số điện thoại</label>
                <div className="relative">
                  <FiPhone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="tel" value={form.phone} onChange={handle('phone')} placeholder="0901234567"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3.5 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
              </div>
            </div>

            <div>
              <label className="block text-[12.5px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Email</label>
              <div className="relative">
                <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input type="email" value={form.email} onChange={handle('email')} placeholder="email@cuaban.com"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3.5 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[12.5px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Mật khẩu</label>
                <div className="relative">
                  <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="password" value={form.password} onChange={handle('password')} placeholder="Tối thiểu 6 ký tự"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3.5 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
              </div>
              <div>
                <label className="block text-[12.5px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Xác nhận mật khẩu</label>
                <div className="relative">
                  <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="password" value={form.confirmPassword} onChange={handle('confirmPassword')} placeholder="Nhập lại"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3.5 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
              </div>
            </div>

            <p className="text-[12px] text-slate-500 leading-relaxed pt-1">
              Bằng việc tạo tài khoản, bạn đồng ý với{' '}
              <a href="#" className="text-primary font-semibold">Điều khoản sử dụng</a> và{' '}
              <a href="#" className="text-primary font-semibold">Chính sách bảo mật</a> của GadgetZone.
            </p>

            <button type="submit" disabled={loading}
              className="w-full bg-[#0B1120] hover:bg-primary text-white py-3.5 rounded-lg font-bold text-[14px] transition flex items-center justify-center gap-2 group disabled:opacity-50"
            >
              {loading ? 'Đang xử lý...' : (
                <>
                  Tạo tài khoản
                  <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>
        </div>
      </div>

      {/* Visual panel */}
      <div className="hidden lg:flex bg-[#0B1120] text-white p-12 xl:p-16 flex-col justify-between relative overflow-hidden order-1 lg:order-2">
        <div className="absolute -top-40 -left-40 w-[400px] h-[400px] rounded-full bg-accent/15 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-40 -right-40 w-[400px] h-[400px] rounded-full bg-primary/20 blur-3xl pointer-events-none" />

        <Link to="/" className="relative inline-flex items-center gap-2.5 self-end">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <span className="font-heading font-black text-white text-[15px] tracking-tighter">GZ</span>
          </div>
          <span className="font-heading font-extrabold text-[22px] tracking-tight">
            Gadget<span className="text-primary">Zone</span>
          </span>
        </Link>

        <div className="relative">
          <span className="gz-eyebrow text-blue-400">Tham gia cộng đồng</span>
          <h2 className="font-heading text-[40px] xl:text-[52px] font-black leading-[1.05] tracking-tight mt-4 max-w-[440px]">
            Đặc quyền dành riêng <span className="text-accent">cho bạn.</span>
          </h2>

          <ul className="mt-8 space-y-3.5 max-w-[400px]">
            {[
              { icon: FiGift, label: 'Tặng voucher 200.000đ cho đơn đầu tiên' },
              { icon: FiTag, label: 'Giảm thêm 5% cho thành viên VIP' },
              { icon: FiCheckCircle, label: 'Theo dõi đơn hàng & đánh giá sản phẩm' },
            ].map((b, i) => {
              const Icon = b.icon;
              return (
                <li key={i} className="flex items-center gap-3.5 text-[14px] text-slate-300">
                  <span className="w-9 h-9 rounded-lg bg-primary/15 border border-primary/30 flex items-center justify-center text-primary flex-shrink-0">
                    <Icon className="text-[15px]" />
                  </span>
                  {b.label}
                </li>
              );
            })}
          </ul>
        </div>

        <div className="relative">
          <p className="text-[12.5px] text-slate-500">
            "Mua iPhone 15 Pro Max tại GadgetZone — giao chỉ 2h, gói cẩn thận, giá tốt hơn nhiều cửa hàng khác."
          </p>
          <p className="text-[12px] text-slate-400 mt-2 font-medium">— Trần Minh Tuấn, khách hàng</p>
        </div>
      </div>
    </div>
  );
};

export default Register;
