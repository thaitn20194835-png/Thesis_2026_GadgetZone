import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { FiMail, FiLock, FiEye, FiEyeOff, FiArrowRight, FiShield, FiTruck, FiHeadphones } from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'react-toastify';

const Login = () => {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [form, setForm] = useState({ email: '', password: '' });
  const [showPwd, setShowPwd] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) { toast.warning('Vui lòng nhập đầy đủ'); return; }
    setLoading(true);
    try {
      await login(form.email, form.password);
      toast.success('Đăng nhập thành công');
      navigate('/');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Đăng nhập thất bại');
    } finally { setLoading(false); }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2 bg-white">
      {/* Left visual panel */}
      <div className="hidden lg:flex bg-[#0B1120] text-white p-12 xl:p-16 flex-col justify-between relative overflow-hidden">
        <div className="absolute -top-32 -right-32 w-[400px] h-[400px] rounded-full bg-primary/20 blur-3xl pointer-events-none" />
        <div className="absolute -bottom-40 -left-40 w-[400px] h-[400px] rounded-full bg-accent/15 blur-3xl pointer-events-none" />

        <Link to="/" className="relative inline-flex items-center gap-2.5">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <span className="font-heading font-black text-white text-[15px] tracking-tighter">GZ</span>
          </div>
          <span className="font-heading font-extrabold text-[22px] tracking-tight">
            Gadget<span className="text-primary">Zone</span>
          </span>
        </Link>

        <div className="relative">
          <span className="gz-eyebrow text-blue-400">Chào mừng trở lại</span>
          <h2 className="font-heading text-[40px] xl:text-[52px] font-black leading-[1.05] tracking-tight mt-4 max-w-[440px]">
            Mọi thiết bị công nghệ <span className="text-primary">bạn yêu</span> — tại một nơi.
          </h2>
          <p className="text-slate-400 text-[14.5px] leading-relaxed mt-5 max-w-[420px]">
            Đăng nhập để theo dõi đơn hàng, lưu sản phẩm yêu thích và nhận ưu đãi độc quyền dành riêng cho thành viên.
          </p>
        </div>

        <div className="relative grid grid-cols-3 gap-3">
          {[
            { icon: FiShield, label: 'Bảo hành 12 tháng' },
            { icon: FiTruck, label: 'Giao toàn quốc' },
            { icon: FiHeadphones, label: 'Hỗ trợ 24/7' },
          ].map((b, i) => {
            const Icon = b.icon;
            return (
              <div key={i} className="border border-white/10 bg-white/[0.03] rounded-xl p-4">
                <Icon className="text-primary text-[18px]" />
                <p className="text-[12px] text-slate-300 mt-2 leading-tight">{b.label}</p>
              </div>
            );
          })}
        </div>
      </div>

      {/* Right form panel */}
      <div className="flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-[420px]">
          {/* Mobile logo */}
          <Link to="/" className="lg:hidden inline-flex items-center gap-2.5 mb-8">
            <div className="w-10 h-10 bg-[#0B1120] rounded-lg flex items-center justify-center">
              <span className="font-heading font-black text-white text-[15px] tracking-tighter">GZ</span>
            </div>
            <span className="font-heading font-extrabold text-[22px] tracking-tight">
              Gadget<span className="text-primary">Zone</span>
            </span>
          </Link>

          <span className="gz-eyebrow text-primary">Đăng nhập</span>
          <h1 className="font-heading text-[32px] lg:text-[36px] font-extrabold tracking-tight text-[#0B1120] mt-2">
            Xin chào, bạn đã trở lại!
          </h1>
          <p className="text-slate-500 text-[14px] mt-2">
            Chưa có tài khoản?{' '}
            <Link to="/dang-ky" className="font-bold text-[#0B1120] hover:text-primary border-b border-[#0B1120] hover:border-primary transition">
              Đăng ký ngay
            </Link>
          </p>

          <form onSubmit={handleSubmit} className="mt-8 space-y-4">
            <div>
              <label className="block text-[12.5px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Email</label>
              <div className="relative">
                <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="email" name="email" autoComplete="email"
                  placeholder="email@cuaban.com"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3.5 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition"
                />
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-[12.5px] font-bold text-slate-700 tracking-wide uppercase">Mật khẩu</label>
                <a href="#" className="text-[12px] text-primary hover:underline font-semibold">Quên mật khẩu?</a>
              </div>
              <div className="relative">
                <FiLock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type={showPwd ? 'text' : 'password'} name="password" autoComplete="current-password"
                  placeholder="Tối thiểu 6 ký tự"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-12 py-3.5 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition"
                />
                <button
                  type="button" onClick={() => setShowPwd(!showPwd)}
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-700"
                >
                  {showPwd ? <FiEyeOff /> : <FiEye />}
                </button>
              </div>
            </div>

            <button
              type="submit" disabled={loading}
              className="w-full bg-[#0B1120] hover:bg-primary text-white py-3.5 rounded-lg font-bold text-[14px] transition flex items-center justify-center gap-2 group disabled:opacity-50"
            >
              {loading ? 'Đang xử lý...' : (
                <>
                  Đăng nhập
                  <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
                </>
              )}
            </button>
          </form>

          <div className="flex items-center gap-3 my-6">
            <div className="flex-1 border-t border-slate-200" />
            <span className="text-[11.5px] text-slate-400 uppercase tracking-wider font-semibold">Demo nhanh</span>
            <div className="flex-1 border-t border-slate-200" />
          </div>

          <div className="grid sm:grid-cols-2 gap-2">
            <button
              onClick={() => setForm({ email: 'admin@gadgetzone.vn', password: 'admin123' })}
              className="text-left bg-slate-50 border border-slate-200 rounded-lg p-3 hover:border-[#0B1120] transition"
            >
              <span className="text-[10.5px] uppercase tracking-wider font-bold text-slate-400">Admin</span>
              <p className="text-[12.5px] font-mono text-[#0B1120] mt-0.5 truncate">admin@gadgetzone.vn</p>
            </button>
            <button
              onClick={() => setForm({ email: 'nguyenvana@gmail.com', password: '123456' })}
              className="text-left bg-slate-50 border border-slate-200 rounded-lg p-3 hover:border-[#0B1120] transition"
            >
              <span className="text-[10.5px] uppercase tracking-wider font-bold text-slate-400">Khách hàng</span>
              <p className="text-[12.5px] font-mono text-[#0B1120] mt-0.5 truncate">nguyenvana@gmail.com</p>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
