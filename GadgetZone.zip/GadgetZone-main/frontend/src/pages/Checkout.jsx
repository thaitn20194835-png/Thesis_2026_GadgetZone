import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FiMapPin, FiUser, FiPhone, FiFileText, FiCreditCard,
  FiDollarSign, FiCheck, FiShoppingCart, FiArrowRight, FiShield, FiTruck, FiTag, FiX,
} from 'react-icons/fi';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { orderService } from '../services/orderService';
import { paymentService } from '../services/paymentService';
import { voucherService } from '../services/voucherService';
import { toast } from 'react-toastify';

const Checkout = () => {
  const navigate = useNavigate();
  const { cart, clearCart } = useCart();
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: user?.name || '', phone: user?.phone || '', address: user?.address || '',
    note: '', paymentMethod: 'cod',
  });
  const [voucherInput, setVoucherInput] = useState('');
  const [voucher, setVoucher] = useState(null);
  const [verifying, setVerifying] = useState(false);

  const fmt = (p) => (p || 0).toLocaleString('vi-VN') + 'đ';

  const items = cart?.items || [];
  const subtotal = items.reduce((s, it) => {
    const p = it.product?.salePrice > 0 && it.product.salePrice < it.product.price ? it.product.salePrice : it.product?.price || 0;
    return s + p * it.quantity;
  }, 0);
  const discount = voucher?.discount || 0;
  const total = subtotal - discount;

  const applyVoucher = async () => {
    if (!voucherInput.trim()) return;
    setVerifying(true);
    try {
      const res = await voucherService.verify(voucherInput.trim(), subtotal);
      setVoucher(res.data.data);
      toast.success(`Áp dụng mã ${res.data.data.code} thành công`);
    } catch (err) {
      setVoucher(null);
      toast.error(err.response?.data?.message || 'Mã không hợp lệ');
    } finally { setVerifying(false); }
  };

  const removeVoucher = () => { setVoucher(null); setVoucherInput(''); };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.address) { toast.warning('Vui lòng nhập đầy đủ thông tin'); return; }
    if (items.length === 0) { toast.warning('Giỏ hàng trống'); return; }

    setLoading(true);
    try {
      const orderData = {
        shippingAddress: { name: form.name, phone: form.phone, address: form.address },
        note: form.note,
        paymentMethod: form.paymentMethod,
        voucherCode: voucher?.code,
      };
      const res = await orderService.createOrder(orderData);
      const order = res.data.data || res.data;

      if (form.paymentMethod === 'vnpay') {
        const payRes = await paymentService.createVnpayUrl(order._id);
        const paymentUrl = payRes.data?.data?.paymentUrl;
        if (!paymentUrl) {
          toast.error('Không tạo được liên kết thanh toán VNPay');
          return;
        }
        window.location.href = paymentUrl;
      } else {
        await clearCart();
        toast.success('Đặt hàng thành công!');
        navigate(`/don-hang/${order._id}`);
      }
    } catch (err) {
      toast.error(err.response?.data?.message || 'Đặt hàng thất bại');
    } finally { setLoading(false); }
  };

  const STEPS = [
    { label: 'Giỏ hàng', done: true },
    { label: 'Thanh toán', active: true },
    { label: 'Hoàn tất', upcoming: true },
  ];

  return (
    <div className="bg-[#FAFAFA] min-h-screen">
      <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-8 lg:py-10">
        {/* Steps */}
        <div className="bg-white border border-slate-200 rounded-xl p-5 mb-6">
          <div className="flex items-center justify-center gap-2 sm:gap-4">
            {STEPS.map((s, i) => (
              <div key={i} className="flex items-center gap-2 sm:gap-4">
                <div className="flex items-center gap-2.5">
                  <div className={`w-9 h-9 rounded-full flex items-center justify-center text-[13px] font-bold ${s.done ? 'bg-success text-white' : s.active ? 'bg-[#0B1120] text-white' : 'bg-slate-100 text-slate-400'}`}>
                    {s.done ? <FiCheck /> : i + 1}
                  </div>
                  <span className={`text-[12.5px] font-bold uppercase tracking-wider hidden sm:inline ${s.done ? 'text-success' : s.active ? 'text-[#0B1120]' : 'text-slate-400'}`}>
                    {s.label}
                  </span>
                </div>
                {i < STEPS.length - 1 && <div className={`w-8 sm:w-16 h-0.5 ${s.done ? 'bg-success' : 'bg-slate-200'}`} />}
              </div>
            ))}
          </div>
        </div>

        <span className="gz-eyebrow text-primary">Bước 2 / 3</span>
        <h1 className="font-heading text-[28px] lg:text-[36px] font-extrabold tracking-tight text-[#0B1120] mt-2 mb-8 leading-tight">
          Hoàn tất đơn hàng
        </h1>

        <form onSubmit={handleSubmit} className="grid lg:grid-cols-12 gap-6">
          {/* Form column */}
          <div className="lg:col-span-7 space-y-6">
            {/* Shipping */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 lg:p-7">
              <h2 className="font-heading text-[18px] font-bold text-[#0B1120] flex items-center gap-2 mb-5">
                <FiMapPin className="text-primary" /> Thông tin giao hàng
              </h2>

              <div className="space-y-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-[12px] font-bold text-slate-700 mb-2 uppercase tracking-wide">Họ và tên</label>
                    <div className="relative">
                      <FiUser className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Người nhận"
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                    </div>
                  </div>
                  <div>
                    <label className="block text-[12px] font-bold text-slate-700 mb-2 uppercase tracking-wide">Số điện thoại</label>
                    <div className="relative">
                      <FiPhone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                      <input type="tel" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} placeholder="0901234567"
                        className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-[12px] font-bold text-slate-700 mb-2 uppercase tracking-wide">Địa chỉ giao hàng</label>
                  <div className="relative">
                    <FiMapPin className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                    <input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} placeholder="Số nhà, đường, phường, quận, thành phố"
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                  </div>
                </div>

                <div>
                  <label className="block text-[12px] font-bold text-slate-700 mb-2 uppercase tracking-wide">Ghi chú (tùy chọn)</label>
                  <div className="relative">
                    <FiFileText className="absolute left-4 top-3.5 text-slate-400" />
                    <textarea rows={2} value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="Yêu cầu giao hàng giờ hành chính..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition resize-none" />
                  </div>
                </div>
              </div>
            </div>

            {/* Payment */}
            <div className="bg-white border border-slate-200 rounded-xl p-6 lg:p-7">
              <h2 className="font-heading text-[18px] font-bold text-[#0B1120] flex items-center gap-2 mb-5">
                <FiCreditCard className="text-primary" /> Phương thức thanh toán
              </h2>

              <div className="grid sm:grid-cols-2 gap-3">
                {[
                  { key: 'cod', icon: FiDollarSign, title: 'Thanh toán khi nhận', sub: 'Trả tiền mặt khi nhận hàng' },
                  { key: 'vnpay', icon: FiCreditCard, title: 'VNPay', sub: 'ATM, Visa, Master, QR' },
                ].map((p) => {
                  const Icon = p.icon;
                  const active = form.paymentMethod === p.key;
                  return (
                    <label
                      key={p.key}
                      className={`relative border-2 rounded-xl p-5 cursor-pointer transition ${active ? 'border-[#0B1120] bg-slate-50' : 'border-slate-200 hover:border-slate-300'}`}
                    >
                      <input type="radio" name="paymentMethod" value={p.key} checked={active} onChange={(e) => setForm({ ...form, paymentMethod: e.target.value })} className="sr-only" />
                      {active && (
                        <span className="absolute top-3 right-3 w-5 h-5 rounded-full bg-[#0B1120] text-white flex items-center justify-center">
                          <FiCheck className="text-[11px]" />
                        </span>
                      )}
                      <div className="w-11 h-11 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-[#0B1120]">
                        <Icon className="text-[20px]" />
                      </div>
                      <div className="font-heading text-[14px] font-bold text-[#0B1120] mt-3">{p.title}</div>
                      <div className="text-[11.5px] text-slate-500 mt-0.5">{p.sub}</div>
                    </label>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Summary column */}
          <div className="lg:col-span-5">
            <div className="bg-white border border-slate-200 rounded-xl p-6 sticky top-[100px]">
              <h3 className="font-heading text-[16px] font-bold text-[#0B1120] mb-4">
                Đơn hàng ({items.length} sản phẩm)
              </h3>

              <div className="max-h-[280px] overflow-y-auto -mx-2 px-2 divide-y divide-slate-100">
                {items.map((it) => {
                  const p = it.product;
                  const unit = p?.salePrice && p.salePrice < p.price ? p.salePrice : p?.price || 0;
                  return (
                    <div key={it._id || p?._id} className="flex gap-3 py-3">
                      <div className="w-12 h-12 rounded-lg bg-slate-50 border border-slate-100 overflow-hidden flex-shrink-0">
                        {p?.images?.[0] ? (
                          <img src={p.images[0]} alt={p.name} className="w-full h-full object-cover" />
                        ) : <div className="w-full h-full flex items-center justify-center text-slate-300"><FiShoppingCart className="text-sm" /></div>}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-[12.5px] font-semibold text-[#0B1120] line-clamp-1">{p?.name}</p>
                        <p className="text-[11.5px] text-slate-500">{it.quantity} x {fmt(unit)}</p>
                      </div>
                      <span className="text-[12.5px] font-bold text-[#0B1120] flex-shrink-0">{fmt(unit * it.quantity)}</span>
                    </div>
                  );
                })}
              </div>

              {/* Voucher input */}
              <div className="mt-4 p-3 bg-slate-50 rounded-lg border border-dashed border-slate-300">
                {voucher ? (
                  <div className="flex items-center gap-2">
                    <FiTag className="text-accent" />
                    <div className="flex-1 min-w-0">
                      <div className="text-[12.5px] font-bold text-accent">{voucher.code}</div>
                      <div className="text-[11px] text-slate-500">Tiết kiệm {fmt(voucher.discount)}</div>
                    </div>
                    <button onClick={removeVoucher} className="w-7 h-7 rounded-md hover:bg-slate-200 text-slate-500 flex items-center justify-center transition">
                      <FiX className="text-[13px]" />
                    </button>
                  </div>
                ) : (
                  <div className="flex gap-2">
                    <input
                      value={voucherInput} onChange={(e) => setVoucherInput(e.target.value.toUpperCase())}
                      placeholder="Nhập mã giảm giá"
                      className="flex-1 bg-white border border-slate-200 rounded-md px-3 py-2 text-[12.5px] font-mono outline-none focus:border-[#0B1120]"
                    />
                    <button type="button" onClick={applyVoucher} disabled={verifying || !voucherInput.trim()}
                      className="bg-[#0B1120] hover:bg-primary text-white px-4 rounded-md text-[12px] font-bold transition disabled:opacity-60">
                      {verifying ? '...' : 'ÁP DỤNG'}
                    </button>
                  </div>
                )}
              </div>

              <div className="border-t border-dashed border-slate-200 my-4" />

              <div className="space-y-2 text-[13px]">
                <div className="flex justify-between text-slate-600">
                  <span>Tạm tính</span>
                  <span className="text-[#0B1120] font-semibold">{fmt(subtotal)}</span>
                </div>
                {discount > 0 && (
                  <div className="flex justify-between">
                    <span className="text-slate-600 flex items-center gap-1.5"><FiTag className="text-accent text-[12px]" /> Giảm giá</span>
                    <span className="text-accent font-semibold">-{fmt(discount)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Phí vận chuyển</span>
                  <span className="text-success font-bold">Miễn phí</span>
                </div>
              </div>

              <div className="border-t border-slate-100 my-4" />

              <div className="flex justify-between items-baseline">
                <span className="text-[14px] text-slate-600">Tổng cộng</span>
                <strong className="font-heading text-[26px] font-extrabold text-[#0B1120]">{fmt(total)}</strong>
              </div>

              <button
                type="submit" disabled={loading}
                className="w-full bg-[#0B1120] hover:bg-primary text-white py-4 rounded-lg font-bold text-[14px] mt-5 flex items-center justify-center gap-2 transition group disabled:opacity-50"
              >
                {loading ? 'Đang xử lý...' : (
                  <>
                    Xác nhận đặt hàng
                    <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
                  </>
                )}
              </button>

              <div className="grid grid-cols-2 gap-2 mt-5 pt-5 border-t border-slate-100">
                <div className="flex items-center gap-2 text-[11.5px] text-slate-600">
                  <FiTruck className="text-primary" /> Giao 2 giờ
                </div>
                <div className="flex items-center gap-2 text-[11.5px] text-slate-600">
                  <FiShield className="text-primary" /> Bảo hành 12 tháng
                </div>
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Checkout;
