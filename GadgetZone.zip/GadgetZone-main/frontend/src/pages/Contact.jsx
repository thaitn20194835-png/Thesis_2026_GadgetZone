import { useState } from 'react';
import {
  FiMapPin, FiPhone, FiMail, FiClock, FiSend,
  FiUser, FiAtSign, FiMessageSquare, FiArrowRight, FiFacebook, FiInstagram, FiYoutube,
} from 'react-icons/fi';
import { toast } from 'react-toastify';

const CONTACT_INFO = [
  { icon: FiMapPin, label: 'Trụ sở chính', value: '73 Quang Trung, Hà Đông, Hà Nội', extra: 'Tầng 5, tòa nhà GadgetZone' },
  { icon: FiPhone, label: 'Hotline 24/7', value: '1900 1234', extra: 'Miễn phí cuộc gọi' },
  { icon: FiMail, label: 'Email hỗ trợ', value: 'support@gadgetzone.vn', extra: 'Phản hồi trong 24h' },
  { icon: FiClock, label: 'Giờ làm việc', value: '8:00 - 22:00', extra: 'Thứ 2 - Chủ nhật' },
];

const Contact = () => {
  const [form, setForm] = useState({ name: '', email: '', phone: '', subject: '', message: '' });
  const handle = (k) => (e) => setForm({ ...form, [k]: e.target.value });

  const handleSubmit = (e) => {
    e.preventDefault();
    toast.success('Cảm ơn bạn! Chúng tôi sẽ phản hồi trong 24 giờ.');
    setForm({ name: '', email: '', phone: '', subject: '', message: '' });
  };

  return (
    <div className="bg-[#FAFAFA]">
      {/* Hero */}
      <section className="bg-orange-50 border-b border-slate-200 relative overflow-hidden">
        <div className="absolute -top-40 -left-40 w-[400px] h-[400px] rounded-full bg-accent/15 blur-3xl pointer-events-none" />
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-16 lg:py-20 grid lg:grid-cols-12 gap-10 relative">
          <div className="lg:col-span-7">
            <span className="gz-eyebrow text-accent">Liên hệ</span>
            <h1 className="font-heading text-[40px] lg:text-[64px] font-black tracking-[-0.025em] text-[#0B1120] mt-4 leading-[1]">
              Hãy <span className="text-accent">nói chuyện</span> với chúng tôi.
            </h1>
            <p className="text-slate-600 text-[15.5px] lg:text-[16.5px] mt-6 max-w-[540px] leading-relaxed">
              Có câu hỏi về sản phẩm? Cần tư vấn kỹ thuật? Hay đơn giản chỉ muốn chia sẻ? Đội ngũ GadgetZone luôn sẵn sàng lắng nghe và phản hồi nhanh chóng.
            </p>
          </div>

          <div className="lg:col-span-5">
            <div className="bg-[#0B1120] text-white rounded-2xl p-6 lg:p-8 relative overflow-hidden">
              <div className="absolute -bottom-20 -right-20 w-[300px] h-[300px] rounded-full bg-primary/20 blur-3xl pointer-events-none" />
              <div className="relative">
                <span className="gz-eyebrow text-blue-400">Cần hỗ trợ ngay?</span>
                <h3 className="font-heading text-[24px] font-bold tracking-tight mt-3">Gọi hotline miễn phí</h3>
                <a href="tel:19001234" className="block font-heading text-[32px] font-black tracking-tight mt-2 text-primary">
                  1900 1234
                </a>
                <p className="text-slate-400 text-[13px] mt-1.5">Phục vụ 8:00 - 22:00 hàng ngày</p>

                <div className="flex items-center gap-2 mt-6">
                  <a href="#" className="w-10 h-10 rounded-lg bg-white/5 hover:bg-primary border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition" aria-label="Facebook"><FiFacebook /></a>
                  <a href="#" className="w-10 h-10 rounded-lg bg-white/5 hover:bg-primary border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition" aria-label="Instagram"><FiInstagram /></a>
                  <a href="#" className="w-10 h-10 rounded-lg bg-white/5 hover:bg-primary border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition" aria-label="YouTube"><FiYoutube /></a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Info cards */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 py-12">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {CONTACT_INFO.map((c, i) => {
            const Icon = c.icon;
            return (
              <div key={i} className="bg-white border border-slate-200 rounded-2xl p-6 hover:border-[#0B1120] transition group">
                <div className="w-11 h-11 rounded-xl bg-slate-100 group-hover:bg-[#0B1120] flex items-center justify-center text-[#0B1120] group-hover:text-white transition">
                  <Icon className="text-[18px]" />
                </div>
                <span className="gz-eyebrow text-slate-500 mt-5 block">{c.label}</span>
                <p className="font-heading text-[16px] font-bold text-[#0B1120] mt-1.5 leading-tight">{c.value}</p>
                <p className="text-[12px] text-slate-500 mt-1">{c.extra}</p>
              </div>
            );
          })}
        </div>
      </section>

      {/* Form + Map */}
      <section className="max-w-[1240px] mx-auto px-4 lg:px-6 pb-20 grid lg:grid-cols-12 gap-6">
        <div className="lg:col-span-7 bg-white border border-slate-200 rounded-2xl p-7 lg:p-10">
          <span className="gz-eyebrow text-primary">Gửi tin nhắn</span>
          <h2 className="font-heading text-[26px] lg:text-[32px] font-extrabold tracking-tight text-[#0B1120] mt-2 leading-tight">
            Chúng tôi sẵn sàng lắng nghe
          </h2>
          <p className="text-slate-500 text-[14px] mt-2">Điền thông tin bên dưới — chúng tôi sẽ phản hồi trong 24 giờ.</p>

          <form className="mt-7 space-y-4" onSubmit={handleSubmit}>
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Họ và tên</label>
                <div className="relative">
                  <FiUser className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input value={form.name} onChange={handle('name')} required placeholder="Nguyễn Văn A"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
              </div>
              <div>
                <label className="block text-[12px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Email</label>
                <div className="relative">
                  <FiAtSign className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="email" value={form.email} onChange={handle('email')} required placeholder="email@cuaban.com"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
              </div>
            </div>

            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-[12px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Số điện thoại</label>
                <div className="relative">
                  <FiPhone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="tel" value={form.phone} onChange={handle('phone')} placeholder="0901234567"
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition" />
                </div>
              </div>
              <div>
                <label className="block text-[12px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Chủ đề</label>
                <select value={form.subject} onChange={handle('subject')} required
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition appearance-none cursor-pointer">
                  <option value="">Chọn chủ đề</option>
                  <option value="support">Hỗ trợ kỹ thuật</option>
                  <option value="complaint">Khiếu nại</option>
                  <option value="feedback">Góp ý sản phẩm</option>
                  <option value="cooperation">Hợp tác kinh doanh</option>
                  <option value="other">Khác</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-[12px] font-bold text-slate-700 mb-2 tracking-wide uppercase">Nội dung</label>
              <div className="relative">
                <FiMessageSquare className="absolute left-4 top-3.5 text-slate-400" />
                <textarea
                  rows={5} value={form.message} onChange={handle('message')} required
                  placeholder="Bạn muốn chia sẻ điều gì với chúng tôi?"
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-11 pr-4 py-3 text-[14px] outline-none focus:border-[#0B1120] focus:bg-white transition resize-none"
                />
              </div>
            </div>

            <button
              type="submit"
              className="bg-[#0B1120] hover:bg-primary text-white px-7 py-3.5 rounded-lg font-semibold text-[14px] inline-flex items-center gap-2.5 transition group"
            >
              <FiSend /> Gửi tin nhắn
              <FiArrowRight className="group-hover:translate-x-1 transition-transform" />
            </button>
          </form>
        </div>

        <div className="lg:col-span-5 flex flex-col gap-4">
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden flex-1">
            <iframe
              title="GadgetZone Map"
              src="https://www.google.com/maps?q=73%20Quang%20Trung%2C%20H%C3%A0%20%C4%90%C3%B4ng%2C%20H%C3%A0%20N%E1%BB%99i&output=embed"
              width="100%" height="100%" style={{ border: 0, minHeight: '320px' }}
              allowFullScreen="" loading="lazy" referrerPolicy="no-referrer-when-downgrade"
            />
          </div>

          <div className="bg-[#0B1120] text-white rounded-2xl p-6">
            <span className="gz-eyebrow text-blue-400">Cửa hàng tại</span>
            <h3 className="font-heading text-[20px] font-bold mt-2">Hà Nội</h3>
            <p className="text-slate-400 text-[13px] mt-2 leading-relaxed">
              Ghé thăm cửa hàng để trải nghiệm thực tế sản phẩm, được tư vấn 1-1 bởi chuyên gia và nhận ưu đãi đặc biệt khi mua trực tiếp.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;
