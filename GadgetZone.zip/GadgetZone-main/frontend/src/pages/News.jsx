import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FiCalendar, FiUser, FiArrowRight, FiArrowUpRight, FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import { newsService } from '../services/newsService';

const News = () => {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);

  useEffect(() => {
    const fetchNews = async () => {
      setLoading(true);
      try {
        const res = await newsService.getAll({ page, limit: 9 });
        setArticles(res.data.data || res.data || []);
        setTotalPages(res.data.totalPages || 1);
      } catch { setArticles([]); }
      finally { setLoading(false); }
    };
    fetchNews();
  }, [page]);

  const fmtDate = (d) => new Date(d).toLocaleDateString('vi-VN', { day: '2-digit', month: 'short', year: 'numeric' });

  const featured = articles[0];
  const rest = articles.slice(1);

  return (
    <div className="bg-[#FAFAFA] min-h-screen">
      {/* Hero */}
      <section className="bg-blue-50 border-b border-slate-200 relative overflow-hidden">
        <div className="absolute -top-40 -right-40 w-[400px] h-[400px] rounded-full bg-primary/15 blur-3xl pointer-events-none" />
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-14 lg:py-20 relative">
          <span className="gz-eyebrow text-primary">Tạp chí GadgetZone</span>
          <h1 className="font-heading text-[40px] lg:text-[64px] font-black tracking-[-0.025em] text-[#0B1120] mt-4 leading-[1] max-w-[720px]">
            Tin tức công nghệ <span className="text-primary">mỗi ngày.</span>
          </h1>
          <p className="text-slate-600 text-[15px] lg:text-[16px] mt-5 max-w-[600px] leading-relaxed">
            Cập nhật ra mắt sản phẩm, đánh giá chi tiết, hướng dẫn mua sắm và xu hướng công nghệ — tổng hợp bởi đội ngũ biên tập GadgetZone.
          </p>
        </div>
      </section>

      {loading ? (
        <div className="max-w-[1240px] mx-auto px-4 py-20 text-center text-slate-400 text-sm">Đang tải...</div>
      ) : articles.length === 0 ? (
        <div className="max-w-[1240px] mx-auto px-4 py-20 text-center text-slate-400 text-sm">Chưa có bài viết nào.</div>
      ) : (
        <>
          {/* Featured editorial */}
          {featured && (
            <section className="max-w-[1240px] mx-auto px-4 lg:px-6 py-12">
              <Link
                to={`/tin-tuc/${featured._id || featured.id}`}
                className="grid lg:grid-cols-12 gap-8 group"
              >
                <div className="lg:col-span-7 aspect-[16/10] bg-white border border-slate-200 rounded-2xl overflow-hidden">
                  {featured.image && (
                    <img src={featured.image} alt={featured.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                  )}
                </div>
                <div className="lg:col-span-5 flex flex-col justify-center">
                  <div className="flex items-center gap-2 mb-4">
                    <span className="bg-[#0B1120] text-white text-[10.5px] font-bold tracking-wider px-2 py-1 rounded uppercase">
                      Bài viết nổi bật
                    </span>
                    {featured.tags?.[0] && (
                      <span className="text-[10.5px] tracking-wider uppercase font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded">
                        {featured.tags[0]}
                      </span>
                    )}
                  </div>
                  <h2 className="font-heading text-[26px] lg:text-[32px] font-extrabold tracking-tight text-[#0B1120] leading-[1.15] group-hover:text-primary transition-colors">
                    {featured.title}
                  </h2>
                  <p className="text-slate-600 text-[14.5px] mt-4 leading-relaxed line-clamp-3">
                    {featured.summary}
                  </p>
                  <div className="flex items-center gap-4 mt-6 text-[12.5px] text-slate-500 font-medium">
                    <span className="flex items-center gap-1.5"><FiUser /> {featured.author || 'Admin'}</span>
                    <span className="w-1 h-1 bg-slate-300 rounded-full" />
                    <span className="flex items-center gap-1.5"><FiCalendar /> {fmtDate(featured.createdAt || featured.date)}</span>
                  </div>
                  <div className="inline-flex items-center gap-2 mt-6 text-[14px] font-semibold text-[#0B1120] group-hover:gap-3 transition-all w-max">
                    Đọc bài viết <FiArrowUpRight />
                  </div>
                </div>
              </Link>
            </section>
          )}

          {/* Grid */}
          {rest.length > 0 && (
            <section className="max-w-[1240px] mx-auto px-4 lg:px-6 pb-14 border-t border-slate-200 pt-12">
              <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5 lg:gap-6">
                {rest.map((a) => (
                  <Link
                    key={a._id || a.id}
                    to={`/tin-tuc/${a._id || a.id}`}
                    className="group bg-white border border-slate-200 rounded-2xl overflow-hidden hover:border-[#0B1120] transition"
                  >
                    <div className="aspect-[16/10] overflow-hidden bg-slate-100">
                      {a.image && (
                        <img src={a.image} alt={a.title}
                          loading="lazy"
                          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                      )}
                    </div>
                    <div className="p-5 lg:p-6">
                      <div className="flex items-center gap-2 mb-3 flex-wrap">
                        {a.tags?.slice(0, 2).map((t) => (
                          <span key={t} className="text-[10.5px] tracking-wider uppercase font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                            {t}
                          </span>
                        ))}
                      </div>
                      <h3 className="font-heading text-[17px] font-bold text-[#0B1120] line-clamp-2 leading-tight group-hover:text-primary transition-colors">
                        {a.title}
                      </h3>
                      <p className="text-[13px] text-slate-500 mt-2 line-clamp-2 leading-relaxed">{a.summary}</p>
                      <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100">
                        <span className="text-[11.5px] text-slate-500 font-medium">
                          {fmtDate(a.createdAt || a.date)}
                        </span>
                        <FiArrowRight className="text-slate-400 group-hover:text-[#0B1120] group-hover:translate-x-1 transition" />
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-3 mt-12">
                  <button
                    disabled={page <= 1} onClick={() => setPage(page - 1)}
                    className="flex items-center gap-2 px-5 py-2.5 text-[13px] font-semibold border border-slate-200 rounded-lg hover:border-[#0B1120] disabled:opacity-30 disabled:cursor-not-allowed transition"
                  >
                    <FiChevronLeft /> Trước
                  </button>
                  <span className="text-[13px] text-slate-500 font-medium">Trang {page} / {totalPages}</span>
                  <button
                    disabled={page >= totalPages} onClick={() => setPage(page + 1)}
                    className="flex items-center gap-2 px-5 py-2.5 text-[13px] font-semibold border border-slate-200 rounded-lg hover:border-[#0B1120] disabled:opacity-30 disabled:cursor-not-allowed transition"
                  >
                    Sau <FiChevronRight />
                  </button>
                </div>
              )}
            </section>
          )}
        </>
      )}
    </div>
  );
};

export default News;
