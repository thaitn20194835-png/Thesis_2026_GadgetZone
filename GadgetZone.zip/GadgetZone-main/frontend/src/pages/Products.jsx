import { useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { FiFilter, FiChevronLeft, FiChevronRight, FiX, FiCheck } from 'react-icons/fi';
import { productService } from '../services/productService';
import { categoryService } from '../services/categoryService';
import { brandService } from '../services/brandService';
import ProductCard from '../components/common/ProductCard';

const Products = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [brands, setBrands] = useState([]);
  const [loading, setLoading] = useState(true);
  const [totalPages, setTotalPages] = useState(1);
  const [showFilter, setShowFilter] = useState(false);

  const currentPage = parseInt(searchParams.get('page')) || 1;
  const selectedCategory = searchParams.get('category') || '';
  const selectedBrand = searchParams.get('brand') || '';
  const searchQuery = searchParams.get('search') || '';
  const sortBy = searchParams.get('sort') || 'newest';
  const minPrice = searchParams.get('minPrice') || '';
  const maxPrice = searchParams.get('maxPrice') || '';

  useEffect(() => {
    const fetchFilters = async () => {
      try {
        const [catRes, brandRes] = await Promise.all([categoryService.getAll(), brandService.getAll()]);
        setCategories(catRes.data.data || catRes.data || []);
        setBrands(brandRes.data.data || brandRes.data || []);
      } catch (e) { console.error(e); }
    };
    fetchFilters();
  }, []);

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      try {
        const params = { page: currentPage, limit: 12 };
        if (selectedCategory) params.category = selectedCategory;
        if (selectedBrand) params.brand = selectedBrand;
        if (searchQuery) params.search = searchQuery;
        if (minPrice) params.minPrice = minPrice;
        if (maxPrice) params.maxPrice = maxPrice;
        if (sortBy) params.sort = sortBy;
        const res = await productService.getAll(params);
        setProducts(res.data.data || res.data || []);
        setTotalPages(res.data.totalPages || 1);
      } catch (e) { console.error(e); } finally { setLoading(false); }
    };
    fetchProducts();
  }, [currentPage, selectedCategory, selectedBrand, searchQuery, sortBy, minPrice, maxPrice]);

  const updateParams = (key, value) => {
    const newParams = new URLSearchParams(searchParams);
    if (value) newParams.set(key, value); else newParams.delete(key);
    if (key !== 'page') newParams.set('page', '1');
    setSearchParams(newParams);
  };

  const handlePriceFilter = (e) => {
    e.preventDefault();
    const f = new FormData(e.target);
    const newParams = new URLSearchParams(searchParams);
    const min = f.get('minPrice'); const max = f.get('maxPrice');
    if (min) newParams.set('minPrice', min); else newParams.delete('minPrice');
    if (max) newParams.set('maxPrice', max); else newParams.delete('maxPrice');
    newParams.set('page', '1');
    setSearchParams(newParams);
  };

  const clearAllFilters = () => setSearchParams({});
  const hasActiveFilters = selectedCategory || selectedBrand || minPrice || maxPrice;

  const PRICE_PRESETS = [
    { label: 'Dưới 5 triệu', min: 0, max: 5000000 },
    { label: '5 - 15 triệu', min: 5000000, max: 15000000 },
    { label: '15 - 30 triệu', min: 15000000, max: 30000000 },
    { label: 'Trên 30 triệu', min: 30000000, max: '' },
  ];

  return (
    <div className="bg-[#FAFAFA] min-h-screen">
      {/* Page Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-8 lg:py-10">
          <span className="gz-eyebrow text-primary">Cửa hàng</span>
          <h1 className="font-heading text-[28px] lg:text-[40px] font-extrabold tracking-tight text-[#0B1120] mt-2 leading-tight">
            {searchQuery ? `Kết quả: "${searchQuery}"` : 'Tất cả sản phẩm'}
          </h1>
          <p className="text-slate-500 text-[14px] mt-2">
            {loading ? 'Đang tải...' : `${products.length} sản phẩm`}
            {hasActiveFilters && ' · đã áp dụng bộ lọc'}
          </p>
        </div>
      </div>

      <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-8 flex gap-6 lg:flex-row flex-col">
        {/* Mobile filter toggle */}
        <button
          className="lg:hidden flex items-center justify-center gap-2 bg-white border border-slate-200 rounded-lg px-4 py-3 text-sm font-semibold text-slate-700 hover:border-[#0B1120] transition"
          onClick={() => setShowFilter(!showFilter)}
        >
          {showFilter ? <FiX /> : <FiFilter />}
          {showFilter ? 'Đóng bộ lọc' : 'Hiển thị bộ lọc'}
        </button>

        {/* Sidebar */}
        <aside className={`lg:w-[270px] flex-shrink-0 ${showFilter ? 'block' : 'hidden'} lg:block`}>
          <div className="bg-white border border-slate-200 rounded-xl p-5 sticky top-[100px]">
            {hasActiveFilters && (
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-100">
                <span className="text-[12.5px] font-semibold text-slate-500">Bộ lọc đang áp dụng</span>
                <button
                  className="text-[12px] font-semibold text-accent hover:underline"
                  onClick={clearAllFilters}
                >
                  Xóa tất cả
                </button>
              </div>
            )}

            {/* Category */}
            <div className="pb-5 mb-5 border-b border-slate-100">
              <h3 className="gz-eyebrow text-[#0B1120] mb-3.5">Danh mục</h3>
              <ul className="space-y-1">
                <li>
                  <button
                    className={`flex items-center justify-between w-full text-left text-[13.5px] py-1.5 px-2 rounded-md transition ${!selectedCategory ? 'text-[#0B1120] font-bold bg-slate-100' : 'text-slate-600 hover:text-[#0B1120]'}`}
                    onClick={() => updateParams('category', '')}
                  >
                    <span>Tất cả</span>
                    {!selectedCategory && <FiCheck className="text-primary text-xs" />}
                  </button>
                </li>
                {categories.map((cat) => (
                  <li key={cat._id}>
                    <button
                      className={`flex items-center justify-between w-full text-left text-[13.5px] py-1.5 px-2 rounded-md transition ${selectedCategory === cat._id ? 'text-[#0B1120] font-bold bg-slate-100' : 'text-slate-600 hover:text-[#0B1120]'}`}
                      onClick={() => updateParams('category', cat._id)}
                    >
                      <span>{cat.name}</span>
                      {selectedCategory === cat._id && <FiCheck className="text-primary text-xs" />}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Brand */}
            <div className="pb-5 mb-5 border-b border-slate-100">
              <h3 className="gz-eyebrow text-[#0B1120] mb-3.5">Thương hiệu</h3>
              <ul className="space-y-1 max-h-[220px] overflow-y-auto">
                <li>
                  <button
                    className={`flex items-center justify-between w-full text-left text-[13.5px] py-1.5 px-2 rounded-md transition ${!selectedBrand ? 'text-[#0B1120] font-bold bg-slate-100' : 'text-slate-600 hover:text-[#0B1120]'}`}
                    onClick={() => updateParams('brand', '')}
                  >
                    <span>Tất cả</span>
                    {!selectedBrand && <FiCheck className="text-primary text-xs" />}
                  </button>
                </li>
                {brands.map((b) => (
                  <li key={b._id}>
                    <button
                      className={`flex items-center justify-between w-full text-left text-[13.5px] py-1.5 px-2 rounded-md transition ${selectedBrand === b._id ? 'text-[#0B1120] font-bold bg-slate-100' : 'text-slate-600 hover:text-[#0B1120]'}`}
                      onClick={() => updateParams('brand', b._id)}
                    >
                      <span>{b.name}</span>
                      {selectedBrand === b._id && <FiCheck className="text-primary text-xs" />}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Price presets */}
            <div className="pb-5 mb-5 border-b border-slate-100">
              <h3 className="gz-eyebrow text-[#0B1120] mb-3.5">Khoảng giá</h3>
              <div className="grid grid-cols-2 gap-2 mb-4">
                {PRICE_PRESETS.map((p) => {
                  const active = String(minPrice) === String(p.min) && String(maxPrice) === String(p.max);
                  return (
                    <button
                      key={p.label}
                      onClick={() => {
                        const np = new URLSearchParams(searchParams);
                        np.set('minPrice', String(p.min));
                        if (p.max) np.set('maxPrice', String(p.max)); else np.delete('maxPrice');
                        np.set('page', '1');
                        setSearchParams(np);
                      }}
                      className={`text-[12px] py-2 px-2 rounded-md border transition ${active ? 'border-[#0B1120] bg-[#0B1120] text-white font-bold' : 'border-slate-200 text-slate-600 hover:border-[#0B1120]'}`}
                    >
                      {p.label}
                    </button>
                  );
                })}
              </div>

              <form className="space-y-2" onSubmit={handlePriceFilter}>
                <div className="flex gap-2">
                  <input
                    type="number" name="minPrice" placeholder="Từ" defaultValue={minPrice}
                    className="w-full border border-slate-200 rounded-md px-3 py-2 text-[12.5px] outline-none focus:border-[#0B1120] transition"
                  />
                  <input
                    type="number" name="maxPrice" placeholder="Đến" defaultValue={maxPrice}
                    className="w-full border border-slate-200 rounded-md px-3 py-2 text-[12.5px] outline-none focus:border-[#0B1120] transition"
                  />
                </div>
                <button type="submit" className="w-full bg-[#0B1120] hover:bg-primary text-white text-[13px] font-semibold py-2 rounded-md transition">
                  Áp dụng
                </button>
              </form>
            </div>
          </div>
        </aside>

        {/* Content */}
        <main className="flex-1 min-w-0">
          {/* Sort bar */}
          <div className="flex items-center justify-between mb-5 bg-white border border-slate-200 rounded-xl px-4 py-3">
            <span className="text-[13px] text-slate-500 font-medium">
              {loading ? 'Đang tải...' : `${products.length} sản phẩm`}
            </span>
            <div className="flex items-center gap-2">
              <span className="text-[12px] text-slate-400 hidden sm:inline">Sắp xếp:</span>
              <select
                value={sortBy}
                onChange={(e) => updateParams('sort', e.target.value)}
                className="border border-slate-200 rounded-md px-3 py-1.5 text-[13px] font-medium outline-none focus:border-[#0B1120] transition cursor-pointer"
              >
                <option value="newest">Mới nhất</option>
                <option value="price_asc">Giá tăng dần</option>
                <option value="price_desc">Giá giảm dần</option>
                <option value="rating">Đánh giá cao</option>
              </select>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-white border border-slate-200 rounded-xl overflow-hidden animate-pulse">
                  <div className="aspect-square bg-slate-100" />
                  <div className="p-4 space-y-2">
                    <div className="h-3 bg-slate-100 rounded w-1/3" />
                    <div className="h-4 bg-slate-100 rounded w-full" />
                    <div className="h-5 bg-slate-100 rounded w-1/2 mt-3" />
                  </div>
                </div>
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-xl py-20 text-center">
              <div className="text-slate-300 text-5xl mb-4">¯\_(ツ)_/¯</div>
              <p className="font-heading font-bold text-lg text-[#0B1120]">Không tìm thấy sản phẩm</p>
              <p className="text-slate-500 text-[13.5px] mt-2">Thử thay đổi bộ lọc hoặc từ khóa tìm kiếm.</p>
              <button
                onClick={clearAllFilters}
                className="mt-5 inline-flex items-center gap-2 bg-[#0B1120] text-white px-5 py-2.5 rounded-lg font-semibold text-[13px] hover:bg-primary transition"
              >
                Xóa bộ lọc
              </button>
            </div>
          ) : (
            <>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 lg:gap-5">
                {products.map((p) => <ProductCard key={p._id} product={p} />)}
              </div>

              {totalPages > 1 && (
                <div className="flex items-center justify-center gap-1.5 mt-10">
                  <button
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 transition disabled:opacity-30 disabled:cursor-not-allowed"
                    disabled={currentPage <= 1}
                    onClick={() => updateParams('page', String(currentPage - 1))}
                  >
                    <FiChevronLeft />
                  </button>
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
                    <button
                      key={p}
                      onClick={() => updateParams('page', String(p))}
                      className={`w-10 h-10 rounded-lg text-[13.5px] font-bold transition ${p === currentPage ? 'bg-[#0B1120] text-white' : 'text-slate-600 hover:bg-slate-100'}`}
                    >
                      {p}
                    </button>
                  ))}
                  <button
                    className="w-10 h-10 rounded-lg flex items-center justify-center text-slate-500 hover:bg-slate-100 transition disabled:opacity-30 disabled:cursor-not-allowed"
                    disabled={currentPage >= totalPages}
                    onClick={() => updateParams('page', String(currentPage + 1))}
                  >
                    <FiChevronRight />
                  </button>
                </div>
              )}
            </>
          )}
        </main>
      </div>
    </div>
  );
};

export default Products;
