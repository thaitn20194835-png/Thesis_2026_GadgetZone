import { useState, useRef, useEffect } from 'react';
import { FiMessageCircle, FiX, FiSend, FiCpu, FiUser } from 'react-icons/fi';
import { chatbotService } from '../../services/chatbotService';

const QUICK = [
  'Gợi ý điện thoại dưới 20 triệu',
  'iPhone 15 Pro Max có gì hot?',
  'Laptop nào phù hợp sinh viên?',
];

const ChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState([
    { from: 'bot', text: 'Xin chào! Tôi là Zen — trợ lý AI của GadgetZone. Tôi có thể giúp bạn tư vấn sản phẩm phù hợp nhất.' },
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const send = async (text) => {
    const t = (text || input).trim();
    if (!t || loading) return;
    setMessages((p) => [...p, { from: 'user', text: t }]);
    setInput('');
    setLoading(true);
    try {
      const res = await chatbotService.sendMessage(t);
      const reply = res.data.data?.reply || res.data.reply || res.data.message || 'Xin lỗi, tôi chưa hiểu câu hỏi.';
      setMessages((p) => [...p, { from: 'bot', text: reply }]);
    } catch {
      setMessages((p) => [...p, { from: 'bot', text: 'Đã có lỗi xảy ra, bạn thử lại sau nhé.' }]);
    } finally { setLoading(false); }
  };

  return (
    <>
      {isOpen && (
        <div className="fixed bottom-24 right-4 sm:right-6 w-[calc(100%-32px)] sm:w-[380px] max-h-[560px] bg-white rounded-2xl border border-slate-200 shadow-2xl flex flex-col z-50 overflow-hidden gz-fadein">
          {/* Header */}
          <div className="bg-[#0B1120] text-white px-5 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-primary flex items-center justify-center">
                <FiCpu className="text-[15px]" />
              </div>
              <div>
                <div className="font-heading font-bold text-[14px] leading-tight">Trợ lý Zen</div>
                <div className="text-[10.5px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-success animate-pulse" /> Đang trực tuyến
                </div>
              </div>
            </div>
            <button onClick={() => setIsOpen(false)} className="w-8 h-8 rounded-lg bg-white/10 hover:bg-white/20 flex items-center justify-center transition">
              <FiX />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 flex flex-col gap-3 bg-slate-50">
            {messages.map((m, i) => (
              <div key={i} className={`flex gap-2 ${m.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                {m.from === 'bot' && (
                  <div className="w-7 h-7 rounded-full bg-[#0B1120] text-white flex items-center justify-center flex-shrink-0">
                    <FiCpu className="text-[11px]" />
                  </div>
                )}
                <div className={`px-3.5 py-2.5 text-[13px] leading-relaxed max-w-[78%] ${
                  m.from === 'user'
                    ? 'bg-[#0B1120] text-white rounded-2xl rounded-tr-sm'
                    : 'bg-white border border-slate-200 text-slate-700 rounded-2xl rounded-tl-sm'
                }`}>
                  {m.text}
                </div>
                {m.from === 'user' && (
                  <div className="w-7 h-7 rounded-full bg-primary text-white flex items-center justify-center flex-shrink-0">
                    <FiUser className="text-[11px]" />
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="flex gap-2">
                <div className="w-7 h-7 rounded-full bg-[#0B1120] text-white flex items-center justify-center"><FiCpu className="text-[11px]" /></div>
                <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-sm px-4 py-3 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce" />
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce [animation-delay:.1s]" />
                  <span className="w-1.5 h-1.5 rounded-full bg-slate-400 animate-bounce [animation-delay:.2s]" />
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          {/* Quick prompts */}
          {messages.length <= 1 && (
            <div className="px-4 py-2.5 bg-slate-50 border-t border-slate-200 flex flex-wrap gap-1.5">
              {QUICK.map((q) => (
                <button
                  key={q} onClick={() => send(q)}
                  className="text-[11.5px] bg-white border border-slate-200 hover:border-[#0B1120] text-slate-600 hover:text-[#0B1120] rounded-full px-3 py-1.5 transition"
                >
                  {q}
                </button>
              ))}
            </div>
          )}

          {/* Input */}
          <div className="border-t border-slate-200 px-3 py-2.5 flex items-center gap-2 bg-white">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && !e.shiftKey && (e.preventDefault(), send())}
              placeholder="Nhập câu hỏi..."
              className="flex-1 px-3 py-2 text-[13.5px] outline-none placeholder:text-slate-400 bg-transparent"
            />
            <button
              onClick={() => send()} disabled={loading || !input.trim()}
              className="w-9 h-9 bg-[#0B1120] hover:bg-primary text-white rounded-lg flex items-center justify-center transition disabled:opacity-40"
            >
              <FiSend className="text-[14px]" />
            </button>
          </div>
        </div>
      )}

      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-6 right-6 w-14 h-14 bg-[#0B1120] text-white rounded-full flex items-center justify-center hover:bg-primary transition z-50"
        style={{ boxShadow: '0 10px 32px -8px rgba(15,23,42,0.4)' }}
        aria-label="Mở chat"
      >
        {isOpen ? <FiX className="text-xl" /> : <FiMessageCircle className="text-xl" />}
        {!isOpen && (
          <span className="absolute -top-1 -right-1 w-3.5 h-3.5 bg-accent rounded-full ring-2 ring-white animate-pulse" />
        )}
      </button>
    </>
  );
};

export default ChatWidget;
