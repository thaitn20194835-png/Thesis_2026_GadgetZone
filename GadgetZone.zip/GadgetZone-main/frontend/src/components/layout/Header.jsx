import { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  FiShoppingCart, FiUser, FiSearch, FiMenu, FiX, FiLogOut,
  FiPackage, FiSettings, FiGrid, FiPhone, FiChevronDown,
  FiSmartphone, FiMonitor, FiTablet, FiWatch, FiHeadphones, FiZap,
} from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';

const CATEGORIES = [
  { name: 'Điện thoại', icon: FiSmartphone },
  { name: 'Laptop', icon: FiMonitor },
  { name: 'Tablet', icon: FiTablet },
  { name: 'Đồng hồ thông minh', icon: FiWatch },
  { name: 'Âm thanh', icon: FiHeadphones },
  { name: 'Phụ kiện', icon: FiZap },
];

const MARQUEE_ITEMS = [
  'Miễn phí giao hàng đơn từ 500.000đ',
  'Trả góp 0% qua thẻ tín dụng',
  'Bảo hành chính hãng 12 tháng',
  'Đổi trả miễn phí trong 30 ngày',
  'Hotline tư vấn 24/7: 1900 1234',
];

const Header = () => {
  const { user, logout } = useAuth();
  const { cartCount } = useCart();
  const navigate = useNavigate();

  const [searchTerm, setSearchTerm] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [catOpen, setCatOpen] = useState(false);
  const userRef = useRef(null);
  const catRef = useRef(null);

  useEffect(() => {
    const onClick = (e) => {
      if (userRef.current && !userRef.current.contains(e.target)) setUserMenuOpen(false);
      if (catRef.current && !catRef.current.contains(e.target)) setCatOpen(false);
    };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      navigate(`/san-pham?search=${encodeURIComponent(searchTerm.trim())}`);
      setSearchTerm('');
      setMenuOpen(false);
    }
  };

  const handleLogout = () => {
    logout();
    setUserMenuOpen(false);
    setMenuOpen(false);
    navigate('/');
  };

  return (
    <header className="relative z-50">
      {/* ===== Marquee announcement strip ===== */}
      <div className="hidden md:block bg-[#0B1120] text-slate-300 overflow-hidden h-9">
        <div className="flex items-center h-full whitespace-nowrap gz-marquee w-max">
          {[...MARQUEE_ITEMS, ...MARQUEE_ITEMS, ...MARQUEE_ITEMS].map((t, i) => (
            <span key={i} className="text-[12px] font-medium tracking-wide px-8 flex items-center gap-2">
              <span className="w-1 h-1 rounded-full bg-accent" />
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* ===== Main bar ===== */}
      <div className="bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 h-[68px] flex items-center gap-5 lg:gap-8">
          {/* Logo */}
          <Link to="/" className="flex-shrink-0 flex items-center gap-2 group">
            <div className="w-9 h-9 bg-[#0B1120] rounded-lg flex items-center justify-center group-hover:bg-primary transition">
              <span className="font-heading font-black text-white text-[15px] tracking-tighter">GZ</span>
            </div>
            <span className="font-heading font-extrabold text-[19px] tracking-tight text-[#0B1120] hidden sm:inline">
              Gadget<span className="text-primary">Zone</span>
            </span>
          </Link>

          {/* Categories button (desktop) */}
          <div className="hidden lg:block relative" ref={catRef}>
            <button
              onClick={() => setCatOpen(!catOpen)}
              className="flex items-center gap-2 px-3.5 py-2.5 text-[13.5px] font-semibold text-slate-700 rounded-md border border-slate-200 hover:border-slate-300 hover:bg-slate-50 transition"
            >
              <FiGrid />
              <span>Danh mục</span>
              <FiChevronDown className={`text-xs transition-transform ${catOpen ? 'rotate-180' : ''}`} />
            </button>
            {catOpen && (
              <div className="absolute top-full left-0 mt-2 w-[280px] bg-white border border-slate-200 rounded-xl shadow-lg p-2 gz-fadein">
                {CATEGORIES.map((c) => {
                  const Icon = c.icon;
                  return (
                    <Link
                      key={c.name}
                      to={`/san-pham?search=${encodeURIComponent(c.name)}`}
                      className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-[13.5px] text-slate-700 hover:bg-primary-light hover:text-primary transition"
                      onClick={() => setCatOpen(false)}
                    >
                      <span className="w-8 h-8 rounded-md bg-slate-100 flex items-center justify-center text-slate-600">
                        <Icon />
                      </span>
                      <span className="font-medium">{c.name}</span>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>

          {/* Search */}
          <form
            onSubmit={handleSearch}
            className="hidden md:flex flex-1 max-w-[520px] h-11 bg-slate-100 rounded-lg overflow-hidden focus-within:bg-white focus-within:ring-2 focus-within:ring-primary/15 focus-within:border-primary border border-transparent transition"
          >
            <div className="flex items-center px-4 text-slate-400">
              <FiSearch />
            </div>
            <input
              type="text"
              className="flex-1 bg-transparent text-[14px] outline-none placeholder:text-slate-400"
              placeholder="iPhone 15 Pro Max, MacBook M3, AirPods..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
            <button
              type="submit"
              className="bg-[#0B1120] hover:bg-primary text-white px-5 text-[13px] font-semibold tracking-wide transition"
            >
              Tìm
            </button>
          </form>

          {/* Right actions (desktop) */}
          <div className="hidden md:flex items-center gap-1 ml-auto">
            <Link to="/tin-tuc" className="hidden lg:block px-3 py-2 text-[13.5px] font-medium text-slate-700 hover:text-primary rounded-md transition">Tin tức</Link>
            <Link to="/gioi-thieu" className="hidden lg:block px-3 py-2 text-[13.5px] font-medium text-slate-700 hover:text-primary rounded-md transition">Giới thiệu</Link>

            <a
              href="tel:19001234"
              className="hidden xl:flex items-center gap-2 px-3 py-2 text-slate-700 hover:text-primary rounded-md transition"
              title="Hotline"
            >
              <FiPhone />
              <span className="text-[13px] font-semibold">1900 1234</span>
            </a>

            {user ? (
              <>
                <Link to="/gio-hang" className="relative p-2.5 ml-1 text-slate-700 hover:text-primary transition rounded-md hover:bg-slate-100">
                  <FiShoppingCart className="text-[19px]" />
                  {cartCount > 0 && (
                    <span className="absolute top-0.5 right-0.5 bg-accent text-white text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center ring-2 ring-white">
                      {cartCount}
                    </span>
                  )}
                </Link>

                <div className="relative" ref={userRef}>
                  <button
                    className="flex items-center gap-2 pl-2 pr-2.5 py-1.5 rounded-md hover:bg-slate-100 transition"
                    onClick={() => setUserMenuOpen(!userMenuOpen)}
                  >
                    <span className="w-8 h-8 rounded-full bg-primary text-white text-[12px] font-bold flex items-center justify-center">
                      {user.name?.charAt(0)?.toUpperCase() || 'U'}
                    </span>
                    <span className="text-[13px] font-medium text-slate-700 max-w-[110px] truncate">{user.name}</span>
                    <FiChevronDown className={`text-xs text-slate-400 transition-transform ${userMenuOpen ? 'rotate-180' : ''}`} />
                  </button>
                  {userMenuOpen && (
                    <div className="absolute top-full right-0 mt-2 bg-white border border-slate-200 rounded-xl shadow-lg min-w-[210px] py-1.5 z-50 gz-fadein">
                      {user.role === 'admin' && (
                        <Link to="/admin" onClick={() => setUserMenuOpen(false)} className="px-4 py-2.5 text-[13.5px] flex items-center gap-2.5 hover:bg-slate-50 hover:text-primary transition">
                          <FiGrid /> Quản trị
                        </Link>
                      )}
                      <Link to="/don-hang" onClick={() => setUserMenuOpen(false)} className="px-4 py-2.5 text-[13.5px] flex items-center gap-2.5 hover:bg-slate-50 hover:text-primary transition">
                        <FiPackage /> Đơn hàng
                      </Link>
                      <Link to="/tai-khoan" onClick={() => setUserMenuOpen(false)} className="px-4 py-2.5 text-[13.5px] flex items-center gap-2.5 hover:bg-slate-50 hover:text-primary transition">
                        <FiSettings /> Tài khoản
                      </Link>
                      <div className="border-t border-slate-100 my-1.5" />
                      <button onClick={handleLogout} className="w-full text-left px-4 py-2.5 text-[13.5px] flex items-center gap-2.5 text-red-500 hover:bg-red-50 transition">
                        <FiLogOut /> Đăng xuất
                      </button>
                    </div>
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-2 ml-1">
                <Link to="/dang-nhap" className="px-3.5 py-2 text-[13.5px] font-medium text-slate-700 hover:text-primary rounded-md transition">
                  Đăng nhập
                </Link>
                <Link to="/dang-ky" className="px-4 py-2 text-[13.5px] font-semibold text-white bg-[#0B1120] hover:bg-primary rounded-md transition">
                  Đăng ký
                </Link>
              </div>
            )}
          </div>

          {/* Mobile actions */}
          <div className="md:hidden flex items-center gap-2 ml-auto">
            {user && (
              <Link to="/gio-hang" className="relative p-2 text-slate-700">
                <FiShoppingCart className="text-xl" />
                {cartCount > 0 && (
                  <span className="absolute -top-0.5 -right-0.5 bg-accent text-white text-[10px] font-bold min-w-[16px] h-4 rounded-full flex items-center justify-center">{cartCount}</span>
                )}
              </Link>
            )}
            <button onClick={() => setMenuOpen(!menuOpen)} aria-label="Menu" className="p-2 text-slate-700">
              {menuOpen ? <FiX className="text-xl" /> : <FiMenu className="text-xl" />}
            </button>
          </div>
        </div>
      </div>

      {/* ===== Mobile Menu ===== */}
      {menuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 py-4 gz-fadein">
          <form onSubmit={handleSearch} className="flex items-center bg-slate-100 rounded-lg overflow-hidden mb-4 h-11">
            <div className="px-3 text-slate-400"><FiSearch /></div>
            <input
              type="text" placeholder="Tìm sản phẩm..."
              value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 bg-transparent px-1 text-sm outline-none"
            />
            <button type="submit" className="bg-[#0B1120] text-white px-5 h-full text-[13px] font-semibold">Tìm</button>
          </form>

          <p className="gz-eyebrow mb-2 px-1">Danh mục</p>
          <div className="grid grid-cols-2 gap-2 mb-4">
            {CATEGORIES.map((c) => {
              const Icon = c.icon;
              return (
                <Link
                  key={c.name}
                  to={`/san-pham?search=${encodeURIComponent(c.name)}`}
                  onClick={() => setMenuOpen(false)}
                  className="flex items-center gap-2.5 px-3 py-2.5 rounded-lg border border-slate-200 text-[13px] text-slate-700 hover:border-primary hover:text-primary transition"
                >
                  <Icon className="text-base" />
                  <span className="font-medium">{c.name}</span>
                </Link>
              );
            })}
          </div>

          <nav className="flex flex-col border-t border-slate-100 pt-3">
            <Link to="/san-pham" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm font-medium text-slate-700 rounded-md hover:bg-slate-100">Tất cả sản phẩm</Link>
            <Link to="/tin-tuc" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm font-medium text-slate-700 rounded-md hover:bg-slate-100">Tin tức</Link>
            <Link to="/gioi-thieu" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm font-medium text-slate-700 rounded-md hover:bg-slate-100">Giới thiệu</Link>
            <Link to="/lien-he" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm font-medium text-slate-700 rounded-md hover:bg-slate-100">Liên hệ</Link>
          </nav>

          <div className="border-t border-slate-100 my-3" />

          {user ? (
            <div className="flex flex-col">
              {user.role === 'admin' && (
                <Link to="/admin" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm font-medium text-slate-700 rounded-md hover:bg-slate-100 flex items-center gap-2"><FiGrid /> Quản trị</Link>
              )}
              <Link to="/don-hang" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm font-medium text-slate-700 rounded-md hover:bg-slate-100 flex items-center gap-2"><FiPackage /> Đơn hàng</Link>
              <Link to="/tai-khoan" onClick={() => setMenuOpen(false)} className="px-3 py-2.5 text-sm font-medium text-slate-700 rounded-md hover:bg-slate-100 flex items-center gap-2"><FiSettings /> Tài khoản</Link>
              <button onClick={handleLogout} className="px-3 py-2.5 text-sm font-medium text-red-500 rounded-md hover:bg-red-50 flex items-center gap-2"><FiLogOut /> Đăng xuất</button>
            </div>
          ) : (
            <div className="flex gap-2">
              <Link to="/dang-nhap" onClick={() => setMenuOpen(false)} className="flex-1 text-center px-4 py-2.5 text-sm font-medium text-slate-700 border border-slate-200 rounded-md">Đăng nhập</Link>
              <Link to="/dang-ky" onClick={() => setMenuOpen(false)} className="flex-1 text-center px-4 py-2.5 text-sm font-semibold text-white bg-[#0B1120] rounded-md">Đăng ký</Link>
            </div>
          )}
        </div>
      )}
    </header>
  );
};

export default Header;
