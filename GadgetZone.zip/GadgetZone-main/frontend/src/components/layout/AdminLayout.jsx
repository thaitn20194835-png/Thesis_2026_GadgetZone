import { useState } from 'react';
import { NavLink, Outlet, Navigate, Link } from 'react-router-dom';
import {
  FiGrid, FiBox, FiTag, FiLayers, FiShoppingBag, FiUsers, FiFileText,
  FiArrowLeft, FiBell, FiSearch, FiLogOut, FiMenu, FiX,
  FiStar, FiGift, FiTruck, FiMessageCircle,
} from 'react-icons/fi';
import { useAuth } from '../../context/AuthContext';

const NAV_GROUPS = [
  {
    label: 'Tổng quan',
    items: [
      { to: '/admin', icon: FiGrid, label: 'Dashboard', end: true, accent: 'text-primary', dot: 'bg-primary' },
    ],
  },
  {
    label: 'Catalog',
    items: [
      { to: '/admin/san-pham', icon: FiBox, label: 'Sản phẩm', accent: 'text-blue-400', dot: 'bg-blue-400' },
      { to: '/admin/danh-muc', icon: FiLayers, label: 'Danh mục', accent: 'text-emerald-400', dot: 'bg-emerald-400' },
      { to: '/admin/thuong-hieu', icon: FiTag, label: 'Thương hiệu', accent: 'text-purple-400', dot: 'bg-purple-400' },
      { to: '/admin/ncc', icon: FiTruck, label: 'Nhà cung cấp', accent: 'text-orange-400', dot: 'bg-orange-400' },
    ],
  },
  {
    label: 'Bán hàng',
    items: [
      { to: '/admin/don-hang', icon: FiShoppingBag, label: 'Đơn hàng', accent: 'text-accent', dot: 'bg-accent' },
      { to: '/admin/voucher', icon: FiGift, label: 'Voucher', accent: 'text-rose-400', dot: 'bg-rose-400' },
      { to: '/admin/danh-gia', icon: FiStar, label: 'Đánh giá', accent: 'text-amber-400', dot: 'bg-amber-400' },
    ],
  },
  {
    label: 'Nội dung',
    items: [
      { to: '/admin/tin-tuc', icon: FiFileText, label: 'Tin tức', accent: 'text-cyan-400', dot: 'bg-cyan-400' },
      { to: '/admin/binh-luan', icon: FiMessageCircle, label: 'Bình luận', accent: 'text-teal-400', dot: 'bg-teal-400' },
    ],
  },
  {
    label: 'Hệ thống',
    items: [
      { to: '/admin/nguoi-dung', icon: FiUsers, label: 'Người dùng', accent: 'text-pink-400', dot: 'bg-pink-400' },
    ],
  },
];

const AdminLayout = () => {
  const { user, loading, logout } = useAuth();
  const [mobileOpen, setMobileOpen] = useState(false);

  if (loading) return <div className="py-10 text-center text-slate-500">Đang tải...</div>;
  if (!user || user.role !== 'admin') return <Navigate to="/" />;

  const Sidebar = (
    <aside className="w-[260px] bg-[#0B1120] text-white flex-shrink-0 flex flex-col h-screen sticky top-0">
      {/* Brand */}
      <div className="px-5 py-5 border-b border-white/[0.06] flex items-center gap-2.5">
        <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
          <span className="font-heading font-black text-white text-[15px] tracking-tighter">GZ</span>
        </div>
        <div>
          <div className="font-heading font-extrabold text-[15px] tracking-tight leading-tight">Gadget<span className="text-primary">Zone</span></div>
          <div className="text-[10.5px] text-slate-500 uppercase tracking-wider font-bold">Admin Panel</div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 overflow-y-auto">
        {NAV_GROUPS.map((group) => (
          <div key={group.label} className="mb-5">
            <p className="text-[10.5px] uppercase tracking-[0.18em] font-bold text-slate-600 px-3 mb-2">{group.label}</p>
            <div className="flex flex-col gap-1">
              {group.items.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.end}
                    onClick={() => setMobileOpen(false)}
                    className={({ isActive }) =>
                      `relative flex items-center gap-3 px-3 py-2.5 rounded-lg text-[13.5px] font-medium transition group ${
                        isActive
                          ? 'bg-white/[0.08] text-white'
                          : 'text-slate-400 hover:bg-white/[0.04] hover:text-white'
                      }`
                    }
                  >
                    {({ isActive }) => (
                      <>
                        {isActive && <span className={`absolute left-0 top-2 bottom-2 w-1 rounded-r ${item.dot}`} />}
                        <Icon className={`text-[16px] ${isActive ? item.accent : ''}`} />
                        <span className="flex-1">{item.label}</span>
                      </>
                    )}
                  </NavLink>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      {/* User block */}
      <div className="border-t border-white/[0.06] p-3">
        <div className="flex items-center gap-3 p-2 rounded-lg bg-white/[0.03]">
          <div className="w-9 h-9 rounded-full bg-primary text-white text-[13px] font-bold flex items-center justify-center">
            {user.name?.charAt(0)?.toUpperCase() || 'A'}
          </div>
          <div className="flex-1 min-w-0">
            <div className="text-[13px] font-semibold text-white truncate">{user.name}</div>
            <div className="text-[10.5px] text-slate-500 uppercase tracking-wider font-bold">Quản trị viên</div>
          </div>
          <button onClick={logout} className="w-8 h-8 rounded-md text-slate-400 hover:bg-white/[0.06] hover:text-red-400 flex items-center justify-center transition" title="Đăng xuất">
            <FiLogOut className="text-[14px]" />
          </button>
        </div>
        <Link to="/" className="flex items-center justify-center gap-2 mt-2 text-[12px] text-slate-500 hover:text-white py-2 transition">
          <FiArrowLeft /> Về trang khách
        </Link>
      </div>
    </aside>
  );

  return (
    <div className="flex min-h-screen bg-slate-100">
      {/* Desktop sidebar */}
      <div className="hidden lg:block">{Sidebar}</div>

      {/* Mobile drawer */}
      {mobileOpen && (
        <>
          <div className="lg:hidden fixed inset-0 bg-black/60 z-40" onClick={() => setMobileOpen(false)} />
          <div className="lg:hidden fixed left-0 top-0 z-50">{Sidebar}</div>
        </>
      )}

      {/* Main */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar */}
        <header className="h-16 bg-white border-b border-slate-200 px-5 lg:px-7 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-3">
            <button onClick={() => setMobileOpen(true)} className="lg:hidden w-9 h-9 rounded-lg text-slate-600 hover:bg-slate-100 flex items-center justify-center">
              <FiMenu className="text-lg" />
            </button>
            <div className="hidden md:flex items-center gap-2 bg-slate-100 rounded-lg h-10 px-3.5 w-[320px]">
              <FiSearch className="text-slate-400 text-[14px]" />
              <input placeholder="Tìm kiếm nhanh..." className="bg-transparent flex-1 outline-none text-[13px] placeholder:text-slate-400" />
              <kbd className="hidden lg:inline-flex text-[10px] font-mono bg-white border border-slate-200 rounded px-1.5 py-0.5 text-slate-400">⌘K</kbd>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button className="relative w-10 h-10 rounded-lg hover:bg-slate-100 text-slate-600 flex items-center justify-center transition">
              <FiBell className="text-[17px]" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-accent rounded-full ring-2 ring-white" />
            </button>
            <div className="hidden sm:flex items-center gap-2.5 pl-3 border-l border-slate-200">
              <div className="text-right">
                <div className="text-[12.5px] font-bold text-[#0B1120] leading-tight">{user.name}</div>
                <div className="text-[10.5px] text-slate-500">Admin</div>
              </div>
              <div className="w-9 h-9 rounded-full bg-[#0B1120] text-white text-[12px] font-bold flex items-center justify-center">
                {user.name?.charAt(0)?.toUpperCase() || 'A'}
              </div>
            </div>
          </div>
        </header>

        <main className="flex-1 p-5 lg:p-7 overflow-y-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
