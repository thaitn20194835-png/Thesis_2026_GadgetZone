import { useState } from 'react';
import { Link } from 'react-router-dom';
import { FiPhone, FiMail, FiMapPin, FiSend, FiArrowUp, FiFacebook, FiYoutube, FiInstagram, FiTwitter } from 'react-icons/fi';
import { toast } from 'react-toastify';

const Footer = () => {
  const [email, setEmail] = useState('');

  const handleNewsletter = (e) => {
    e.preventDefault();
    if (email.trim()) {
      toast.success('Cảm ơn bạn đã đăng ký nhận tin!');
      setEmail('');
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#0B1120] text-white">
      {/* ===== Newsletter — editorial divide ===== */}
      <div className="border-b border-white/10">
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-14 grid lg:grid-cols-2 gap-10 items-center">
          <div>
            <span className="gz-eyebrow text-primary">Bản tin GadgetZone</span>
            <h2 className="font-heading text-[28px] lg:text-[36px] font-black tracking-tight leading-tight mt-3 max-w-[400px]">
              Đăng ký nhận tin & ưu đãi độc quyền
            </h2>
            <p className="text-slate-400 text-[14px] mt-3 max-w-[440px] leading-relaxed">
              Là người đầu tiên biết về sản phẩm mới, khuyến mãi giới hạn và bài viết công nghệ chuyên sâu của chúng tôi.
            </p>
          </div>

          <form onSubmit={handleNewsletter} className="flex gap-2.5">
            <div className="flex-1 relative">
              <FiMail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                type="email"
                placeholder="email@cuaban.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full bg-white/5 border border-white/15 rounded-lg pl-11 pr-4 py-3.5 text-[14px] outline-none focus:border-primary focus:bg-white/10 placeholder:text-slate-500 transition"
              />
            </div>
            <button
              type="submit"
              className="bg-white text-[#0B1120] hover:bg-primary hover:text-white px-6 py-3.5 rounded-lg font-semibold text-[14px] transition-all flex items-center gap-2"
            >
              <FiSend />
              <span className="hidden sm:inline">Đăng ký</span>
            </button>
          </form>
        </div>
      </div>

      {/* ===== Main grid ===== */}
      <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-14 grid lg:grid-cols-12 gap-10">
        {/* Brand */}
        <div className="lg:col-span-4">
          <Link to="/" className="inline-flex items-center gap-2.5 mb-5">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <span className="font-heading font-black text-white text-[15px] tracking-tighter">GZ</span>
            </div>
            <span className="font-heading font-extrabold text-[22px] tracking-tight">
              Gadget<span className="text-primary">Zone</span>
            </span>
          </Link>

          <p className="text-slate-400 text-[13.5px] leading-relaxed max-w-[360px]">
            Cửa hàng điện tử trực tuyến uy tín hàng đầu Việt Nam. Sản phẩm chính hãng, giá tốt nhất, dịch vụ tận tâm.
          </p>

          <div className="mt-7 space-y-2.5">
            <a href="tel:19001234" className="flex items-center gap-3 text-slate-400 hover:text-white transition group">
              <span className="w-9 h-9 rounded-lg bg-white/5 group-hover:bg-primary flex items-center justify-center transition">
                <FiPhone className="text-[14px]" />
              </span>
              <span className="text-[13.5px] font-medium">1900 1234</span>
            </a>
            <a href="mailto:support@gadgetzone.vn" className="flex items-center gap-3 text-slate-400 hover:text-white transition group">
              <span className="w-9 h-9 rounded-lg bg-white/5 group-hover:bg-primary flex items-center justify-center transition">
                <FiMail className="text-[14px]" />
              </span>
              <span className="text-[13.5px] font-medium">support@gadgetzone.vn</span>
            </a>
            <div className="flex items-start gap-3 text-slate-400">
              <span className="w-9 h-9 rounded-lg bg-white/5 flex items-center justify-center flex-shrink-0">
                <FiMapPin className="text-[14px]" />
              </span>
              <span className="text-[13.5px] leading-relaxed pt-1.5">73 Quang Trung, Hà Đông, Hà Nội</span>
            </div>
          </div>

          {/* Social */}
          <div className="flex items-center gap-2 mt-7">
            {[
              { icon: FiFacebook, label: 'Facebook' },
              { icon: FiYoutube, label: 'YouTube' },
              { icon: FiInstagram, label: 'Instagram' },
              { icon: FiTwitter, label: 'Twitter' },
            ].map((s, i) => {
              const Icon = s.icon;
              return (
                <a key={i} href="#" aria-label={s.label} className="w-10 h-10 rounded-lg bg-white/5 hover:bg-primary border border-white/10 hover:border-primary flex items-center justify-center text-slate-400 hover:text-white transition">
                  <Icon className="text-[15px]" />
                </a>
              );
            })}
          </div>
        </div>

        {/* Link columns */}
        <div className="lg:col-span-8 grid grid-cols-2 sm:grid-cols-3 gap-8">
          <div>
            <h4 className="gz-eyebrow text-white mb-4">Khám phá</h4>
            <ul className="space-y-2.5">
              {[
                ['Sản phẩm', '/san-pham'],
                ['Tin tức', '/tin-tuc'],
                ['Giới thiệu', '/gioi-thieu'],
                ['Liên hệ', '/lien-he'],
              ].map(([label, to]) => (
                <li key={label}>
                  <Link to={to} className="text-[13.5px] text-slate-400 hover:text-white transition">{label}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="gz-eyebrow text-white mb-4">Danh mục</h4>
            <ul className="space-y-2.5">
              {['Điện thoại', 'Laptop', 'Tablet', 'Đồng hồ', 'Âm thanh', 'Phụ kiện'].map((c) => (
                <li key={c}>
                  <Link to={`/san-pham?search=${encodeURIComponent(c)}`} className="text-[13.5px] text-slate-400 hover:text-white transition">{c}</Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="gz-eyebrow text-white mb-4">Hỗ trợ khách hàng</h4>
            <ul className="space-y-2.5">
              {[
                'Chính sách bảo hành',
                'Chính sách đổi trả',
                'Hướng dẫn mua hàng',
                'Phương thức thanh toán',
                'Câu hỏi thường gặp',
              ].map((s) => (
                <li key={s}>
                  <a href="#" className="text-[13.5px] text-slate-400 hover:text-white transition">{s}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* ===== Bottom bar ===== */}
      <div className="border-t border-white/10">
        <div className="max-w-[1240px] mx-auto px-4 lg:px-6 py-5 flex flex-col md:flex-row items-center justify-between gap-3 text-[12px] text-slate-500">
          <p>© 2026 GadgetZone. Bảo lưu mọi quyền.</p>
          <div className="flex items-center gap-4">
            <a href="#" className="hover:text-white transition">Điều khoản</a>
            <span className="w-1 h-1 bg-slate-700 rounded-full" />
            <a href="#" className="hover:text-white transition">Bảo mật</a>
            <span className="w-1 h-1 bg-slate-700 rounded-full" />
            <a href="#" className="hover:text-white transition">Cookies</a>
          </div>
          <button
            onClick={scrollToTop}
            aria-label="Lên đầu trang"
            className="w-9 h-9 rounded-lg bg-white/5 hover:bg-primary border border-white/10 flex items-center justify-center text-slate-400 hover:text-white transition"
          >
            <FiArrowUp />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
