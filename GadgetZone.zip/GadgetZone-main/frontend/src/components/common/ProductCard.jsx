import { Link, useNavigate } from 'react-router-dom';
import { FiShoppingCart, FiStar, FiHeart, FiZap } from 'react-icons/fi';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import { toast } from 'react-toastify';

const ProductCard = ({ product, compact = false }) => {
  const { addToCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();

  // Format giá kiểu Việt Nam: 24.990.000 → "24,99 triệu" (gọn, dễ đọc)
  const formatPrice = (p) => {
    const n = p || 0;
    if (n >= 1_000_000) {
      const tr = (n / 1_000_000).toFixed(2).replace(/\.?0+$/, '').replace('.', ',');
      return `${tr} triệu`;
    }
    if (n >= 1_000) return `${(n / 1_000).toFixed(0)}k`;
    return `${n.toLocaleString('vi-VN')}đ`;
  };

  const handleAddToCart = async (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      toast.warning('Vui lòng đăng nhập để mua hàng');
      navigate('/dang-nhap');
      return;
    }
    try {
      await addToCart(product._id, 1);
      toast.success('Đã thêm vào giỏ hàng');
    } catch {
      toast.error('Thêm giỏ hàng thất bại');
    }
  };

  const hasDiscount = product.salePrice > 0 && product.salePrice < product.price;
  const discountPercent = hasDiscount
    ? Math.round((1 - product.salePrice / product.price) * 100)
    : 0;
  const finalPrice = hasDiscount ? product.salePrice : product.price;

  return (
    <article className="group relative bg-white border border-slate-200/80 rounded-xl overflow-hidden hover:border-slate-300 transition-all duration-300">
      {/* Top ribbon */}
      {hasDiscount && (
        <div className="absolute top-3 left-3 z-10 bg-accent text-white text-[10.5px] font-bold tracking-wider px-2 py-1 rounded-md flex items-center gap-1 uppercase">
          <FiZap className="text-[10px]" />
          Giảm {discountPercent}%
        </div>
      )}
      {product.isFeatured && !hasDiscount && (
        <div className="absolute top-3 left-3 z-10 bg-[#0B1120] text-white text-[10.5px] font-bold tracking-wider px-2 py-1 rounded-md uppercase">
          Nổi bật
        </div>
      )}

      {/* Wishlist (visual only) */}
      <button
        onClick={(e) => { e.preventDefault(); e.stopPropagation(); toast.info('Đã thêm vào yêu thích'); }}
        className="absolute top-3 right-3 z-10 w-9 h-9 bg-white/90 backdrop-blur-sm border border-slate-200 rounded-full flex items-center justify-center text-slate-500 hover:text-accent hover:border-accent opacity-0 group-hover:opacity-100 transition-all duration-300"
        aria-label="Thêm yêu thích"
      >
        <FiHeart className="text-[15px]" />
      </button>

      <Link to={`/san-pham/${product._id}`} className="block">
        {/* Image — fill the card, ảnh to đẹp */}
        <div className="relative aspect-square bg-slate-50 overflow-hidden">
          {product.images?.[0] ? (
            <img
              src={product.images[0]}
              alt={product.name}
              loading="lazy"
              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
              onError={(e) => { e.target.style.display = 'none'; }}
            />
          ) : (
            <div className="flex items-center justify-center h-full text-slate-300 text-4xl">
              <FiShoppingCart />
            </div>
          )}
        </div>

        {/* Body */}
        <div className={`px-4 ${compact ? 'pt-3 pb-3' : 'pt-3.5 pb-4'}`}>
          {product.brand?.name && (
            <span className="text-[10.5px] tracking-[0.15em] uppercase font-bold text-slate-400">
              {product.brand.name}
            </span>
          )}

          <h3 className="text-[14px] font-semibold text-slate-800 line-clamp-2 mt-1 leading-snug min-h-[40px]">
            {product.name}
          </h3>

          {/* Stars */}
          <div className="flex items-center gap-1.5 mt-2">
            <div className="flex items-center gap-0.5">
              {[1,2,3,4,5].map((i) => (
                <FiStar
                  key={i}
                  className={i <= Math.round(product.rating || 0)
                    ? 'text-amber-400 fill-amber-400 text-[11px]'
                    : 'text-slate-200 fill-slate-200 text-[11px]'
                  }
                />
              ))}
            </div>
            <span className="text-[11.5px] text-slate-400">
              {product.rating?.toFixed(1) || '0.0'}
              {product.numReviews > 0 && <span className="ml-1">· {product.numReviews}</span>}
            </span>
          </div>

          {/* Price */}
          <div className="mt-2.5 flex items-baseline flex-wrap gap-x-2 gap-y-0.5">
            <span className="text-[18px] font-extrabold text-[#0B1120] tracking-tight">
              {formatPrice(finalPrice)}
            </span>
            {hasDiscount && (
              <span className="text-[12.5px] text-slate-400 line-through">
                {formatPrice(product.price)}
              </span>
            )}
          </div>

          {hasDiscount && (
            <p className="text-[11.5px] text-accent font-semibold mt-1">
              Tiết kiệm {formatPrice(product.price - product.salePrice)}
            </p>
          )}
        </div>
      </Link>

      {/* Footer button — visible by default, prominent on hover */}
      <div className="px-4 pb-4">
        <button
          onClick={handleAddToCart}
          className="w-full flex items-center justify-center gap-2 bg-slate-100 hover:bg-[#0B1120] text-slate-700 hover:text-white text-[13px] font-semibold py-2.5 rounded-lg transition-colors duration-200"
        >
          <FiShoppingCart className="text-[15px]" />
          <span>Thêm vào giỏ</span>
        </button>
      </div>
    </article>
  );
};

export default ProductCard;
